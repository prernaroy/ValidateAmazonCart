/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.SearchFinancing;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class SearchFinancing {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(SearchFinancing.class);

	public SearchFinancing(WebDriver driver) {
	}

	@FindBy(xpath = "//h1")
	private WebElement txt_ScreenName;

	@FindBy(xpath = "//*[text()='MyFilter']/../following::div[position()=1]")
	private WebElement cmbSlctView;

	@FindBy(xpath = "//label[contains(text(),'Name')]/../following::div[position()=2]//input")
	private WebElement txt_Name;

	@FindBy(xpath = "//label[contains(text(),'Release Status')]/../following::div[position()=2]//input")
	private WebElement txt_Status;

	@FindBy(xpath = "//*[text()='Go']")
	private WebElement btnGo;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'DealSearch')]/tbody/tr[1]")
	private WebElement table_Finance;

	public String xpSelectView = "//*[text()='MyFilter']/../following::div[position()=1]";
	public String xpName = "//label[contains(text(),'Name')]/../following::div[position()=2]//input";
	public String xpStatus = "//label[contains(text(),'Release Status')]/../following::div[position()=2]//input";
	public String xpGo = "//*[text()='Go']";
	public String xptblFinance = "//table[contains(@aria-labelledby,'DealSearch')]/tbody/tr[1]";

	public boolean searchfinance(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_SEARCHFINANCING_Name);
		String sReleaseStatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SEARCHFINANCING_ReleaseStatus);
		String sSearch = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_SEARCHFINANCING_Search);

		try {
			lowlevellogsobj.info("Started in Search Finance Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			Thread.sleep(3000);
			if (driver.findElements(By.xpath("h1")).size() == 1) {
				WebElement eleTitle = driver.findElement(By.xpath("//h1[text()='All Financing Deals']"));
				commfunct_Obj.expectedValue(eleTitle, "text", "All Financing Deals", "Yes");
				lowlevellogsobj.info("Landed successfully on Search Financing Screen");
			}
			Thread.sleep(2000);

			if (sName.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpName, "Yes", sName);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Finance name is entered as ->" + sName);
			}

			if (sReleaseStatus.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpStatus)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpStatus, "Yes", sReleaseStatus);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Release Status is entered as ->" + sReleaseStatus);
			}

				Thread.sleep(3000);
			if (sSearch.equalsIgnoreCase("Yes")) {
				commfunct_Obj.waitUntilDocumentIsReady(driver);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpGo)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpGo, "Yes");
				lowlevellogsobj.info("Clicked on Go Button");
				Thread.sleep(3000);
			}
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptblFinance)));
			commfunct_Obj.commonClick(table_Finance, "Yes");
			lowlevellogsobj.info("Finance with Released status is selected");

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering Search Finance Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}
}