/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Drawdowns;

import static org.testng.Assert.expectThrows;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;

/**
 * @author I313006
 *
 */
public class Drawdown {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();

	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Drawdown.class);

	public Drawdown(WebDriver driver) {
	}

	@FindBy(xpath = "//*[(@id='application-zdealsearch-manage-component---dealEdit--idDealEditObjectPage-anchBar')]//div[4]")
	public WebElement lst_SubMenu;


	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Minimum Amount per Drawdown']/../following::div[position()=3]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_MinAmtPerDD;


	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Minimum Amount per Drawdown']/../following::div[position()=7]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_MinAmt_NR;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MinAmount-input-inner')]")
	public WebElement txt_MinAmtPerDDVal;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MinAmount-sfEdit-input-inner')]")
	public WebElement txt_MinAmtPerDDCurr;



	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Maximum Amount per Drawdown']/../following::div[position()=3]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_MaxAmtPerDD;


	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Maximum Amount per Drawdown']/../following::div[position()=7]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_MaxAmt_NR;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MaxAmount-input-inner')]")
	public WebElement txt_MaxAmtPerDDVal;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MaxAmount-sfEdit-input-inner')]")
	public WebElement txt_MaxAmtPerDDCurr;



	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Multiple Of']/../following::div[position()=3]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_MultipleOf;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Multiple Of']/../following::div[position()=7]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_MultipleOf_NR;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MultipleOf-input-inner')]")
	public WebElement txt_Multipleof;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MultipleOf-sfEdit-input-inner')]")
	public WebElement txt_MultipleofCurr;


	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='All Products']/following::div[position()=1]")
	public WebElement sldr_PermAllProd;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='All Currencies']/following::div[position()=1]")
	public WebElement sldr_PermAllCurr;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='All Interest Periods']/following::div[position()=1]")
	public WebElement sldr_PermIntPeriod;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Free Text Rules']/following::button[position()=3]/span")
	public WebElement btn_AddFT;



	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//label[contains(text(),'Valid To')]/../following::div[position()=2]//span[contains(@id,'arrow')]")
	public WebElement cmbValidTo;

	@FindBy(xpath = "//div[contains(@id,'DealDrawingRulesView')]//table[contains(@aria-labelledby,'FreeTextRules')]/tbody/tr[1]/td[3]/span")
	public WebElement table_FTcol;




	public String xpDDRulestab="//*[contains(@id,'dealEdit--DealDrawingRules-anchor-content')]";

	public String xpradbtn_MinAmtPerDD="//div[contains(@id,'DealDrawingRulesView')]//*[text()='Minimum Amount per Drawdown']/../following::input[position()=1][contains(@id,'RB')]";
	public String xpradbtn_MinAmtPerNR="//div[contains(@id,'DealDrawingRulesView')]//*[text()='Minimum Amount per Drawdown']/../following::input[position()=2][contains(@id,'RB')]";
	public String xptxt_MinAmtval="//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MinAmount-input-inner')]";
	public String xptxt_MinAmtPerDDCurr="//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MinAmount-sfEdit-input-inner')]";


	public String xpradbtn_MaxAmtPerDD= "//div[contains(@id,'DealDrawingRulesView')]//*[text()='Maximum Amount per Drawdown']/../following::input[position()=1][contains(@id,'RB')]";
	public String xptxt_MaxAmtPerDDVal= "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MaxAmount-input-inner')]";
	public String xptxt_MaxAmtPerDDCurr= "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MaxAmount-sfEdit-input-inner')]";

	public String xpradbtn_MultipleOf="//div[contains(@id,'DealDrawingRulesView')]//*[text()='Multiple Of']/../following::input[position()=1][contains(@id,'RB')]";
	public String xptxt_Multipleof= "//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MultipleOf-input-inner')]";
	public String xptxt_MultipleofCurr="//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'MultipleOf-sfEdit-input-inner')]";

	public String xpsldr_PermAllProd="//div[contains(@id,'DealDrawingRulesView')]//*[text()='All Products']/following::div[position()=1]/div";
	public String xpsldr_PermAllCurr="//div[contains(@id,'DealDrawingRulesView')]//*[text()='All Currencies']/following::div[position()=1]/div";
	public String xpsldr_PermIntPeriod="//div[contains(@id,'DealDrawingRulesView')]//*[text()='All Interest Periods']/following::div[position()=1]/div";


	public String xpbtnFTAdd="//div[contains(@id,'DealDrawingRulesView')]//*[text()='Free Text Rules']/following::button[position()=3]/span";
	public String xptxt_FT="//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'FreeText-input-inner')]";
	public String xptxt_FTdt="//div[contains(@id,'DealDrawingRulesView')]//input[contains(@id,'ValidFrom-datePicker-inner')]";

	public String xpFTCreate="//div[contains(@id,'DealDrawingRulesView')]//*[text()='Create']";
	public String xpFTTablecol = "//div[contains(@id,'DealDrawingRulesView')]//table[contains(@aria-labelledby,'FreeTextRules')]/tbody/tr[1]/td[3]/span";
	public String xpValidTo= "//div[contains(@id,'DealDrawingRulesView')]//label[contains(text(),'Valid To')]/../following::div[position()=2]//span[contains(@id,'arrow')]";

	public boolean drawdownDetails(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
			throws InterruptedException, IOException, SAXException,
			ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 30);

		String sMinAmtPerDD = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_MinAmtPerDD);
		String sMinAmtPerDDVal = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_MinAmtPerDDVal);
		String sMaxAmtPerDD = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_MaxAmtPerDD);
		String sMaxAmtPerDDVal = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_MaxAmtPerDDVal);
		String sMultipleOf = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_MultipleOf);
		String sMultipleOfVal = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_MultipleOfVal);
		String sPermAllProd = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_PermAllProd);
		String sPermAllCurr = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_PermAllCurr);
		String sPermIntPeriod = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_PermIntPeriod);
		String sCurrency=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_CURRENCY);
		String sFTR = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_FreeTextRule);
		String sFT = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_FreeText);
		String sValidfrom = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRAWDOWNRULES_ValidFrom);
		String sValidTo = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRAWDOWNRULES_ValidTo);

		try {
			lowlevellogsobj.info("Started in Drawdown Class");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDRulestab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDRulestab, "Yes");
			

			if(sMinAmtPerDDVal.length()>0){
				if(sMinAmtPerDD.equalsIgnoreCase("Amount")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradbtn_MinAmtPerDD)));
					commfunct_Obj.commonClick(radbtn_MinAmtPerDD, "Yes");
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_MinAmtval)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_MinAmtval, "Yes", sMinAmtPerDDVal);
					txt_MinAmtPerDDVal.sendKeys(Keys.ENTER);
					Thread.sleep(3000);
					lowlevellogsobj.info("Minimum Amount per Drawdown Amount is ->"+sMinAmtPerDDVal);
					if(sCurrency.length()>0){
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_MinAmtPerDDCurr)));
						commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_MinAmtPerDDCurr, "Yes", sCurrency);
						txt_MinAmtPerDDCurr.sendKeys(Keys.ENTER);
						Thread.sleep(3000);
						lowlevellogsobj.info("Minimum Amount per Drawdown Amount Currency is ->"+sCurrency);
					}
				}
				else{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradbtn_MinAmtPerNR)));
					commfunct_Obj.commonClick(radbtn_MinAmt_NR, "Yes");
					lowlevellogsobj.info("Minimum Amount per Drawdown is Not Restricted");
				}
			}

			if (sMaxAmtPerDDVal.length()>0){

				if(sMaxAmtPerDD.equalsIgnoreCase("Amount")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradbtn_MaxAmtPerDD)));
					commfunct_Obj.commonClick(radbtn_MaxAmtPerDD, "Yes");
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_MaxAmtPerDDVal)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_MaxAmtPerDDVal, "Yes", sMaxAmtPerDDVal);
					txt_MaxAmtPerDDVal.sendKeys(Keys.ENTER);
					Thread.sleep(1000);
					lowlevellogsobj.info("Maximum Amount per Drawdown Amount is ->"+sMaxAmtPerDDVal);
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_MaxAmtPerDDCurr)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_MaxAmtPerDDCurr, "Yes", sCurrency);
					txt_MaxAmtPerDDCurr.sendKeys(Keys.ENTER);
					Thread.sleep(1000);
					lowlevellogsobj.info("Maximum Amount per Drawdown Amount Currency is ->"+sCurrency);
				}
				else{
					
					commfunct_Obj.commonClick(radbtn_MaxAmt_NR, "Yes");
					lowlevellogsobj.info("Maximum Amount per Drawdown is Not Restricted");
				}
			}

			Thread.sleep(500);
			if(sMultipleOfVal.length()>0){
				if(sMultipleOf.equalsIgnoreCase("Amount")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradbtn_MultipleOf)));
					commfunct_Obj.commonClick(radbtn_MultipleOf, "Yes");
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_Multipleof)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_Multipleof, "Yes", sMultipleOfVal);
					txt_Multipleof.sendKeys(Keys.ENTER);
					Thread.sleep(1000);
					lowlevellogsobj.info("Multiple Of Amount entered is ->"+sMaxAmtPerDDVal);
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_MultipleofCurr)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_MultipleofCurr, "Yes", sCurrency);
					txt_MultipleofCurr.sendKeys(Keys.ENTER);
					Thread.sleep(1000);
					lowlevellogsobj.info("Multiple Of Currency is ->"+sCurrency);
				}
				else{
				
					commfunct_Obj.commonClick(radbtn_MultipleOf_NR, "Yes");
					lowlevellogsobj.info("Multiple Of is selected as Not Restricted");
				}
			}

			
			if (sPermAllProd.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpsldr_PermAllProd)));
				commfunct_Obj.commonClick(sldr_PermAllProd, "Yes");
				lowlevellogsobj.info("All Products option is opted in");
			}
			else{
				lowlevellogsobj.info("All Products option is opted out");
			}

			if (sPermAllCurr.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpsldr_PermAllCurr)));
				commfunct_Obj.commonClick(sldr_PermAllCurr, "Yes");
				lowlevellogsobj.info("All Currencies option is opted in");
			}
			else{
				lowlevellogsobj.info("All Currencies option is opted out");
			}

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sldr_PermIntPeriod);
			Thread.sleep(500);

			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("xpsldr_PermIntPeriod")));
			if (sPermIntPeriod.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpsldr_PermIntPeriod)));
				commfunct_Obj.commonClick(sldr_PermIntPeriod, "Yes");
				lowlevellogsobj.info("All Interest Periods option is opted in");
			}
			else{
				lowlevellogsobj.info("All Interest Periods option is opted out");
			}
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btn_AddFT);
			Thread.sleep(500);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnFTAdd)));

			//Add Free Text Rule
			if(sFTR.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnFTAdd)));
				commfunct_Obj.commonClick(btn_AddFT, "Yes");
				
				if(sFT.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_FT)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_FT, "Yes", sFT);
				}
				if(sValidfrom.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_FTdt)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xptxt_FTdt, "Yes", sValidfrom);
				}
				if(sValidTo.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidTo)));
				commfunct_Obj.comboSelect(driver, sValidTo, cmbValidTo);
				}
				
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFTCreate)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpFTCreate, "Yes");
			}
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFTTablecol)));
			commfunct_Obj.expectedValue(table_FTcol, "text",sFT,"Yes");
			lowlevellogsobj.info("Free Text Rule is added");
			Thread.sleep(2000);


			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering Drawdown Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}



}
