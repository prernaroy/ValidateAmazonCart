/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Copy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import application.Drawdowns.Drawdown;
import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class Copy_VerifySource {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Copy_VerifySource.class);
	boolean result1;
	private WebDriver driver;
	public Drawdown ddrules = new Drawdown(driver);

	public Copy_VerifySource(WebDriver driver) {
	}

	@FindBy(xpath = "//*[contains(@id,'idDealDisplayHeader-overflow-inner')]")
	private WebElement btnMore;

	@FindBy(xpath = "//div[contains(@id,'popover')]//*[text()='Copy']")
	private WebElement btnShowcashflow;

	@FindBy(xpath = "//div[contains(@id,'idDealMenuButtonLevel')]/descendant::button[position()=2]/span")
	private WebElement cmbShowlevel;

	@FindBy(xpath = "//*[text()='Business Partners']/preceding::div[position()=1]")
	private WebElement chkBusinesspartners;

	@FindBy(xpath = "//*[text()='Responsible Agents']/preceding::div[position()=1]")
	private WebElement chkResponsibleagents;

	@FindBy(xpath = "//*[text()='Syndication Agreements']/preceding::div[position()=1]")
	private WebElement chkSyndicationagreements;

	@FindBy(xpath = "//*[text()='Locks']/preceding::div[position()=1]")
	private WebElement chkLocks;

	@FindBy(xpath = "//*[text()='Rules']/preceding::div[position()=1]")
	private WebElement chkPCR;

	@FindBy(xpath = "//*[text()='Conditions']/preceding::div[position()=1]")
	private WebElement chkConditions;

	@FindBy(xpath = "//*[text()='Drawdown Rules']/preceding::div[position()=1]")
	private WebElement chkDrawdownrules;

	@FindBy(xpath = "//*[text()='Covenants']/preceding::div[position()=1]")
	private WebElement chkCovenants;

	@FindBy(xpath = "//div[contains(@id,'DealCopyTreeTable-rowsel2')]")
	private WebElement chkDDlevel;

	@FindBy(xpath = "//footer//*[text()='Copy']")
	private WebElement btnCopy;

	@FindBy(xpath = "//*[text()='Expand']/../following::span[position()=1]")
	private WebElement cmbSlctlevel;

	@FindBy(xpath = "//td[contains(@id,'OverviewTreeTable-rows-row0-col0')]//span[contains(text(),'Copy Of')]")
	private WebElement lblCreate;

	@FindBy(xpath = "//td[contains(@id,'dealEdit--DealOverviewView--OverviewTreeTable-rows-row1-col0')]//a")
	private WebElement linkTranche;

	@FindBy(xpath = "//td[contains(@id,'dealEdit--DealOverviewView--OverviewTreeTable-rows-row2-col0')]//a")
	private WebElement linkTranche1;

	@FindBy(xpath = "//td[contains(@id,'dealEdit--DealOverviewView--OverviewTreeTable-rows-row2-col0')]//a")
	private WebElement linkDD;

	@FindBy(xpath = "//td[contains(@id,'dealEdit--DealOverviewView--OverviewTreeTable-rows-row3-col0')]//a")
	private WebElement linkDD1;
	
	
	@FindBy(xpath = "//td[contains(@id,'trancheEdit--TrancheOverviewView--OverviewTreeTable-rows-row1-col0')]//a")
	private WebElement linkDDTranche;
	
	@FindBy(xpath = "//td[contains(@id,'trancheEdit--TrancheOverviewView--OverviewTreeTable-rows-row1-col0')]//a")
	private WebElement linkDDTranche1;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'dealEdit--CovenantView--covenantTable-header')]/tbody/tr[1]/td[3]")
	private WebElement rowCov;
	
	@FindBy(xpath = "//table[contains(@aria-labelledby,'drawdownEdit--CovenantView--covenantTable-header')]/tbody/tr[1]/td[3]")
	private WebElement DDrowCov;

	@FindBy(xpath = "//*[contains(text(),'Covenant Type')]/../following::div[position()=1]//input")
	private WebElement txt_CovenantType;

	@FindBy(xpath = "//*[contains(text(),'Description')]/../following::div[position()=1]//input")
	private WebElement txt_Description;

	@FindBy(xpath = "//*[text()='End of Contractual Consequences']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbEOC;

	@FindBy(xpath = "//*[contains(text(),'Valid From')]/../following::div[position()=1]//input")
	private WebElement txt_Validfrom;

	@FindBy(xpath = "//*[text()='Valid To']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbValidto;

	@FindBy(xpath = "//*[text()='Details']")
	private WebElement btn_Details;

	@FindBy(xpath = "//*[contains(@id,'dealEdit--DealDetailsView--idStatusForDeal-label')]")
	private WebElement lblStatus;



	@FindBy(xpath = "//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'bank')]")
	private WebElement radioBank;

	@FindBy(xpath = "//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'borrower')]")
	private WebElement radioBorrower;
	
	@FindBy(xpath = "//div[contains(@id,'component---Edit--DetailsView--borrower')]/div[not(contains(@class,'Inn'))]")
	private WebElement DDradioBorrower;

	@FindBy(xpath = "//*[text()='First Key Date']/../following::div[position()=1]//span")
	private WebElement txtFKdate;

	@FindBy(xpath = "//*[text()='Covenant Monitoring Procedure']/../following::div[position()=1]//label")
	private WebElement cmbCMP;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'idContractualConsequences-header')]/tbody/tr[1]/td[2]")
	private WebElement linkcovenantCC;

	@FindBy(xpath = "//*[contains(text(),'Individual Lock')]/following::div[position()=2]//label")
	private WebElement cmbIL;

	@FindBy(xpath = "//a[@id='backBtn']")
	private WebElement btnBack;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'conditionTable')]/tbody/tr[1]/td[3]//span/span")
	private WebElement lblConditiontype;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'trancheEdit--ConditionView--conditionTable-header')]/tbody/tr[1]/td[3]//span/span")
	private WebElement lbltrancheConditiontype;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'conditionTable')]/tbody/tr[1]/td[4]//span/span")
	private WebElement lblValidfrom;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'trancheEdit--ConditionView--conditionTable-header')]/tbody/tr[1]/td[4]//span/span")
	private WebElement lbltrancheValidfrom;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'dealEdit--ConditionView--conditionTable-header')]/tbody/tr[1]/td[6]/div/span[position()=1]")
	private WebElement lblPercentage;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'trancheEdit--ConditionView--conditionTable-header')]/tbody/tr[1]/td[6]/div/span[position()=1]")
	private WebElement lbltranchePercentage;

	@FindBy(xpath = "//label[@title='Role in the Syndication']/../following::div[position()=3]//input")
	private WebElement cmbRole;
	
	@FindBy(xpath = "//div[contains(@id,'trancheEdit--SyndicationView--idSyndicationHeader--Form--Grid')]//label[@title='Role in the Syndication']/following::span[position()=1]")
	private WebElement cmbTRole;
	
	
	@FindBy(xpath = "//*[text()='Mandatory Syndication']/../following::div[position()=1]//input")
	private WebElement cmbMndsyndication;

	@FindBy(xpath = "//input[contains(@id,'dealEdit--SyndicationView')]")
	private WebElement txtAmnt;
	
	@FindBy(xpath = "//input[contains(@id,'trancheEdit--SyndicationView')]")
	private WebElement txtTAmnt;

	@FindBy(xpath = "//*[contains(@id,'idSaveDeal')]//*")
	private WebElement btn_Save;
	
	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btn_Apply;
	
	@FindBy(xpath = "//*[text()='Release Status:']/following::span[position()=1]")
	private WebElement labelFinancestatus;

	@FindBy(xpath = "//footer[contains(@id,'footer')]//*[text()='Submit']")
	private WebElement btnSubmit;


	@FindBy(xpath = "//*[contains(@id,'dealEdit--DealOverview-anchor-content')]")
	private WebElement tabOverview;

	@FindBy(xpath = "//*[contains(@id,'trancheEdit--TrancheDetailsView--idBorrowerTranche-label')]")
	private WebElement TrancheMB;

	@FindBy(xpath = "//*[contains(@id,'trancheEdit--TrancheDetailsView--idTrancheProdSelect-label')]")
	private WebElement TranchePrd;
	
	
	@FindBy(xpath = "//*[contains(@id,'trancheEdit--SyndicationView--idSyndicationHeader--Form--Grid')]//label[@title='Role in the Syndication']/following::span[position()=1]")
	private WebElement trancheSyndrole;
	
	
	@FindBy(xpath = "//*[contains(@id,'DrawdownDetailsView--idDrawdownProdSelect-label')]")
	private WebElement DDPrd;
	
	@FindBy(xpath = "//*[contains(@id,'drawdownEdit--SyndicationView--idSyndicationHeader--Form--Grid')]//label[@title='Role in the Syndication']/following::span[position()=1]")
	private WebElement DDSyndrole;
	
	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;

	public String xpMore = "//*[contains(@id,'idDealDisplayHeader-overflow-inner')]";
	public String xpSCF = "//div[contains(@id,'popover')]//*[text()='Copy']";
	public String xpCopytable = "//table[contains(@id,'DealCopyTreeTable-table')]/tbody/tr[1]/td[2]//span[contains(text(),'Auto')]";
	public String xpchkBP = "//*[text()='Business Partners']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkRA = "//*[text()='Responsible Agents']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkSA = "//*[text()='Syndication Agreements']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkLcks = "//*[text()='Locks']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkPCR = "//*[text()='Rules']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkCnd = "//*[text()='Conditions']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkDDR = "//*[text()='Drawdown Rules']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpchkCov = "//*[text()='Covenants']/preceding::input[contains(@id,'selectMulti-CB')]";
	public String xpSelectdrawdown = "//div[contains(@id,'DealCopyTreeTable-rowsel2')]";
	public String xpMB = "//section[contains(@id,'DealEdit')]//label[text()='Main Borrower']/../following::div[position()=2]//input";
	public String xpProduct = "//section[contains(@id,'DealEdit')]//label[text()='Product']/../following::div[position()=2]//input";
	public String xpCD = "//section[contains(@id,'DealEdit')]//label[text()='Commitment date']/../following::div[position()=2]//input";
	public String xpStatus = "//*[contains(@id,'dealEdit--DealDetailsView--idStatusForDeal-label')]";
	public String xpdtlsLangauge = "//label[contains(text(),'Correspondence Language')]/../following::div[position()=2]//input";
	public String xpDtlstab = "//*[contains(@id,'dealEdit--DealDetails-anchor-content')]";
	public String xpTrachedtlstab="//span[contains(@id,'trancheEdit--TrancheDetails-anchor-content')]";
	public String xpDDtlstab="//span[contains(@id,'DrawdownDetails-anchor-inner')]";

	public String xpTMB = "//*[contains(@id,'trancheEdit--TrancheDetailsView--idBorrowerTranche-label')]";
	public String xpTProduct = "//*[contains(@id,'trancheEdit--TrancheDetailsView--idTrancheProdSelect-label')]";
	public String xpTAMT = "//section[contains(@id,'TrancheEdit')]//label[text()='Total Tranche Amount']/../following::div[position()=2]//input[not(contains(@id,'sf'))]";
	public String xpTStartdate = "//section[contains(@id,'TrancheEdit')]//label[text()='Start of Term']/../following::div[position()=2]//input[not(contains(@id,'sf'))]";
	public String xpTEndterm = "//section[contains(@id,'TrancheEdit')]//label[text()='End of Term']/../following::div[position()=5]//input[not(contains(@id,'sf'))]";
	
	public String xpDDAMT = "//section[contains(@id,'drawdownEdit')]//label[text()='Total Drawdown Amount']/../following::div[position()=2]//input[not(contains(@id,'sf'))]";
	public String xpDDStartdate = "//section[contains(@id,'drawdownEdit')]//label[text()='Start of Term']/../following::div[position()=2]//input[not(contains(@id,'sf'))]";
	public String xpDDEndterm = "//section[contains(@id,'drawdownEdit')]//label[text()='End of Term']/../following::div[position()=5]//input[not(contains(@id,'sf'))]";

	public String xpConditionstab = "//*[contains(@id,'dealEdit--DealConditions-anchor-content')]";
	public String xptrancheConditionstab = "//*[contains(@id,'trancheEdit--TrancheConditions-anchor-content')]";
	public String xpDDConditionstab = "//*[contains(@id,'drawdownEdit--DrawdownConditions-anchor-content')]";
	public String xpAddcondition = "//*[contains(@id,'buttonAddCond-img')]";
	public String xpConditiontype = "//table[contains(@aria-labelledby,'conditionTable')]/tbody/tr[1]/td[3]//span/span";
	public String xpValidfrom = "//table[contains(@aria-labelledby,'conditionTable')]/tbody/tr[1]/td[4]//span/span";
	public String xpPercentage = "//table[contains(@aria-labelledby,'conditionTable')]/tbody/tr[1]/td[6]//span/span";
	public String xpFTTablecol = "//div[contains(@id,'DealDrawingRulesView')]//table[contains(@aria-labelledby,'FreeTextRules')]/tbody/tr[1]/td[3]/span";
	public String xpFTTablevalidfrom = "//div[contains(@id,'DealDrawingRulesView')]//table[contains(@aria-labelledby,'FreeTextRules')]/tbody/tr[1]/td[4]/span";
	public String xpCovenantstab = "//*[contains(@id,'dealEdit--DealCovenants-anchor-content')]";
	public String xprowCov = "//table[contains(@aria-labelledby,'dealEdit--CovenantView--covenantTable-header')]/tbody/tr[1]/td[3]";
		
	// Covenants
	public String xpCovtype = "//*[contains(text(),'Covenant Type')]/../following::div[position()=1]//input";
	public String xpDesc = "//*[contains(text(),'Description')]/../following::div[position()=1]//input";
	public String xpEOC = "//*[text()='End of Contractual Consequences']/../following::div[position()=1]//input";
	public String xpvalidFrom = "//*[contains(text(),'Valid From')]/../following::div[position()=1]//input";
	public String xpValidto = "//*[text()='Valid To']/../following::div[position()=1]//input";

	// Covenants Details
	public String xpDetailstab = "//*[text()='Details']";
	public String xpradioBank = "//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'bank')]";
	public String xpCCP = "//*[text()='Covenant Check Procedure']/../following::div[position()=1]//input";
	public String xpSCThreshold = "//*[text()='Soft Covenant Threshold']/../following::div[position()=1]//input";
	public String xpHCThreshold = "//*[text()='Hard Covenant Threshold']/../following::div[position()=1]//input";
	public String xpFKdate = "//*[text()='First Key Date']/../following::div[position()=1]//span";
	public String xpCMP = "//*[text='Covenant Monitoring Procedure']/../following::div[position()=1]//input";
	public String xpCP = "//*[text()='Calculation Period']/../following::div[position()=1]//input";
	public String xpCPcmb = "//*[text()='Calculation Period']/../following::div[position()=7]//input";
	public String xpSubmissiondeadline = "//*[text()='Submission Deadline']/../following::div[position()=1]//input";
	public String xpSDCmb = "//*[text()='Submission Deadline']/following::div[position()=7]//input";

	// Covenant CC
	public String xpCCtab = "//*[text()='Contractual Consequences']";

	// CC Add Lock

	public String xpCCType = "//*[contains(text(),'Consequence Type')]/following::div[position()=2]//input";
	public String xpCCusage = "//*[contains(text(),'Usage')]/following::div[position()=2]//input";
	public String xpCCOC = "//*[contains(text(),'Obligatory Consequence')]/following::div[position()=2]//input";
	public String xpCCLT = "//*[contains(text(),'Lock Type')]/following::div[position()=2]//input";
	public String xpCCIL = "//*[contains(text(),'Individual Lock')]/following::div[position()=2]//label";
	public String xpCCCL = "//*[contains(text(),'Collective Lock')]/following::div[position()=2]//input";
	public String xpCCVF = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Valid From')]/following::div[position()=2]//input";
	public String xpCCTerm = "//*[contains(text(),'Term')]/following::div[position()=2]//input";
	public String xpCCICAFlag = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Inherit Condition Adjustment')]/following::div[position()=2]//input";

	// Partners
	public String xpPartnerstab = "//*[contains(@id,'dealEdit--DealPartners-anchor-content')]";
	public String xpChksyndicate = "//table[contains(@aria-labelledby,'tableForBusinessPartners--table-header')]/tbody/tr[1]/td[3]//span/span";
	public String xpChkpaymentinfo = "//table[contains(@aria-labelledby,'tableForBusinessPartners--table-header')]/tbody/tr[2]/td[10]//span";
	public String xpChkpaymentinfo1 = "//table[contains(@aria-labelledby,'tableForBusinessPartners--table-header')]/tbody/tr[1]/td[10]//span";
	
	//Tranche Partners
	public String xpTPartnerstab = "//*[contains(@id,'trancheEdit--TranchePartners-anchor-content')]";
	public String xpTChksyndicate = "//table[contains(@aria-labelledby,'trancheEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[1]/td[3]//span/span";
	public String xpTChkpaymentinfo = "//table[contains(@aria-labelledby,'trancheEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[2]/td[10]/span";
	public String xpTChkpaymentinfo1 = "//table[contains(@aria-labelledby,'trancheEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[1]/td[10]//span";
	
	//Drawdown Partners
	public String xpDDPartnerstab = "//*[contains(@id,'drawdownEdit--DrawdownPartners-anchor-content')]";
	public String xpDDChksyndicate = "//table[contains(@aria-labelledby,'drawdownEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[1]/td[3]//span/span";
	public String xpDDChkpaymentinfo = "//table[contains(@aria-labelledby,'drawdownEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[2]/td[10]/span";
	public String xpDDChkpaymentinfo1 = "//table[contains(@aria-labelledby,'drawdownEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[1]/td[10]//span";

	// Syndication
	public String xpSyndicationtab = "//*[contains(@id,'dealEdit')]//*[text()='Syndication']";
	public String xpRole = "//label[@title='Role in the Syndication']/../following::div[position()=3]//input";
	public String xpMdtsyn = "//*[contains(@id,'dealEdit--SyndicationView')]//*[text()='Mandatory Syndication']/../following::div[position()=1]//input";
	public String xpSynamt = "//input[contains(@id,'dealEdit--SyndicationView')]";
	
	// Tranche Syndication
	public String xpTSyndicationtab = "//*[contains(@id,'TrancheEdit')]//*[text()='Syndication']";
	public String xpTRole = "//*[contains(@id,'trancheEdit--SyndicationView--idSyndicationHeader--Form--Grid')]//label[@title='Role in the Syndication']/following::span[position()=1]";
	public String xpTMdtsyn = "//*[text()='Mandatory Syndication']/../following::div[position()=1]//input";
	public String xpTSynamt = "//input[contains(@id,'trancheEdit--SyndicationView')]";

	// Rules
	public String xpPCruletab = "//*[text()='Rules']";
	public String xpRluse = "//table[contains(@aria-labelledby,'idPaymentControlRules--table-header')]/tbody/tr[1]/td[3]/span";
	public String xpRLPayer = "//table[contains(@aria-labelledby,'idPaymentControlRules--table-header')]/tbody/tr[1]/td[4]/a";

	
	//Tranche Rules
	public String xpTPCruletab = "//*[contains(@id,'trancheEdit--TranchePaymentRules-anchor-content')]";
	public String xpTRluse = "//table[contains(@aria-labelledby,'trancheEdit--PaymentRulesView--idPaymentControlRules--table-header')]/tbody/tr[1]/td[3]/span";
	public String xpTRLPayer = "//table[contains(@aria-labelledby,'trancheEdit--PaymentRulesView--idPaymentControlRules--table-header')]/tbody/tr[1]/td[4]/a";
	
	
	
	public String xptitle = "//h1[contains(@class,'HeadTitle')]";
	public String xpbtnSave = "//*[contains(@id,'idSaveDeal')]//*";
	public String xpReleasestatus = "//*[text()='Release Status:']/following::span[position()=1]";
	public String xpSubmittedstatus = "//header//*[text()='In Approval']";


	//Overview
	public String xpOverview="//*[contains(@id,'dealEdit--DealOverview-anchor-content')]";
	public String xpTraoverview="//*[contains(@id,'trancheEdit--TrancheOverview-anchor-content')]";
	
	//tranche drawdown
	public String xpDDRulestab="//*[contains(@id,'trancheEdit--TrancheDrawingRules-anchor-content')]";
	public String xpmaxdd="//div[contains(@id,'idGenDrawdownRules--Form--Grid')]//*[text()='Maximum Number of Drawdowns']/../following::input[3][contains(@class,'Inner')]";
	
	//DD Covenants
	
	public String xpDDCovenantstab = "//*[contains(@id,'drawdownEdit--DrawdownCovenants-anchor-content')]";
	public String xpDDrowCov = "//table[contains(@aria-labelledby,'dealEdit--CovenantView--covenantTable-header')]/tbody/tr[1]/td[3]";
	
	// Covenants
	public String xpDDCovtype = "//*[contains(text(),'Covenant Type')]/../following::div[position()=1]//input";
	public String xpDDDesc = "//*[contains(text(),'Description')]/../following::div[position()=1]//input";
	public String xpDDEOC = "//*[text()='End of Contractual Consequences']/../following::div[position()=1]//input";
	public String xpDDvalidFrom = "//*[contains(text(),'Valid From')]/../following::div[position()=1]//input";
	public String xpDDValidto = "//*[text()='Valid To']/../following::div[position()=1]//input";

	// Covenants Details
	public String xpDDDetailstab = "//*[contains(@id,'Edit--Details-anchor-inner')]";
	public String xpDDradioBank = "//div[contains(@id,'component---Edit--DetailsView--bank')]/div[not(contains(@class,'Inn'))]";
	public String xpDDCCP = "//*[text()='Covenant Check Procedure']/../following::div[position()=1]//input";
	public String xpDDSCThreshold = "//*[text()='Soft Covenant Threshold']/../following::div[position()=1]//input";
	public String xpDDHCThreshold = "//*[text()='Hard Covenant Threshold']/../following::div[position()=1]//input";
	public String xpDDFKdate = "//*[text()='First Key Date']/../following::div[position()=1]//span";
	public String xpDDCMP = "//*[text='Covenant Monitoring Procedure']/../following::div[position()=1]//input";
	public String xpDDCP = "//*[text()='Calculation Period']/../following::div[position()=1]//input";
	public String xpDDCPcmb = "//*[text()='Calculation Period']/../following::div[position()=7]//input";
	public String xpDDSubmissiondeadline = "//*[text()='Submission Deadline']/../following::div[position()=1]//input";
	public String xpDDSDCmb = "//*[text()='Submission Deadline']/following::div[position()=7]//input";

	// Covenant CC
	public String xpDDCCtab = "//*[contains(@id,'Edit--ContractualConsequences-anchor-content')]";

	// CC Add Lock

	public String xpDDCCType = "//*[contains(text(),'Consequence Type')]/following::div[position()=2]//input";
	public String xpDDCCusage = "//*[contains(text(),'Usage')]/following::div[position()=2]//input";
	public String xpDDCCOC = "//*[contains(text(),'Obligatory Consequence')]/following::div[position()=2]//input";
	public String xpDDCCLT = "//*[contains(text(),'Lock Type')]/following::div[position()=2]//input";
	public String xpDDCCIL = "//*[contains(text(),'Individual Lock')]/following::div[position()=2]//label";
	public String xpDDCCCL = "//*[contains(text(),'Collective Lock')]/following::div[position()=2]//input";
	public String xpDDCCVF = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Valid From')]/following::div[position()=2]//input";
	public String xpDDCCTerm = "//*[contains(text(),'Term')]/following::div[position()=2]//input";
	public String xpDDCCICAFlag = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Inherit Condition Adjustment')]/following::div[position()=2]//input";
	
	//DD Syndication

		public String xpDDSyndicationtab = "//*[contains(@id,'drawdownEdit--DrawdownSyndication-anchor-content')]";
		public String xpDDRole = "//*[contains(@id,'drawdownEdit--SyndicationView--idSyndicationHeader--Form--Grid')]//label[@title='Role in the Syndication']/following::span[position()=1]";
	
		
	//DD Rules
		public String xpDDPCruletab = "//*[contains(@id,'drawdownEdit--DrawdownPaymentRules-anchor-content')]";
		public String xpDDRluse = "//table[contains(@aria-labelledby,'drawdownEdit--PaymentRulesView--idPaymentControlRules--table-header')]/tbody/tr[1]/td[3]/span";
		public String xpDDRLPayer = "//table[contains(@aria-labelledby,'drawdownEdit--PaymentRulesView--idPaymentControlRules--table-header')]/tbody/tr[1]/td[4]/a";
				
	
		public String xpApplybtn = "//*[text()='Apply']";	
		public String xpSubmit="//footer[contains(@id,'footer')]//*[text()='Submit']";
	public String xpSubmitfinancing="//*[text()='Submit Financing']";

	public boolean Copy(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sShowlevel = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_SHOWLEVEL);
		String sET_BusinessPartners = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_BusinessPartners);
		String sET_ResponsibleAgents = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_ResponsibleAgents);
		String sET_SyndicationAgreements = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_SyndicationAgreements);
		String sET_Locks = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_Locks);
		String sET_PaymentControlRules = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_PaymentControlRules);
		String sET_Conditions = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_Conditions);
		String sET_DrawdownRules = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_DrawdownRules);
		String sET_Covenants = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_ET_Covenants);
		String sCopytext= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COPY_CopyText);
		String sTrancheName= ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewTranche, "REF_01",1);
		String sDrawdownName=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewDrawdown, "REF_01",1);
		String sMainBorrower = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01",2);
		String sProduct = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01",3);
		String sCommitmentDate = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01",4);
		String sStatus= ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01",5);
		String sLangauge = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01",6);
		String sConditiontype = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_CONDITIONSHEADER, "REF_01",1);
		String strancheConditiontype = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_TRACONDITIONSHEADER, "REF_01",1);
		String sValidfrom = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_CONDITIONSHEADER, "REF_01",2);
		String sPercentage = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_CONDITIONSHEADER, "REF_01",3);
		String sMinAmtPerDD=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",1);
		String sMinAmtPerDDVal=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",2);
		String sMaxAmtPerDD=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",3);
		String sMaxAmtPerDDVal=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",4);
		String sMultipleOf=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",5);
		String sMultipleOfVal=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",6);
		String sCurrency=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",7);
		String sPermAllProd=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",8);
		String sPermAllCurr=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",9);
		String sPermIntPeriod=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",10);
		String sFT=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",12);
		String sDDvalidfrom=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DRAWDOWNRULES, "REF_01",13);
		String sDealCovtype=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSHEADER, "REF_01",1);
		String sDealDescription=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSHEADER, "REF_01",2);
		String sDealEOC_Consequences=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSHEADER, "REF_01",3);
		String sDealValidFrom=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSHEADER, "REF_01",4);
		String sDealValidTo=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSHEADER, "REF_01",5);
		String sResultsupplier=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",1);
		String sChkproc=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",2);
		String sST=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",3);
		String sHT=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",4);
		String sFKDate=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",5);
		String sMP=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",6);
		String sCP=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",7);
		String sPT1=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",8);
		String sSD=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",9);
		String sPT2=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSDETAILS, "REF_01",10);
		String sCCType=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",1);
		String sCCUsage=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",2);
		String sCCOC=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",3);
		String sCCLT=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",4);
		String sCCIL=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",5);
		String sCCCL=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",6);
		String sCCVF=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",7);
		String sCCTerm=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",8);
		String sICAFlag=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_COVENANTSCC_ADDLOCK, "REF_01",9);
		String sPaymentinfo=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_PARTNERS, "REF_01",7);
		String sSynrole=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_SYNDICATION, "REF_01",2);
		String sSynMandatory=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_SYNDICATION, "REF_01",3);
		String sSyvalue=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_SYNDICATION, "REF_01",4);
		String sTSyvalue=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_TRASYNDICATION, "REF_01",4);
		String sRLUse=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_PCR, "REF_01",2);
		String sRLPayer=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_PCR, "REF_01",4);
		String sFinancestatus = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_OverView_Main, "REF_01",2);
		String sSubmittedstatus = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_OverView_Main, "REF_01",4);

		String sTMainBorrower = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewTranche, "REF_01",2);
		String sTProduct = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewTranche, "REF_01",3);
		String sTAmt = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewTranche, "REF_01",4);
		String sTSTerm= ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewTranche, "REF_01",6);
		String sTETerm = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewTranche, "REF_01",8);
		
		String sTPercentage = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_TRACONDITIONSHEADER, "REF_01",3);
		
		String sTnumofDD=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_TraDrawdown, "REF_01",18);

		String sDDProduct = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewDrawdown, "REF_01",3);
		String sDDAmt = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewDrawdown, "REF_01",4);
		String sDDSTerm= ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewDrawdown, "REF_01",7);
		String sDDETerm = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NewDrawdown, "REF_01",9);
		
		String sDDconditions =ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_EditDraConditions, "REF_01",1);
		try {
			lowlevellogsobj.info("Started in Copy Class");
			Thread.sleep(3000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpConditionstype)));
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMore)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpMore, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSCF)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSCF, "Yes");
			lowlevellogsobj.info("Clicked on Copy link Button");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCopytable)));
			commfunct_Obj.comboSelect(driver, sShowlevel, cmbShowlevel);
			commfunct_Obj.waitUntilDocumentIsReady(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSelectdrawdown)));
			Thread.sleep(2000);
			//commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSelectdrawdown, "Yes");
			commfunct_Obj.commonClick(chkDDlevel, "Yes");
			lowlevellogsobj.info("Clicked on Drawdown level checkbox");
			Thread.sleep(2000);

			//Business Partners
			if(sET_BusinessPartners.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkBP, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Business Partner is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkBusinesspartners, "Yes");
					lowlevellogsobj.info("Business Partner is checked");
				}
			}else{
				commfunct_Obj.commonClick(chkBusinesspartners, "Yes");
				lowlevellogsobj.info("Business Partner is unchecked");
			}

			//Responsible Agents
			if(sET_ResponsibleAgents.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkRA, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Responsible Agent is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkResponsibleagents, "Yes");
					lowlevellogsobj.info("Responsible Agent is checked");
				}
			}else{
				commfunct_Obj.commonClick(chkResponsibleagents, "Yes");
				lowlevellogsobj.info("Responsible Agent is unchecked");
			}

			//Syndication Agreements
			if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkSA, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Syndication Agreements is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkSyndicationagreements, "Yes");
					lowlevellogsobj.info("Syndication Agreements is checked");
				}
			}else{
				commfunct_Obj.commonClick(chkSyndicationagreements, "Yes");
				lowlevellogsobj.info("Syndication Agreements is unchecked");
			}

			//Locks
			if(sET_Locks.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkLcks, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Locks is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkLocks, "Yes");
					lowlevellogsobj.info("Locks is checked");
				}
			}else{
				commfunct_Obj.commonClick(chkLocks, "Yes");
				lowlevellogsobj.info("Locks is unchecked");
			}

			//Payment Control Rules
			if(sET_PaymentControlRules.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkPCR, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Payment Control Rules is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkPCR, "Yes");
					lowlevellogsobj.info("Payment Control Rules is checked");
				}
			}else{
				commfunct_Obj.commonClick(chkPCR, "Yes");
				lowlevellogsobj.info("Payment Control Rules is unchecked");
			}

			//Conditions
			if(sET_Conditions.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkCnd, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Conditions is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkConditions, "Yes");
					lowlevellogsobj.info("Conditions is checked");			

				}
			}else{
				commfunct_Obj.commonClick(chkConditions, "Yes");
				lowlevellogsobj.info("Conditions is unchecked");
			}

			//Drawdown Rules
			if(sET_DrawdownRules.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkDDR, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Drawdown Rules is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkDrawdownrules, "Yes");
					lowlevellogsobj.info("Drawdown Rules is checked");			

				}
			}else{
				commfunct_Obj.commonClick(chkDrawdownrules, "Yes");
				lowlevellogsobj.info("Drawdown Rules is unchecked");
			}

			//Covenants
			if(sET_DrawdownRules.equalsIgnoreCase("Yes")){
				String temp = commfunct_Obj.commonFindElement_GetAttribute(driver, "xpath", xpchkCov, "checked");
				if(temp.equalsIgnoreCase("true")){
					lowlevellogsobj.info("Covenants is checked by default");
				}
				else{
					commfunct_Obj.commonClick(chkCovenants, "Yes");
					lowlevellogsobj.info("Covenants is checked");			

				}
			}else{
				commfunct_Obj.commonClick(chkCovenants, "Yes");
				lowlevellogsobj.info("Covenants is unchecked");
			}

			//Click on Copy button
			commfunct_Obj.commonClick(btnCopy, "Yes");
			
			Appcommfunct_Obj.checkSavemessage(driver, Constants.CopyFinance);
			Thread.sleep(2000);
			//Verify Overview Page
			wait.until(ExpectedConditions.visibilityOf(cmbSlctlevel));
			if(sShowlevel.length()>0){
				commfunct_Obj.comboSelect(driver, sShowlevel, cmbSlctlevel);
				lowlevellogsobj.info("Level is selected as ->" + sShowlevel);
			}
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(linkDD));
			if(!sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
				result1=commfunct_Obj.expectedlabelValue(lblCreate, "text", sCopytext, "Yes");
				result1=commfunct_Obj.expectedValue(linkTranche, "text", sTrancheName, "Yes");
				result1=commfunct_Obj.expectedValue(linkDD, "text", sDrawdownName, "Yes");
			}
			else{
				result1=commfunct_Obj.expectedlabelValue(lblCreate, "text", sCopytext, "Yes");
				result1=commfunct_Obj.expectedValue(linkTranche1, "text", sTrancheName, "Yes");
				result1=commfunct_Obj.expectedValue(linkDD1, "text", sDrawdownName, "Yes");
			}
			if(result1==true){
				lowlevellogsobj.info("Copied Overview(Deal Level) page is Matching with Source");
			}
			else{
				lowlevellogsobj.info("Copied Overview(Deal Level) page is NOT Matching with Source");
			}


			//Deal Level
			//Verify Details Page
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDtlstab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMB)));
			Thread.sleep(3000);
			result1=commfunct_Obj.compareValue(driver, xpMB, "Main Borrower", sMainBorrower);
			result1=commfunct_Obj.compareValue(driver, xpProduct, "Product", sProduct);
			result1=commfunct_Obj.compareValue(driver, xpCD, "Commitment date", sCommitmentDate);
			result1=commfunct_Obj.expectedlabelValue(lblStatus, "text", sStatus, "Yes");
			//	result1=commfunct_Obj.compareValue(driver, xpStatus, "Status", sStatus);
			result1=commfunct_Obj.compareValue(driver, xpdtlsLangauge, "Langauge", sLangauge);

			if(result1==true){
				lowlevellogsobj.info("Details(Deal Level) page is Matching with Source");
			}
			else{
				lowlevellogsobj.error("Details(Deal Level) page is NOT Matching with Source");
			}

			//Conditions tab
			if(sET_Conditions.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpConditionstab, "Yes");
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddcondition)));
				result1=commfunct_Obj.expectedlabelValue(lblConditiontype, "text", sConditiontype, "Yes");
				result1=commfunct_Obj.expectedlabelValue(lblValidfrom, "text", sValidfrom, "Yes");
				//result1=commfunct_Obj.expectedlabelValue(lblPercentage, "text", sPercentage, "Yes");


				if(result1==true){
					lowlevellogsobj.info("Conditions(Deal Level) page is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Conditions(Deal Level) page is NOT Matching with Source");
				}
			}
			else{

			}

			//Drawdown Rules
			if(sET_DrawdownRules.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", ddrules.xpDDRulestab, "Yes");

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(ddrules.xptxt_MinAmtval)));

				if(driver.findElement(By.xpath(ddrules.xpradbtn_MinAmtPerDD)).isSelected() && sMinAmtPerDD.equals("Amount")){
					lowlevellogsobj.info("Amount Radio is selected for Minimum Amount per Drawdown and Matching with source");
					result1=commfunct_Obj.compareValue(driver, ddrules.xptxt_MinAmtval, "Minimum Amount Value", sMinAmtPerDDVal);

				}
				else {
					lowlevellogsobj.info("Not restriced is selected for Minimum Amount per Drawdown and Matching with source");

				}


				if(driver.findElement(By.xpath(ddrules.xpradbtn_MaxAmtPerDD)).isSelected() && sMaxAmtPerDD.equals("Amount")){
					lowlevellogsobj.info("Amount Radio is selected for Maximum Amount per Drawdown and Matching with source");
					result1=commfunct_Obj.compareValue(driver, ddrules.xptxt_MaxAmtPerDDVal, "Minimum Amount Value", sMaxAmtPerDDVal);

				}
				else {
					lowlevellogsobj.info("Not restriced is selected for Maximum Amount per Drawdown and Matching with source");

				}
				if(driver.findElement(By.xpath(ddrules.xpradbtn_MultipleOf)).isSelected() && sMultipleOf.equals("Amount")){
					lowlevellogsobj.info("Amount Radio is selected for Maximum Amount per Drawdown and Matching with source");
					result1=commfunct_Obj.compareValue(driver, ddrules.xptxt_Multipleof, "Minimum Amount Value", sMultipleOfVal);

				}
				else {
					lowlevellogsobj.info("Not restriced is selected for Maximum Amount per Drawdown and Matching with source");

				}

				Thread.sleep(3000);

				String allProducts = driver.findElement(By.xpath(ddrules.xpsldr_PermAllProd)).getAttribute("class");
				if(allProducts.contains("On") && sPermAllProd.equalsIgnoreCase("Yes")){
					lowlevellogsobj.info("All products option is On and Matching with source");
					result1=true;
				}
				else{
					lowlevellogsobj.info("All products option is Off and Matching with source");
					result1=true;
				}


				String allCurr= driver.findElement(By.xpath(ddrules.xpsldr_PermAllCurr)).getAttribute("class");
				if(allCurr.contains("On") && sPermAllCurr.equalsIgnoreCase("Yes")){
					lowlevellogsobj.info("All Currencies option is On and Matching with source");
					result1=true;
				}
				else{
					lowlevellogsobj.info("All Currencies option is Off and Matching with source");
					result1=true;
				}

				String allIP= driver.findElement(By.xpath(ddrules.xpsldr_PermIntPeriod)).getAttribute("class");
				if(allIP.contains("On") && sPermIntPeriod.equalsIgnoreCase("Yes")){
					lowlevellogsobj.info("Permitted Interest Period option is On and Matching with source");
					result1=true;
				}
				else{
					lowlevellogsobj.info("Permitted Interest Period is Off and Matching with source");
					result1=true;
				}


				WebElement ele = driver.findElement(By.xpath(ddrules.xpbtnFTAdd));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
				Thread.sleep(500);

				WebElement FT = driver.findElement(By.xpath(xpFTTablecol));
				WebElement vFrom = driver.findElement(By.xpath(xpFTTablevalidfrom));
				result1=commfunct_Obj.expectedValue(FT, "text", sFT, "Yes");
				//result1=commfunct_Obj.expectedValue(vFrom, "text", sDDvalidfrom, "Yes");

				if(result1==true){
					lowlevellogsobj.info("Drawdown(Deal Level) page is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Drawdown(Deal Level) page is NOT Matching with Source");
				}
			}
			else{
				lowlevellogsobj.info("Drawdown Flag is off in the data sheet");
			}

			//Covenants Header
			if(sET_Covenants.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCovenantstab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCovenantstab, "Yes");
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xprowCov)));
				commfunct_Obj.commonClick(rowCov, "Yes");
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCovtype)));

				commfunct_Obj.compareValue(driver, xpCovtype, "Covenant Type",sDealCovtype);
				commfunct_Obj.compareValue(driver, xpDesc, "Description",sDealDescription);
				commfunct_Obj.compareValue(driver, xpEOC, "End of Contractual Consequences",sDealEOC_Consequences);
				commfunct_Obj.compareValue(driver, xpvalidFrom, "Valid From",sDealValidFrom);
				commfunct_Obj.compareValue(driver, xpValidto, "Valid To",sDealValidTo);

				//Covenant Details
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDetailstab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDetailstab, "Yes");
				Thread.sleep(3000);


				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioBank)));

				if(radioBorrower.isSelected() && sResultsupplier.equalsIgnoreCase("Borrower")){
					lowlevellogsobj.info("Borrower is selected and Matching with the source");
					result1=true;
				}
				else{
					lowlevellogsobj.error("Bank is selected and Matching with the source");
					result1=true;
				}

				result1=commfunct_Obj.compareValue(driver, xpCCP, "Covenant Check Procedure",sChkproc);
				String softThreshold = commfunct_Obj.convertodecimal(sST);
				result1=commfunct_Obj.compareValue(driver, xpSCThreshold, "Soft Covenant Threshold",softThreshold);
				String HardThreshold = commfunct_Obj.convertodecimal(sHT);
				result1=commfunct_Obj.compareValue(driver, xpHCThreshold, "Hard Covenant Threshold",HardThreshold);
				result1=commfunct_Obj.expectedlabelValue(txtFKdate, "text", sFKDate, "Yes");
				result1=commfunct_Obj.expectedlabelValue(cmbCMP, "text", sMP, "Yes");
				result1=commfunct_Obj.compareValue(driver, xpCP, "Calculation Period",sCP);
				result1=commfunct_Obj.compareValue(driver, xpCPcmb, "Calculation Period Type",sPT1);
				result1=commfunct_Obj.compareValue(driver, xpSubmissiondeadline, "Submission Deadline",sSD);
				result1=commfunct_Obj.compareValue(driver, xpSDCmb, "Submission Deadline Type",sPT2);

				//Covenant Contractual Consequences

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCCtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCCtab, "Yes");
				wait.until(ExpectedConditions.visibilityOf(linkcovenantCC));
				commfunct_Obj.commonClick(linkcovenantCC, "Yes");
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCCType)));
				result1=commfunct_Obj.compareValue(driver, xpCCType, "Type",sCCType);
				result1=commfunct_Obj.compareValue(driver, xpCCusage, "Usage",sCCUsage);
				result1=commfunct_Obj.compareValue(driver, xpCCOC, "ObligatoryConsequence",sCCOC);
				result1=commfunct_Obj.compareValue(driver, xpCCLT, "LockType",sCCLT);
				result1=commfunct_Obj.expectedlabelValue(cmbIL, "text", sCCIL, "Yes");			
				result1=commfunct_Obj.compareValue(driver, xpCCVF, "ValidFrom",sCCVF);
				result1=commfunct_Obj.compareValue(driver, xpCCTerm, "Term",sCCTerm);
				
				commfunct_Obj.commonClick(btnBack, "Yes");
				wait.until(ExpectedConditions.visibilityOf(btnBack));
				commfunct_Obj.commonClick(btnBack, "Yes");
				wait.until(ExpectedConditions.visibilityOf(btnBack));
				Thread.sleep(1000);

				if(result1==true){
					lowlevellogsobj.info("Covenant page is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Covenant page is NOT Matching with Source");
				} 

			}
			else{
				lowlevellogsobj.info("Covenant Flag is Off in the data sheet");
			}

			
			
			
			//Partners
			if(sET_BusinessPartners.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPartnerstab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPartnerstab, "Yes");
				Thread.sleep(3000);
				if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
					String getRole=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpChksyndicate);
					if(getRole.equalsIgnoreCase("Syndicate Manager")){
						lowlevellogsobj.info("Syndicate Manager row exist and matching with source");
						result1=true;
						String getpaymtInfo=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpChkpaymentinfo);
						if(getpaymtInfo.equalsIgnoreCase(sPaymentinfo)){
							result1=true;
							lowlevellogsobj.info("Payment info is matching");
						}
						else{
							lowlevellogsobj.error("Payment info is NOT matching");
							result1=false;
						}
					}

					else{
						lowlevellogsobj.error("Syndicate Manager row doesn't exist");
						result1=false;
					}
				}



				else{
					lowlevellogsobj.info("Syndicate Agreement flag is turned off in data sheets");
					String getpaymtInfo=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpChkpaymentinfo1);
					if(getpaymtInfo.equalsIgnoreCase(sPaymentinfo)){
						result1=true;
						lowlevellogsobj.info("Payment info is matching");

					}
					else{
						lowlevellogsobj.error("Payment info is NOT matching");
						result1=false;

					}



					if(result1==true){
						lowlevellogsobj.info("Partners tab is Matching with Source");
					}
					else{
						lowlevellogsobj.error("Partners tab is NOT Matching with Source");
					} 


				}
			}
			else{
				lowlevellogsobj.error("Partners Flag is Off in the data sheet");
			}

			//Syndication
			if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSyndicationtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSyndicationtab, "Yes");
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(cmbRole));
				result1=commfunct_Obj.compareValue(driver, xpRole, "Syndication Role", sSynrole);
				result1=commfunct_Obj.compareValue(driver, xpMdtsyn, "Mandatory Syndication", sSynMandatory);
				/*ommfunct_Obj.expectedValue(cmbRole, "text", sSynrole, "Yes");
					commfunct_Obj.expectedValue(cmbMndsyndication, "text", sSynMandatory, "Yes");*/
				String synValue = txtAmnt.getAttribute("value");
				System.out.println("Deal Syndication Amount Excel->"+sTSyvalue);
				System.out.println("Deal Syndication Amount App->"+synValue);
				if(synValue.equalsIgnoreCase(sSyvalue)){
					lowlevellogsobj.info("Syndication ratio is Matching with Source");
					result1=true;
				}else{
					lowlevellogsobj.error("Syndication ratio is NOT Matching with Source");
					result1=false;
				}

				if(result1==true){
					lowlevellogsobj.info("Syndication tab is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Syndication tab is NOT Matching with Source");
				} 
			}
			else{
				lowlevellogsobj.info("Syndication flag is off in the data sheet");
			}

			//Payment Control Rules
			if(sET_PaymentControlRules.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPCruletab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPCruletab, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpRluse)));
				String getUsage=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpRluse);
				if(getUsage.equalsIgnoreCase(sRLUse)){
					lowlevellogsobj.info("Rules Tab -Usage is Matching with Source");
					result1=true;
				}
				else{
					lowlevellogsobj.error("Rules Tab -Usage is NOT Matching with Source");
					result1=false;
				}


				if(result1==true){
					lowlevellogsobj.info("Rules tab is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Rules tab is NOT Matching with Source");
				} 
			}
			else{
				lowlevellogsobj.info("Rules flag is off in the data sheet");
			}



			//Back to Overview Page


			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOverview)));
			commfunct_Obj.commonClick(tabOverview, "Yes");
			Thread.sleep(2000);
			if(!sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonClick(linkTranche, "Yes");
				lowlevellogsobj.info("Clicked on Tranche link");
			}
			else{
				commfunct_Obj.commonClick(linkTranche1, "Yes");
				lowlevellogsobj.info("Clicked on Tranche link");
			}
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTrachedtlstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpTrachedtlstab, "Yes");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTMB )));
			
			result1=commfunct_Obj.expectedlabelValue(TranchePrd, "text", sTProduct , "Yes");
			if(result1==true){
				lowlevellogsobj.info("Product at Tranche level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Product at Tranche level is NOT matching with Source");
			}
			result1=commfunct_Obj.compareValue(driver, xpTAMT , "Tranche Amount", sTAmt );
			if(result1==true){
				lowlevellogsobj.info("Amount at Tranche level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Amount at Tranche level is NOT matching with Source");
			}
			result1=commfunct_Obj.compareValue(driver, xpTStartdate , "Start of Term", sTSTerm);
			if(result1==true){
				lowlevellogsobj.info("Start of Term at Tranche level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Start of Term at Tranche level is NOT matching with Source");
			}
			result1=commfunct_Obj.compareValue(driver, xpTEndterm , "Commitment date", sTETerm );
			if(result1==true){
				lowlevellogsobj.info("Commitment date at Tranche level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Commitment date at Tranche level is NOT matching with Source");
			}

			if(result1==true){
				lowlevellogsobj.info("Details(Tranche Level) page is Matching with Source");
			}
			else{
				lowlevellogsobj.error("Details(Tranche Level) page is NOT Matching with Source");
			}


			//Conditions
			if(sET_Conditions.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xptrancheConditionstab, "Yes");
				Thread.sleep(5000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddcondition)));
				result1=commfunct_Obj.expectedlabelValue(lbltrancheConditiontype, "text", strancheConditiontype, "Yes");
				if(result1==true){
					lowlevellogsobj.info("Condition Type at Tranche level is matching with Source");
				}
				else{
					lowlevellogsobj.error("Condition Type at Tranche level is NOT matching with Source");
				}
				result1=commfunct_Obj.expectedlabelValue(lbltrancheValidfrom, "text", sValidfrom, "Yes");
				if(result1==true){
					lowlevellogsobj.info("Valid From at Tranche level is matching with Source");
				}
				else{
					lowlevellogsobj.error("Valid From at Tranche level is NOT matching with Source");
				}

				sPercentage = sPercentage+"% ";
				result1=commfunct_Obj.expectedlabelValue(lbltranchePercentage, "text", sTPercentage, "Yes");
				if(result1==true){
					lowlevellogsobj.info("Percentage at Tranche level is matching with Source");
				}
				else{
					lowlevellogsobj.error("Percentage at Tranche level is NOT matching with Source");
				}

				if(result1==true){
					lowlevellogsobj.info("Conditions(Tranche Level) page is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Conditions(Tranche Level) page is NOT Matching with Source");
				}

			}
			

			//Drawdown at tranche
			if(sET_DrawdownRules.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDRulestab, "Yes");
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpmaxdd)));
				result1=commfunct_Obj.compareValue(driver, xpmaxdd, "Number of Drawdowns", sTnumofDD );
				if(result1==true){
					lowlevellogsobj.info("Maximum number of drawdown at Tranche level is matching with Source");
				}
				else{
					lowlevellogsobj.error("Maximum number of drawdown at Tranche level is NOT matching with Source");
				}
			}
			
			//Partners
			if(sET_BusinessPartners.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpTPartnerstab, "Yes");
				Thread.sleep(3000);
				if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
					String getRole=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpTChksyndicate);
					if(getRole.equalsIgnoreCase("Syndicate Manager")){
						lowlevellogsobj.info("Syndicate Manager row exist and matching with source");
						result1=true;
						String getpaymtInfo=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpTChkpaymentinfo);
						if(getpaymtInfo.equalsIgnoreCase(sPaymentinfo)){
							result1=true;
							lowlevellogsobj.info("Payment info is matching");
						}
						else{
							lowlevellogsobj.error("Payment info is NOT matching");
							result1=false;
						}
					}

					else{
						lowlevellogsobj.error("Syndicate Manager row doesn't exist");
						result1=false;
					}
				}



				else{
					lowlevellogsobj.info("Syndicate Agreement flag is turned off in data sheets");
					String getpaymtInfo=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpTChkpaymentinfo1);
					if(getpaymtInfo.equalsIgnoreCase(sPaymentinfo)){
						result1=true;
						lowlevellogsobj.info("Payment info is matching");

					}
					else{
						lowlevellogsobj.error("Payment info is NOT matching");
						result1=false;

					}

				


				}
				if(result1==true){
					lowlevellogsobj.info("Partners tab at Tranche Level is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Partners tab at Tranche Level is NOT Matching with Source");
				} 
				}
			
			else{
				lowlevellogsobj.error("Partners Flag is Off in the data sheet");
			}
			
		
			//Tranche Syndication
			if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTSyndicationtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpTSyndicationtab, "Yes");
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(cmbTRole));
				result1=commfunct_Obj.expectedlabelValue(trancheSyndrole, "text", sSynrole, "Yes");
				result1=commfunct_Obj.compareValue(driver, xpTMdtsyn, "Mandatory Syndication", sSynMandatory);
				/*ommfunct_Obj.expectedValue(cmbRole, "text", sSynrole, "Yes");
					commfunct_Obj.expectedValue(cmbMndsyndication, "text", sSynMandatory, "Yes");*/
				String synValue = txtTAmnt.getAttribute("value");
				System.out.println("Tranche Syndication Amount Excel->"+sTSyvalue);
				System.out.println("Tranche Syndication Amount App->"+synValue);
				if(synValue.equalsIgnoreCase(sTSyvalue)){
					lowlevellogsobj.info("Syndication ratio at tranche level is Matching with Source");
					result1=true;
				}else{
					lowlevellogsobj.error("Syndication ratio at tranche level is NOT Matching with Source");
					result1=false;
				}

				if(result1==true){
					lowlevellogsobj.info("Syndication tab is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Syndication tab is NOT Matching with Source");
				} 
			}
			else{
				lowlevellogsobj.info("Syndication flag is off in the data sheet");
			}

			//Tranche Rules Tab
		
			if(sET_PaymentControlRules.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTPCruletab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpTPCruletab, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTRluse)));
				String getUsage=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpTRluse);
				if(getUsage.equalsIgnoreCase(sRLUse)){
					lowlevellogsobj.info("Rules Tab -Usage is Matching with Source");
					result1=true;
				}
				else{
					lowlevellogsobj.error("Rules Tab -Usage is NOT Matching with Source");
					result1=false;
				}


				if(result1==true){
					lowlevellogsobj.info("Rules tab is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Rules tab is NOT Matching with Source");
				} 
			}
			else{
				lowlevellogsobj.info("Rules flag is off in the data sheet");
			}

			//Back to overview page and click on Autodrawdown
			
			
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpTraoverview, "Yes");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.visibilityOf(linkDDTranche1));
			commfunct_Obj.commonClick(linkDDTranche1, "Yes");
			lowlevellogsobj.info("Clicked on Drawdown link from Tranche level");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDtlstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDtlstab, "Yes");
			Thread.sleep(3000);
			
			result1=commfunct_Obj.expectedlabelValue(DDPrd, "text", sDDProduct , "Yes");
			if(result1==true){
				lowlevellogsobj.info("Product at Drawdown level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Product at Drawdown level is NOT matching with Source");
			}
			result1=commfunct_Obj.compareValue(driver, xpDDAMT , "Tranche Amount", sDDAmt );
			if(result1==true){
				lowlevellogsobj.info("Amount at Drawdown level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Amount at Drawdown level is NOT matching with Source");
			}
			result1=commfunct_Obj.compareValue(driver, xpDDStartdate , "Start of Term", sDDSTerm);
			if(result1==true){
				lowlevellogsobj.info("Start of Term at Drawdown level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Start of Term at Drawdown level is NOT matching with Source");
			}
			result1=commfunct_Obj.compareValue(driver, xpDDEndterm , "Commitment date", sDDETerm );
			if(result1==true){
				lowlevellogsobj.info("Commitment date at Drawdown level is matching with Source");
			}
			else{
				lowlevellogsobj.error("Commitment date at Drawdown level is NOT matching with Source");
			}

			if(result1==true){
				lowlevellogsobj.info("Details(Drawdown Level) page is Matching with Source");
			}
			else{
				lowlevellogsobj.error("Details(Drawdown Level) page is NOT Matching with Source");
			}

			
			//Conditions
			if(sET_Conditions.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDConditionstab, "Yes");
				Thread.sleep(2000);
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 30, screenloader);
				
				
				String [] temp = sDDconditions.split("\\|");
				int totalRows=driver.findElements(By.xpath("//table[contains(@aria-labelledby,'drawdownEdit--ConditionView--conditionTable-header')]/tbody/tr")).size();
				
				for(int i=0;i<totalRows-1;i++){
					WebElement ele = driver.findElement(By.xpath("//table[contains(@aria-labelledby,'drawdownEdit--ConditionView--conditionTable-header')]/tbody/tr["+(i+1)+"]/td[3]//span/span"));
					String actcondType=ele.getText();
					if(actcondType.equalsIgnoreCase(temp[i])){
						lowlevellogsobj.info(""+temp[i]+" condition type is present and is Matching with Source");
					}
					else{
						lowlevellogsobj.info(""+temp[i]+" condition type is not present and is Matching with Source");
					}
				}
				
				
				
			}
			else{
				lowlevellogsobj.info("Condition Flag is off in test data sheet");
			}
			
			
			// Drawdown Covenants Header
			if(sET_Covenants.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDCovenantstab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDCovenantstab, "Yes");
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDrowCov)));
				commfunct_Obj.commonClick(DDrowCov, "Yes");
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDCovtype)));

				commfunct_Obj.compareValue(driver, xpDDCovtype, "Covenant Type",sDealCovtype);
				commfunct_Obj.compareValue(driver, xpDDDesc, "Description",sDealDescription);
				commfunct_Obj.compareValue(driver, xpDDEOC, "End of Contractual Consequences",sDealEOC_Consequences);
				commfunct_Obj.compareValue(driver, xpDDvalidFrom, "Valid From",sDealValidFrom);
				commfunct_Obj.compareValue(driver, xpDDValidto, "Valid To",sDealValidTo);

				//Covenant Details
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDDetailstab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDDetailstab, "Yes");
				Thread.sleep(3000);


				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDradioBank)));

				if(DDradioBorrower.isSelected() && sResultsupplier.equalsIgnoreCase("Borrower")){
					lowlevellogsobj.info("Borrower is selected and Matching with the source");
					result1=true;
				}
				else{
					lowlevellogsobj.error("Bank is selected and Matching with the source");
					result1=true;
				}

				result1=commfunct_Obj.compareValue(driver, xpDDCCP, "Covenant Check Procedure",sChkproc);
				String softThreshold = commfunct_Obj.convertodecimal(sST);
				result1=commfunct_Obj.compareValue(driver, xpDDSCThreshold, "Soft Covenant Threshold",softThreshold);
				String HardThreshold = commfunct_Obj.convertodecimal(sHT);
				result1=commfunct_Obj.compareValue(driver, xpDDHCThreshold, "Hard Covenant Threshold",HardThreshold);
				result1=commfunct_Obj.expectedlabelValue(txtFKdate, "text", sFKDate, "Yes");
				result1=commfunct_Obj.expectedlabelValue(cmbCMP, "text", sMP, "Yes");
				result1=commfunct_Obj.compareValue(driver, xpDDCP, "Calculation Period",sCP);
				result1=commfunct_Obj.compareValue(driver, xpDDCPcmb, "Calculation Period Type",sPT1);
				result1=commfunct_Obj.compareValue(driver, xpDDSubmissiondeadline, "Submission Deadline",sSD);
				result1=commfunct_Obj.compareValue(driver, xpDDSDCmb, "Submission Deadline Type",sPT2);

				//Covenant Contractual Consequences

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDCCtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDCCtab, "Yes");
				wait.until(ExpectedConditions.visibilityOf(linkcovenantCC));
				commfunct_Obj.commonClick(linkcovenantCC, "Yes");
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDCCType)));
				result1=commfunct_Obj.compareValue(driver, xpDDCCType, "Type",sCCType);
				result1=commfunct_Obj.compareValue(driver, xpDDCCusage, "Usage",sCCUsage);
				result1=commfunct_Obj.compareValue(driver, xpDDCCOC, "ObligatoryConsequence",sCCOC);
				result1=commfunct_Obj.compareValue(driver, xpDDCCLT, "LockType",sCCLT);
				result1=commfunct_Obj.expectedlabelValue(cmbIL, "text", sCCIL, "Yes");			
				result1=commfunct_Obj.compareValue(driver, xpDDCCVF, "ValidFrom",sCCVF);
				result1=commfunct_Obj.compareValue(driver, xpDDCCTerm, "Term",sCCTerm);
				
				commfunct_Obj.commonClick(btnBack, "Yes");
				wait.until(ExpectedConditions.visibilityOf(btnBack));
				commfunct_Obj.commonClick(btnBack, "Yes");
				wait.until(ExpectedConditions.visibilityOf(btnBack));
				Thread.sleep(1000);

				if(result1==true){
					lowlevellogsobj.info("Covenant page is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Covenant page is NOT Matching with Source");
				} 

			}
			else{
				lowlevellogsobj.info("Covenant Flag is Off in the data sheet");
			}
			
			//DDPartners
			if(sET_BusinessPartners.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDPartnerstab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDPartnerstab, "Yes");
				Thread.sleep(3000);
				if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
					String getRole=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpDDChksyndicate);
					if(getRole.equalsIgnoreCase("Syndicate Manager")){
						lowlevellogsobj.info("Syndicate Manager row exist and matching with source");
						result1=true;
						String getpaymtInfo=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpDDChkpaymentinfo);
						if(getpaymtInfo.equalsIgnoreCase(sPaymentinfo)){
							result1=true;
							lowlevellogsobj.info("Payment info is matching");
						}
						else{
							lowlevellogsobj.error("Payment info is NOT matching");
							result1=false;
						}
					}

					else{
						lowlevellogsobj.error("Syndicate Manager row doesn't exist");
						result1=false;
					}
				}



				else{
					lowlevellogsobj.info("Syndicate Agreement flag is turned off in data sheets");
					String getpaymtInfo=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpDDChkpaymentinfo1);
					if(getpaymtInfo.equalsIgnoreCase(sPaymentinfo)){
						result1=true;
						lowlevellogsobj.info("Payment info is matching");

					}
					else{
						lowlevellogsobj.error("Payment info is NOT matching");
						result1=false;

					}



					if(result1==true){
						lowlevellogsobj.info("Partners tab is Matching with Source");
					}
					else{
						lowlevellogsobj.error("Partners tab is NOT Matching with Source");
					} 


				}
			}
			else{
				lowlevellogsobj.error("Partners Flag is Off in the data sheet");
			}
			
			//DD Syndication
			if(sET_SyndicationAgreements.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDSyndicationtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDSyndicationtab, "Yes");
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(DDSyndrole));
				result1=commfunct_Obj.expectedlabelValue(DDSyndrole, "text", sSynrole, "Yes");
				if(result1==true){
					lowlevellogsobj.info("Syndication tab(Drawdown level) is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Syndication tab(Drawdown level) is NOT Matching with Source");
				} 
			}
			else{
				lowlevellogsobj.info("Syndication flag is off in the data sheet");
			}

			//DD Rules Tab
		
			if(sET_PaymentControlRules.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDPCruletab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDDPCruletab, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDDRluse)));
				String getUsage=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpDDRluse);
				if(getUsage.equalsIgnoreCase(sRLUse)){
					lowlevellogsobj.info("Rules Tab - Usage(DD level) is Matching with Source");
					result1=true;
				}
				else{
					lowlevellogsobj.error("Rules Tab - Usage(DD level)is NOT Matching with Source");
					result1=false;
				}


				if(result1==true){
					lowlevellogsobj.info("Rules tab(DD level) is Matching with Source");
				}
				else{
					lowlevellogsobj.error("Rules tab(DD level) is NOT Matching with Source");
				} 
			}
			else{
				lowlevellogsobj.info("Rules flag is off in the data sheet");
			}
			
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpApplybtn)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpApplybtn, "Yes");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpApplybtn)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpApplybtn, "Yes");
			Thread.sleep(2000);
			
			
			//Save and Submit
			commfunct_Obj.commonClick(btn_Save, "Yes");
			lowlevellogsobj.info("Footer Save button is clicked");
			
			Appcommfunct_Obj.checkSavemessage(driver, Constants.saveFinancemsg);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReleasestatus)));
			commfunct_Obj.expectedValue(labelFinancestatus, "text", sFinancestatus, "Yes");
			lowlevellogsobj.info("Release status is ->" + sFinancestatus);

			//Submit
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmit)));
			commfunct_Obj.commonClick(btnSubmit, "Yes");
			Thread.sleep(2000);
			lowlevellogsobj.info("Submit button in Overview Page is clicked");
			if(driver.findElements(By.xpath(xpSubmitfinancing)).size()==1){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSubmitfinancing, "Yes");
							
			}
			Appcommfunct_Obj.checkSavemessage(driver, Constants.submitFinancemsg);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmittedstatus)));
			commfunct_Obj.expectedValue(labelFinancestatus, "text", sSubmittedstatus, "Yes");
			lowlevellogsobj.info("Release status (After Submit) is ->" + sSubmittedstatus);

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}

}
