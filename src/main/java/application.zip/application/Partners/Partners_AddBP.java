/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Partners;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class Partners_AddBP {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions acf_Obj = new Application_Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Partners_AddBP.class);

	public Partners_AddBP(WebDriver driver) {
	}

	@FindBy(xpath = "//span[text()='Business Partners']")
	private WebElement title_partner;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'dealEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[1]/td[2]//div[contains(@id,'selectMulti-CbBg')]")
	private WebElement radiobtnBProle;

	@FindBy(xpath = "//div[contains(@id,'dealEdit--PartnersView--tableForBusinessPartners--table-header')]/following::button[position()=1]")
	private WebElement btnEdit;

	@FindBy(xpath = "//*[text()='Payment Method']/../following::div[position()=1]//span")
	private WebElement cmbPaymentmethod;

	@FindBy(xpath = "//*[text()='BP Role']/../following::div[position()=1]//span")
	private WebElement cmbBPRole;

	@FindBy(xpath = "//label[text()='Bank Details ID']/following::input[position()=1]")
	private WebElement txt_Bankdtls;

	@FindBy(xpath = "//label[text()='Business Partner']/following::input[position()=1]")
	private WebElement txt_BPName;

	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btnApply;

	

	@FindBy(xpath = "//div[contains(@id,'dealEdit--PartnersView--tableForBusinessPartners--table-header')]/following::button[position()=3]")
	private WebElement btn_AddBP;

	@FindBy(xpath = "//input[contains(@id,'DealBusinessPartnerTables--idValidFrom-datePicker')]")
	private WebElement txt_ValidFrom;
	
	@FindBy(xpath = "//*[contains(@id,'utilType-comboBoxEdit-arrow')]")
	private WebElement cmbValidTo;
	

	@FindBy(xpath = "//footer/child::button[position()=1]//*[text()='Create']")
	private WebElement btnCreate;

	@FindBy(xpath ="//footer/following::button[contains(@id,'dealEdit--idSaveDeal')]")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Check Consistency']")
	private WebElement linkCheckconistency;

	@FindBy(xpath = "//*[text()='Close']")
	private WebElement btnCCclose;

	@FindBy(xpath = "//span[text()='Release Status:']/following::span[position()=1]")
	private WebElement labelFinancestatus;

	public String xpradioBProle = "//table[contains(@aria-labelledby,'dealEdit--PartnersView--tableForBusinessPartners--table-header')]/tbody/tr[1]/td[2]//div[contains(@id,'selectMulti-CbBg')]";

	public String xpptTitle = "//span[text()='Business Partners']";
	public String xpPartnerstab = "//*[text()='Partners']";
	public String xpBankdtls = "//label[text()='Bank Details ID']/following::input[position()=1]";
	public String xpBPName = "//label[text()='Business Partner']/following::input[position()=1]";
	public String xpMDRef = "//label[text()='Mandate Reference']/following::input[position()=1]";
	public String xpMsglist = "//table[contains(@aria-labelledby,'idConsistencyTable-header')]/tbody/tr/td[6]/span";
	public String xpReleasestatus = "//span[text()='Release Status:']/following::span[position()=1]";
	public String xpResAgent = "//input[contains(@id,'ResponsibleAgentsTable--BpId-input')]";
	public String xpOrgUnit = "//input[contains(@id,'ResponsibleAgentsTable--OrgUnit-input')]";
	public String xpAddBP="//div[contains(@id,'dealEdit--PartnersView--tableForBusinessPartners--table-header')]/following::button[position()=3]";
	public String xpBPRole= "//*[text()='BP Role']/../following::div[position()=1]//span";
	public String xpPaymentmethod = "//*[text()='Payment Method']/../following::div[position()=1]//span";
	
	public String xpApply = "//*[text()='Apply']";

	public String xpValidFrom = "//input[contains(@id,'DealBusinessPartnerTables--idValidFrom-datePicker')]";
	
	public String xpValidTo = "//*[contains(@id,'utilType-comboBoxEdit-arrow')]";

	public String xpCreate = "//footer/child::button[position()=1]//*[text()='Create']";
	
	public boolean tabPartners_AddBP(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_PARTNERS_AddBP_Title);
		String sAdd = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_PARTNERS_AddBP_Add);
		String sBPRole = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_PARTNERS_AddBP_BPRole);
		String sBPName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_PARTNERS_AddBP_BPName);
		String sPaymentmethod = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_PaymentMethod);
		String sBankdtls = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_BankDetailsID);
		String sMDRef = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_MandateRef);
		
		String sValidFrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_ValidFrom);
		String sValidTo = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_ValidTo);
		
		String sSave = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_PARTNERS_AddBP_ClickSave);
		String sCheckConsistency = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_CheckConsistency);
		String sCCErrormsg = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_CheckConsistErrorMsg);
		String sFinancestatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_PARTNERS_AddBP_ReleaseStatus);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPartnerstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPartnerstab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpptTitle)));
			lowlevellogsobj.info("Started in Partners Class");

			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			Thread.sleep(2000);
			commfunct_Obj.expectedValue(title_partner, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(1000);

			// Check Consistency
			if (sCheckConsistency.equalsIgnoreCase("Yes")) {
				
				commfunct_Obj.commonClick(linkCheckconistency, "Yes");
				lowlevellogsobj.info("Clicked on Check conistency link");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMsglist)));
				acf_Obj.messageVerificationPartner(driver, sCCErrormsg);
				lowlevellogsobj.info("Check conistency Error Messgae is verfied successfully");
				commfunct_Obj.commonClick(btnCCclose, "Yes");

			} else {
				lowlevellogsobj.info("Check conistency flag is set to No");
			}
			Thread.sleep(1000);

			// Add Business Partner
			if (sAdd.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddBP)));
				lowlevellogsobj.info("Add Business Partner is set to Yes");
				commfunct_Obj.commonClick(btn_AddBP, "Yes");
				lowlevellogsobj.info("Add Business Partner button is clicked");
			} else {
				lowlevellogsobj.info("Add Business Partner button is not enabled");

			}

			// BP Role
			if (sBPRole.length() > 0) {
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBPRole)));
				commfunct_Obj.comboSelect(driver, sBPRole, cmbBPRole);
				lowlevellogsobj.info("BP Role is selected as ->" + sBPRole);
			}

			// BP Name
			if (sBPName.length() > 0) {
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBPName)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpBPName, "Yes", sBPName);
				txt_BPName.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				lowlevellogsobj.info("BP Name is entered as ->" + sBPName);
			}

			
			// Valid From
			if (sValidFrom.length() > 0) {
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidFrom)));
				commfunct_Obj.commonSetTextTextBox(txt_ValidFrom, sValidFrom);
				lowlevellogsobj.info("Valid From is entered as ->" + sValidFrom);
			}
			// Valid To
			if (sValidTo.length() > 0) {
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidTo)));
				commfunct_Obj.comboSelect(driver, sValidTo, cmbValidTo);
				lowlevellogsobj.info("Valid To is selected as ->" + sValidTo);
			}
			if (sPaymentmethod.length() > 0) {
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentmethod)));
				commfunct_Obj.comboSelect(driver, sPaymentmethod, cmbPaymentmethod);
				lowlevellogsobj.info("Payment method is selected as ->" + sPaymentmethod);
			}
			
			if (sBankdtls.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBankdtls)));
				commfunct_Obj.commonSetTextTextBox(txt_Bankdtls, sBankdtls);
				txt_Bankdtls.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				lowlevellogsobj.info("Bank details is entered as ->" + sBankdtls);
			}

			if (driver.findElements(By.xpath(xpMDRef)).size() == 1) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMDRef)));
				if (sMDRef.length() > 0) {
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpMDRef, "Yes", sMDRef);
					lowlevellogsobj.info("Mandate Reference is entered as ->" + sMDRef);
				}
			}
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCreate)));
			commfunct_Obj.commonClick(btnCreate, "Yes");
			lowlevellogsobj.info("Create button is clicked");
			acf_Obj.checkSavemessage(driver, Constants.bankdtlsUpdatemsg);

			// Save Create Finance

			if (sSave.equalsIgnoreCase("Yes")) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer/following::button[contains(@id,'dealEdit--idSaveDeal')]", "Yes");
				lowlevellogsobj.info("Footer Save button is clicked");
				acf_Obj.checkSavemessage(driver, Constants.saveFinancemsg);
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReleasestatus)));
				commfunct_Obj.expectedValue(labelFinancestatus, "text", sFinancestatus, "Yes");
				lowlevellogsobj.info("Release status is ->" + sFinancestatus);
			} else {
				lowlevellogsobj.info("Either Save button flag is off or Save operation failure");
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		} finally {
			if ((driver.findElements(By.xpath("//a[text()='Show Details']")).size() == 1)
					&& (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size() == 1)) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
				Thread.sleep(1000);
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath",
						"//div[contains(@class,'sapMMessageBoxDetails')]");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->" + geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
				result = false;
			} else if (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size() == 1) {
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath",
						"//div[@class='sapMDialogScrollCont']/span");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->" + geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
				result = false;
			}
			 else {
              	 MsgList.add("Application Dump did not occur");
              }
		}

		return result;
	}

}
