/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.BusinessOperationsTab;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class BusinessOperations {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(BusinessOperations.class);

	public BusinessOperations(WebDriver driver) {
	}

	@FindBy(xpath = "//*[text()='Business Operations']")
	private WebElement tabBO;

	@FindBy(xpath = "//*[text()='Delete']")
	private WebElement btnDelete;

	@FindBy(xpath = "//footer[contains(@id,'footer')]//*[text()='OK']")
	private WebElement btnOK;
	public String xptitle = "//h1[contains(@class,'HeadTitle')]";
	public String xpId="//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr[2]/td[2]//span/span";
	public String xpCount ="//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr[not(contains(@class,'sapMLIBTypeInactive'))]";
	public String xpDelete="//*[text()='Delete']";
	public String xpOK="//footer[contains(@id,'footer')]//*[text()='OK']";

	public boolean tabBO(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sID = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_BO_ID);
		String sInitialStatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BO_InitialStatus);
		String sFinalStatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_BO_FinalStatus);
		String sDelete= commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_BO_Deletion);


		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			lowlevellogsobj.info("Started in Business Operations Class");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpId)));

			//selecting dynamic id for deletion

			int count = driver.findElements(By.xpath(xpCount)).size();
			if(count==1){
				count=count+1;
			}
			
			for(int i=2;i<=count;i++){
				WebElement eleID = driver.findElement(By.xpath("//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr["+i+"]/td[2]//span/span"));
				WebElement eleStatus = driver.findElement(By.xpath("//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr["+i+"]/td[6]//span/span"));
				String actID=eleID.getText();
				String actStatus = eleStatus.getText();
				if(actID.equalsIgnoreCase(sID) && actStatus.equalsIgnoreCase(sInitialStatus)){
					commfunct_Obj.commonClick(eleID, "Yes");
					lowlevellogsobj.info("Clicked on expected BO ROW ID->"+sID);
					Thread.sleep(2000);
					break;
				}
				else{
					lowlevellogsobj.error("Status or ID Mismatch in BO page");
				}



			}


			if(sDelete.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDelete)));
				commfunct_Obj.commonClick(btnDelete, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOK)));
				commfunct_Obj.commonClick(btnOK, "Yes");
				
				Appcommfunct_Obj.checkSavemessage(driver, Constants.Disbdeletionmsg);
				Thread.sleep(2000);
				//selecting dynamic id for deletion
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpId)));
				int delcount = driver.findElements(By.xpath(xpCount)).size();
				for(int i=2;i<=delcount;i++){
					WebElement eleID = driver.findElement(By.xpath("//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr["+i+"]/td[2]//span/span"));
					WebElement eleStatus = driver.findElement(By.xpath("//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr["+i+"]/td[6]//span/span"));
					String actID=eleID.getText();
					String actStatus = eleStatus.getText();
					if(actID.equalsIgnoreCase(sID) && actStatus.equalsIgnoreCase(sFinalStatus)){
						lowlevellogsobj.info("Deleted Disbursement is successful for BO ROW ID->"+sID);
						break;
					}
					else{
						lowlevellogsobj.error("Status or ID Mismatch in BO page");
					}

				}	

			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}

}
