/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.NewFinance;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class NewFinancing {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(NewFinancing.class);

	public NewFinancing(WebDriver driver) {
	}

	@FindBy(xpath = "//h1")
	private WebElement txt_ScreenName;

	@FindBy(xpath = "//span[contains(@id,'idOriginatedFrom-comboBoxEdit-arrow')]")
	private WebElement cmbTOE;

	@FindBy(xpath = "//input[contains(@id,'idProductId')]")
	private WebElement txt_Product;

	@FindBy(xpath = "//span[contains(@id,'idProductId-comboBoxEdit-arrow')]")
	private WebElement cmbProduct;

	@FindBy(xpath = "//label[contains(text(),'Name')]/../following::div[position()=2]//input")
	private WebElement txt_Name;

	@FindBy(xpath = "//label[contains(text(),'Description')]/../following::div[position()=2]//textarea")
	private WebElement txt_Description;

	@FindBy(id = "//input[contains(@id,'idBorrowerInCreate')]")
	private WebElement txt_MainBorrower;

	@FindBy(xpath = "//a[contains(@aria-labelledby,'idBorrowerInCreate-label')]")
	private WebElement txt_BorrowerName;

	@FindBy(xpath = "//input[contains(@id,'idBorrowerInCreate-input')]")
	private WebElement txt_MBPartner;

	@FindBy(id = "//label[text()='Total Financing Amount']/../following::div[position()=2]//input[not(contains(@id,'sfEdit'))]")
	private WebElement txt_TotalFinancingAmount;

	@FindBy(xpath = "//input[contains(@id,'-sfEdit-input-inner')]")
	private WebElement txt_Currency;

	@FindBy(xpath = "//span[contains(@id,'--idStatusForDeal-arrow')]")
	private WebElement txt_StatusDropDown;

	@FindBy(xpath = "//label[contains(text(),'Start of Contract Term')]/../following::div[position()=2]//input")
	private WebElement txt_StartOfContractTerm;

	@FindBy(xpath = "//label[contains(text(),'End of Contract Term')]/../following::div[position()=2]//input")
	private WebElement txtECT;

	@FindBy(xpath = "//label[contains(text(),'End of Contract Term')]/../following::div[position()=4]//input")
	private WebElement txt_ApprovalDate;

	@FindBy(xpath = "//label[contains(text(),'Commitment date')]/../following::div[position()=2]//input")
	private WebElement txt_CommitmentDate;

	@FindBy(xpath = "//label[contains(text(),'Contract Conclusion Date')]/../following::div[position()=2]//input")
	private WebElement txt_ContractConclDate;

	@FindBy(id = "//*[text()='Create']")
	private WebElement Btn_Create;

	@FindBy(xpath = "//span[contains(@id,'idStatusForDeal-arrow')]")
	private WebElement cmbStatus;

	@FindBy(xpath = "//label[contains(text(),'Bank Calendar')]/../following::div[position()=2]//span[contains(@id,'comboBoxEdit-arrow')]")
	private WebElement cmbBC;

	@FindBy(id = "//h1[text()='Include']/following::section//div[@title='contains']")
	private WebElement cmbCondtion;

	public String xpPID = "//input[contains(@id,'idProductId')]";
	public String xpName = "//label[contains(text(),'Name')]/../following::div[position()=2]//input";
	public String xpDesc = "//label[contains(text(),'Description')]/../following::div[position()=2]//textarea";
	public String xpMainBorrower = "//span[contains(@id,'idBorrowerInCreate-input-vhi')]";
	public String xpMBSrch = "//input[contains(@id,'btnBasicSearch-I')]";
	public String xpMBpartner = "//input[contains(@id,'idBorrowerInCreate-input')]";
	public String xpMBparthelper = "//span[contains(@id,'Partner-vhi')]";
	public String xpMBphelperdrpdwn = "//h1[text()='Include']/following::section//div[@title='contains']";
	public String xpMBphelpertxt = "//h1[text()='Include']/following::input[position()=2]";
	public String xpMBsrchicn = "//div[contains(@id,'btnBasicSearch-search')]";
	public String xpSelMB = "//div[@title='Click to Select']";
	public String xpMBlabel = "//a[contains(@aria-labelledby,'idBorrowerInCreate-label')]";
	public String xpTMA = "//label[text()='Total Financing Amount']/../following::div[position()=2]//input[not(contains(@id,'sfEdit'))]";
	public String xpCurrency = "//label[text()='Total Financing Amount']/../following::div[position()=2]//span[contains(@id,'sfEdit-input-vhi')]";
	public String xpSCT = "//label[contains(text(),'Start of Contract Term')]/../following::div[position()=2]//input";
	public String xpECT = "//label[contains(text(),'End of Contract Term')]/../following::div[position()=2]//input";
	public String xpECdt = "//label[contains(text(),'End of Contract Term')]/../following::div[position()=5]//input";
	public String xpCommitmentdt = "//label[contains(text(),'Commitment date')]/../following::div[position()=2]//input";
	public String xpCCdt = "//label[contains(text(),'Contract Conclusion Date')]/following::div[position()=2]//input";
	public String xpBC = "//label[contains(text(),'Bank Calendar')]/../following::div[position()=2]//span[contains(@id,'comboBoxEdit-arrow')]";
	public String xpDS = "//*[text()='Draft saved']";
	public String xpCreate = "//*[text()='Create']";
	public String xpHeadertitle = "//h1[contains(@id,'application-LoansWplcFinancing-manage-component---dealEdit--idDealEditHeader-title')]";
	public String xpScreenName = "//h1";
	public String xpTOE = "//span[contains(@id,'idOriginatedFrom-comboBoxEdit-arrow')]";
	public String xpStatus= "//span[contains(@id,'idStatusForDeal-arrow')]";
	public String xpProduct = "//span[contains(@id,'idProductId-comboBoxEdit-arrow')]";
	public String sAutoname;
	private String sCondition = "equal to";

	public boolean newfinanceDetails(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data)
					throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);
		String sTOE = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_TOE);
		String sProduct = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_Product);
		String sName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_Name);
		String sDescription = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_Description);
		String sMainBorrower = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_MainBorrower);
		String sBorrowerName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_BorrowerName);
		String sTotalFinancingAmt = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_TotalFinancingAmt);
		String sCurrency = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_Currency);
		String sStatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_Status);
		String sStartOfContractTerm = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_StartOfContractTerm);
		String sECTdrpdwn = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_ECDRPDWN);
		String sEndOfContractTerm = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_EndOfContractTerm);
		String sApprovalDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_ApprovalDate);
		String sCommitmentDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_CommitmentDate);
		String sContractConclDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NEWFINANCING_ContractConclDate);
		String sBC = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_BC);
		String sCreate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_Create);
		String sSynd = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NEWFINANCING_Syndication);
		
		try {
			lowlevellogsobj.info("Started in NewFinance Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			Thread.sleep(2000);
			if (driver.findElements(By.xpath("h1")).size() == 1) {
				WebElement eleTitle = driver.findElement(By.xpath("//h1"));
				commfunct_Obj.expectedValue(eleTitle, "text", "New Financing", "Yes");
				lowlevellogsobj.info("Landed successfully on New Financing Screen");
			}
			Thread.sleep(2000);
			sAutoname = "AutoTest_Fin_" + commfunct_Obj.dateTimeGenerate();

			if (sTOE.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpScreenName)));
				// commfunct_Obj.commonSetTextTextBox(txt_Product, sProduct);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTOE)));
				commfunct_Obj.comboSelect(driver, sTOE, cmbTOE);
			}

			if (sProduct.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPID)));
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpProduct)));
				commfunct_Obj.comboSelect(driver, sProduct, cmbProduct);
				lowlevellogsobj.info("Entered Product ID as->" + sProduct);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01", sProduct, 3);
			}
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpName, "Yes", sAutoname);
			lowlevellogsobj.info("Entered Name as->" + sAutoname);
			MsgList.add("Deal ID - "+sAutoname);
			
			if(sSynd.equalsIgnoreCase("No")) {
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NEWFINANCING, "REF_01", sAutoname, 4);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_SEARCHFINANCING, "REF_01", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_SEARCHFINANCING, "REF_02", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BOOverview, "REF_01", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BOOverview, "REF_03", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_MyInbox, "REF_01", sAutoname, 1);
			}
			
			else {
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_NEWFINANCING, "REF_02", sAutoname, 4);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_02", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_SEARCHFINANCING, "REF_04", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BOOverview, "REF_02", sAutoname, 1);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_MyInbox, "REF_04", sAutoname, 1);
				
			}
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDesc)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpDesc, "Yes", sDescription);
			lowlevellogsobj.info("Entered Description as->" + sDescription);

			if (sMainBorrower.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBpartner)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpMBpartner, "Yes", sMainBorrower);
				txt_MBPartner.sendKeys(Keys.ENTER);
				/*
				 * commfunct_Obj.commonFindElement_Click(driver, "xpath",
				 * xpMBsrchicn, "Yes");
				 * wait.until(ExpectedConditions.presenceOfElementLocated(By.
				 * xpath("//table//tbody/tr[1]/td[2]//span[text()="+
				 * sMainBorrower+"]")));
				 * commfunct_Obj.commonFindElement_Click(driver, "xpath",
				 * xpSelMB, "Yes");
				 */
				Thread.sleep(2000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBlabel)));
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01", sMainBorrower, 2);
			}

			if (sBorrowerName.length() > 0) {
				commfunct_Obj.expectedValue(txt_BorrowerName, "text", sBorrowerName, "Yes");
				lowlevellogsobj.info("Validated Succesfully that Borrower name is:" + sBorrowerName);
			}

			if (sTotalFinancingAmt.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTMA)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpTMA, "Yes", sTotalFinancingAmt);
				lowlevellogsobj.info("Entered Total Financing Amount is:" + sTotalFinancingAmt);
			}

			if (sCurrency.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCurrency)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCurrency, "Yes");

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBSrch)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpMBSrch, "Yes", sCurrency);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBsrchicn)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpMBsrchicn, "Yes");
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("//table//tbody/tr[1]/td[2]//span[contains(@data-sap-ui,'clone')]")));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSelMB, "Yes");
				lowlevellogsobj.info("Selected Currency is:" + sCurrency);
				Thread.sleep(2000);
			}

			if (sStatus.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpStatus)));
				commfunct_Obj.comboSelect(driver, sStatus, cmbStatus);
				lowlevellogsobj.info("Selected Status as->" + sStatus);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01", sStatus, 5);
				Thread.sleep(1000);
			}

			if (sStartOfContractTerm.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSCT)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpSCT, "Yes", sStartOfContractTerm);
				lowlevellogsobj.info("Entered Start Of Contract Term is:" + sStartOfContractTerm);
			}

			if (sECTdrpdwn.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpECT)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpECT, "Yes", sECTdrpdwn);
				txtECT.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				lowlevellogsobj.info("Selected End of Contract Term is->" + sECTdrpdwn);
				Thread.sleep(1000);
			}

			if (sEndOfContractTerm.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpECdt)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpECdt, "Yes", sEndOfContractTerm);
				lowlevellogsobj.info("Entered End Of Contract Term is:" + sEndOfContractTerm);
			}

			if (sCommitmentDate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCommitmentdt)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpCommitmentdt, "Yes", sCommitmentDate);
				lowlevellogsobj.info("Entered Commitment Date is:" + sCommitmentDate);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_DETAILS, "REF_01", sCommitmentDate, 4);
			}

			if (sContractConclDate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCCdt)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpCCdt, "Yes", sContractConclDate);
				lowlevellogsobj.info("Entered Contract Conclusion Date is:" + sContractConclDate);
			}

			if (sBC.length() > 0) {
				commfunct_Obj.comboSelect(driver, sBC, cmbBC);
				lowlevellogsobj.info("Selected Bank Calendar is->" + sBC);
			}

			commfunct_Obj.waitUntilDocumentIsReady(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDS)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCreate, "Yes");
			lowlevellogsobj.info("Clicked on Create Button");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpHeadertitle)));
			// Thread.sleep(10000);

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering New Financial Detail:  " + e.getMessage(), e);
			//Appcommfunct_Obj.catchDump(driver);
			result = false;
		} 
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}
}