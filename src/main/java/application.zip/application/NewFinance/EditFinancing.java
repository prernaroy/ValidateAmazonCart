/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.NewFinance;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class EditFinancing {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(EditFinancing.class);

	public EditFinancing(WebDriver driver) {
	}

	@FindBy(xpath = "//*[text()='Edit']")
	private WebElement btnEdit;

	@FindBy(xpath = "//*[text()='Edit Anyway']")
	private WebElement btnCnfEdit;

	@FindBy(xpath = "//header//span[text()='Warning']")
	private WebElement labelWarning;

	public String xptitle = "//h1[contains(@class,'HeadTitle')]";
	public String xpwarning = "//header//span[text()='Warning']";
	public String xpbtnEdit = "//*[text()='Edit']";
	public String xpbtnCnfEdit = "//*[text()='Edit Anyway']";

	public boolean tabEditfinance(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sEdit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_EDITFINANCING_Edit);
		String sWarning = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_EDITFINANCING_Warning);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			lowlevellogsobj.info("Started in Overview Class");
			Thread.sleep(3000);
			if ((driver.findElements(By.xpath(xpbtnEdit)).size() == 1) && (sEdit.equalsIgnoreCase("Yes"))){
			
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnEdit)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnEdit, "Yes");
				lowlevellogsobj.info("Clicked on Edit Button");
				Thread.sleep(3000);
			}
			else {
				lowlevellogsobj.info("Edit button is not displayed");
			}
			Thread.sleep(3000);
			
			if ((driver.findElements(By.xpath(xpwarning)).size() == 1) && (sWarning.equalsIgnoreCase("Yes"))){
			//commfunct_Obj.expectedValue(labelWarning, "text", sWarning, "Yes");
			//lowlevellogsobj.info("Title of window (After Edit) is ->" + sWarning);
			//Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnCnfEdit)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnCnfEdit, "Yes");
			lowlevellogsobj.info("Confirmed clicking on Edit Button");
			Thread.sleep(3000);
			}
			else {
				lowlevellogsobj.info("Warning is not displayed");
			}
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in editing finance Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}

}
