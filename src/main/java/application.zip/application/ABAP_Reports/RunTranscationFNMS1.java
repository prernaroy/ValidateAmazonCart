/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.ABAP_Reports;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;
import utils.ExecuteFNMS1Transaction;

/**
 * @author I313006
 *
 */
public class RunTranscationFNMS1 {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ExecuteFNMS1Transaction FNMS1 = new ExecuteFNMS1Transaction();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(RunTranscationFNMS1.class);

	public RunTranscationFNMS1(WebDriver driver) {
	}

	
	
	

	public boolean RunTransactionFNMS1(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		
		/*String sPagetitle=commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_SCF_PAGETITLE);
		String sAggregation = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_SCF_TYPE);
		String sRecord = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SCF_RECORD);*/
		

		try {
			result = FNMS1.executeFNMS1Transaction();
			if (result==true){
				lowlevellogsobj.info("The Transaction FNMS1 is successful");
			}
				else{
					lowlevellogsobj.info("The Transaction FNMS1 is NOT successful");
				}
			
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}

}
