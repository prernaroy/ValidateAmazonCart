/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class EditDrawdownConditions {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(EditDrawdownConditions.class);

	public EditDrawdownConditions(WebDriver driver) {
	}
	
		
	@FindBy(xpath = "//a[@title='Back']")
	private WebElement btnBack;
	
	@FindBy(xpath = "//span[contains(@id,'idConditionType-arrow')]")
	private WebElement cmbCondtype;
	
	@FindBy(xpath = "//button[contains(@id,'DrawdownConditions-anchor')]")
	private WebElement tabConditions;
	
	@FindBy(xpath = "//section//*[contains(text(),'Periodicity Profile')]/../following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbPeriodicprofile;
	
	@FindBy(xpath = "//footer[contains(@id,'manageCondition-component---Edit')]//button//*[text()='Create']")
	private WebElement btnCreate;
	
	@FindBy(xpath = "//section//*[contains(text(),'Calculation Date')]/../following::div[position()=2]//input")
	private WebElement txtCalculationdate;

	@FindBy(xpath = "//section//*[contains(text(),'Due Date')]/../following::div[position()=2]//input")
	private WebElement txtDuedate;
	
	@FindBy(xpath = "//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr[1]")
	private WebElement tbl_row1;
	
	@FindBy(xpath = "//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr[2]")
	private WebElement tbl_row2;
	
	@FindBy(xpath = "//section//*[contains(text(),'Payer')]/../following::div[position()=2]//span")
	private WebElement txtPayer;
	
	@FindBy(xpath = "//*[contains(@id,'drawdownEdit--ConditionView--buttonAddCond-img')]")
	private WebElement btnAdd;
	
	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;
	
	
	
	
	
	public String xpConditionstab="//button[contains(@id,'DrawdownConditions-anchor')]";
	public String xpCalcdate = "//section//*[contains(text(),'Calculation Date')]/../following::div[position()=2]//input";
	public String xpDuedate = "//section//*[contains(text(),'Due Date')]/../following::div[position()=2]//input";
	public String xptableCondition="//table[contains(@aria-labelledby,'drawdownEdit--ConditionView')]/tbody/tr";
	public String xptblrow1="//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr[1]";
	public String xptblrow2="//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr[2]";
	public String xpbtnApply="//footer[contains(@id,'manageCondition-component---Edit')]//button//*[text()='Apply']";
	public String xpValidfrom="//section//*[contains(text(),'Valid From')]/../following::div[position()=2]//input";
	public String xpPercentage = "//section//*[contains(text(),'Percentage')]/../following::div[position()=2]//input";
	public String xpAmount="//section//*[contains(text(),'Condition Amount')]/../following::div[position()=2]//input";
	public String xpPayer="//section//*[contains(text(),'Payer')]/../following::div[position()=2]//span";
	public String xpTablerows="//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr";
	public String xpCondtype="//span[contains(@id,'idConditionType-arrow')]";
	public String xpSelPayer="//table//tbody/tr[1]/td[2]//span[contains(@data-sap-ui,'clone')]";
	public String xpAddcondition="//*[contains(@id,'drawdownEdit--ConditionView--buttonAddCond-img')]";
	public String xpWaitloading="//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']";
	public String xpPeriodicprofile = "//section//*[contains(text(),'Periodicity Profile')]/../following::div[position()=2]//span[contains(@id,'arrow')]";
	
	public String xpCreate = "//footer[contains(@id,'manageCondition-component---Edit')]//button//*[text()='Create']";
	
	public boolean tabeditdraConditions(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
					throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		String sConditionType=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACONDITIONSHEADER_ConditionType);
		String sPP=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACONDITIONSHEADER_PeriodicProfile);
		String sCalculationDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRACONDITIONSHEADER_CalculationDate);
		String sDueDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRACONDITIONSHEADER_DueDate);
		String sValidfrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRACONDITIONSHEADER_ValidFrom);
		String sPercentage = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRACONDITIONSHEADER_Percentage);
		String sAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRACONDITIONSHEADER_Amount);
		String sPayer = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRACONDITIONSHEADER_Payer);
		
		try {
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpConditionstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpConditionstab, "Yes");
			commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
			lowlevellogsobj.info("Started in Edit Drawdown Conditions Class");
			Thread.sleep(2000);
			/*commfunct_Obj.commonFindElement_Click(driver, "xpath", xptblrow1, "Yes");
			lowlevellogsobj.info("first row is clicked");
			Thread.sleep(2000);*/
			
			String [] strCondtype = sConditionType.split("\\|");
			int totalRows = strCondtype.length;
			for(int i=0; i<totalRows;i++){
			
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddcondition)));
				//commfunct_Obj.commonFindElement_Click(driver, "xpath", xpAddcondition, "Yes");
				commfunct_Obj.commonClick(btnAdd, "Yes");
				//Thread.sleep(3000);
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
				Thread.sleep(3000);
				commfunct_Obj.comboSelect(driver, strCondtype[i], cmbCondtype);
				
				if(sValidfrom.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpValidfrom, "Yes", sValidfrom);
				lowlevellogsobj.info("Valid From Date is entered as ->" + sValidfrom);
				}
				
				if(sPercentage.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPercentage)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpPercentage, "Yes", sPercentage);
					lowlevellogsobj.info("Percentage is entered as ->" + sPercentage);
					}
				
				if(sPayer.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPayer)));
					commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPayer, "Yes");
					wait.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath(xpSelPayer)));
					commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSelPayer, "Yes");
					lowlevellogsobj.info("Selected Payer is:" + sPayer);
					Thread.sleep(1000);
					}
			
				if(sAmount.length()>0){
					
					if(driver.findElements(By.xpath(xpAmount)).size()==1){
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpAmount, "Yes", sAmount);
					lowlevellogsobj.info("Amount is entered as ->" + sAmount);
					}
				}
				
				if (sCalculationDate.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCalcdate)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpCalcdate, "Yes", sCalculationDate);
					// Thread.sleep(1000);
					lowlevellogsobj.info("Calculation Date is entered as ->" + sCalculationDate);
				}
				
				Thread.sleep(1000);
				if (sDueDate.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDuedate)));
					commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpDuedate, "Yes", sDueDate);
					// Thread.sleep(1000);
					lowlevellogsobj.info("Due date is entered as ->" + sDueDate);
				}
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPeriodicprofile)));
				commfunct_Obj.comboSelect(driver, sPP, cmbPeriodicprofile);
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCreate)));
				commfunct_Obj.commonClick(btnCreate, "Yes");
				lowlevellogsobj.info("Clicked on Create button");
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
				Thread.sleep(3000);
				
				
			}
			
		/*	
						
			
			wait.until(ExpectedConditions.visibilityOf(btnApply));
			commfunct_Obj.commonClick(btnApply, "Yes");
			lowlevellogsobj.info("Clicked on Apply button");
			Thread.sleep(1000);
			
			wait.until(ExpectedConditions.visibilityOf(btnBack));
			commfunct_Obj.commonClick(btnBack, "Yes");
			lowlevellogsobj.info("Back button is clicked");
			Thread.sleep(2000);
			
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xptblrow2, "Yes");
			lowlevellogsobj.info("sec row is clicked");
			Thread.sleep(2000);
			
			if (sCalculationDate.length() > 0) {
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpCalcdate, "Yes", sCalculationDate);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Calculation Date is entered as ->" + sCalculationDate);
			}
			
			Thread.sleep(1000);
			if (sDueDate.length() > 0) {
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpDuedate, "Yes", sDueDate);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Due date is entered as ->" + sDueDate);
			}*/
			Thread.sleep(1000);
			
			
			//Appcommfunct_Obj.clickGridele(driver, sConditionType, xptableCondition, cmbPeriodicprofile, sPP, btnApply);
			Thread.sleep(1000);
			lowlevellogsobj.info("Drawdown condition is edited and updated");
			
			result = true;
			
		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}
	
}
