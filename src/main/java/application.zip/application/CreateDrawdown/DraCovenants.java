/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class DraCovenants {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(DraCovenants.class);

	public DraCovenants(WebDriver driver) {
	}
	
	@FindBy(xpath = "//*[contains(@id,'buttonAddCov-img')]")
	private WebElement btn_Addcondition;
	
	
	
	
	public String xpAddcovenant="//*[contains(@id,'buttonAddCov-img')]";
	public String xpCovenantstab="//*[text()='Covenants']";
	public String xpCovenantstype="//label[contains(text(),'Covenant Type')]/../following::div[position()=1]//span[contains(@id,'vhi')]";

	public boolean tabDraCovenants(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
					throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sAddcovenants = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTS_Add);
		
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCovenantstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCovenantstab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddcovenant)));
			lowlevellogsobj.info("Started in Covenants Class");
			if(sAddcovenants.equalsIgnoreCase("Yes")){
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpAddcovenant, "Yes");
			lowlevellogsobj.info("Add Covenant button is clicked");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCovenantstype)));
			}
			result = true;
			
		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}
	
}
