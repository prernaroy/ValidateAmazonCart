/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class DraCovenants_Header {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(DraCovenants_Header.class);

	public DraCovenants_Header(WebDriver driver) {
	}
	
	@FindBy(xpath = "//*[contains(@id,'buttonAddCov-img')]")
	private WebElement btn_Addcondition;
	
	@FindBy(xpath = "//*[contains(text(),'Covenant Type')]/../following::div[position()=1]//input")
	private WebElement txt_CovenantType;
	
	@FindBy(xpath = "//*[contains(text(),'Description')]/../following::div[position()=1]//input")
	private WebElement txt_Description;
	
	@FindBy(xpath = "//*[text()='End of Contractual Consequences']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbEOC;
	
	@FindBy(xpath = "//*[text()='Valid To']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbValidto;
	
	
	public String xpAddcovenant="//*[contains(@id,'buttonAddCov-img')]";
	public String xpCovenantstab="//*[text()='Covenants']";
	public String xpCovenantstype="//*[contains(text(),'Covenant Type')]/../following::div[position()=1]//input";
	public String xpValidfrom="//*[contains(text(),'Valid From')]/../following::div[position()=1]//input";
	public String xpValidTo="//*[contains(text(),'Valid To')]/../following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpDesc="//*[contains(text(),'Description')]/../following::div[position()=1]//input";
	public String xpEOC = "//*[text()='End of Contractual Consequences']/../following::div[position()=1]//span[contains(@id,'arrow')]";
	
	public boolean tabDraCovenantsheader(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
					throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sCovenantType = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTSHEADER_TYPE);
		String sDescription = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTSHEADER_Description);
		String sEOC_Consequences = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTSHEADER_EOC_Consequences);
		String sValidFrom = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTSHEADER_ValidFrom);
		String sValidTo = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTSHEADER_ValidTo);
		String sDate = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_DRACOVENANTSHEADER_Date);
		
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCovenantstype)));
			Thread.sleep(1000);
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpCovenantstype, "Yes", sCovenantType);
			txt_CovenantType.sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			lowlevellogsobj.info("Covenant Type is entered as->"+sCovenantType);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDesc)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpDesc, "Yes", sDescription);
			//commfunct_Obj.commonSetTextTextBox(txt_Description, sDescription);
			lowlevellogsobj.info("Covenant Description is entered as->"+sDescription);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEOC)));
			commfunct_Obj.comboSelect(driver, sEOC_Consequences, cmbEOC);
			lowlevellogsobj.info("Covenant EOC is selected as->"+sEOC_Consequences);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpValidfrom, "Yes", sValidFrom);
			lowlevellogsobj.info("Covenant Valid From is entered as->"+sValidFrom);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidTo)));
			commfunct_Obj.comboSelect(driver, sValidTo, cmbValidto);
			lowlevellogsobj.info("Covenant Valid To is selected as->"+sValidTo);
			
			result = true;
			
		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}
	
}
