/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class DraSyndication {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(DraSyndication.class);

	public DraSyndication(WebDriver driver) {
	}

	@FindBy(xpath = "//span[text()='Syndication Agreements']")
	private WebElement title_syndication;

	@FindBy(xpath = "//*[text()='Mandatory Syndication']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbMndsyndication;
	
	@FindBy(xpath = "//label[@title='Role in the Syndication']/../following::div[position()=3]//span[contains(@id,'arrow')]")
	private WebElement cmbRole;

	@FindBy(xpath = "//input[contains(@id,'dealEdit--SyndicationView')]")
	private WebElement txtAmnt;

	@FindBy(xpath = "//*[text()='Underwriting Term']/../following::div[position()=1]//input")
	private WebElement txtSyndate;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr[1]")
	private WebElement table_row;

	@FindBy(xpath = "//*[text()='Header']")
	private WebElement lblHeader;

	public String xpSyndicationtab = "//*[contains(@id,'drawdownEdit')]//*[text()='Syndication']";
	public String xpSyndate = "//*[text()='Underwriting Term']/../following::div[position()=1]//input";
	public String xpAmnt = "//input[contains(@id,'dealEdit--SyndicationView')]";
	public String xpdraRow = "//table[contains(@aria-labelledby,'drawdownEdit')]/tbody/tr[1]";
	public String xplblHeader = "//*[text()='Header']";
	public String xpMndsyndication = "//*[text()='Mandatory Syndication']/../following::div[position()=1]//span[contains(@id,'arrow')]";
	

	public boolean tabDraSyndication(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sEditdraRow = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATION_Edit);
		String sRole = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_DRASYNDICATION_Role);
		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRASYNDICATION_Title);
		String sMandatorySyndication = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATION_MandatorySyndication);
		String sValue = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRASYNDICATION_Value);
		String sUnderwritingTerm = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATION_UnderwritingTerm);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSyndicationtab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSyndicationtab, "Yes");
			lowlevellogsobj.info("Started in Syndication Class");

			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			commfunct_Obj.expectedValue(title_syndication, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);
			
			if (sMandatorySyndication.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMndsyndication)));
				commfunct_Obj.comboSelect(driver, sMandatorySyndication, cmbMndsyndication);
				Thread.sleep(3000);
				lowlevellogsobj.info("Mandatory Syndication is Selected as ->" + sMandatorySyndication);
			}
			
			

			if (sValue.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAmnt)));
				commfunct_Obj.commonSetTextTextBox(txtAmnt, sValue);
				// Thread.sleep(2000);
				lowlevellogsobj.info("Syndication Value is entered as ->" + sValue);
			}

			if (sUnderwritingTerm.length() > 0) {
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpSyndate, "Yes", sUnderwritingTerm);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Underwriting Term is entered as ->" + sUnderwritingTerm);
			}

		
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}

}
