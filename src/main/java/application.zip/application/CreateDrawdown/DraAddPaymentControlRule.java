/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class DraAddPaymentControlRule {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(DraAddPaymentControlRule.class);

	public DraAddPaymentControlRule(WebDriver driver) {
	}

	@FindBy(xpath = "//div[contains(@class,'sapUxAPHierarchicalSelect')]")
	private WebElement btnMore;

	@FindBy(xpath = "//*[contains(@id,'PaymentRulesTableView--table-header-inner')]/following::button[position()=3]//span[contains(@id,'img')]")
	private WebElement btn_AddPCrule;

	@FindBy(xpath = "//*[contains(@id,'transactiontyp-comboBoxEdit-arrow')]")
	private WebElement cmbUse;

	@FindBy(xpath = "//*[text()='Valid From']/following::div[position()=1]//input[contains(@id,'datePicker')]")
	private WebElement txt_Validfrom;

	@FindBy(xpath = "//*[text()='Valid To']/following::div[position()=1]//input[contains(@id,'datePicker')]")
	private WebElement txt_ValidTo;

	@FindBy(xpath = "//*[contains(@id,'idpayerpayee-arrow')]")
	private WebElement cmbPP;

	@FindBy(xpath = "//*[contains(@id,'idPaymentmethod-arrow')]")
	private WebElement cmbPaymentmethod;

	@FindBy(xpath = "//*[text()='Bank Details ID']/following::div[position()=1]//input")
	private WebElement txt_Bankdtls;

	@FindBy(xpath = "//footer[contains(@id,'dealPaymentRules-footer')]//*[text()='Create']")
	private WebElement btnPMCreate;

	public String xpbtnMore = "//div[contains(@class,'sapUxAPHierarchicalSelect')]";
	public String xpPCR = "//span[contains(@id,'DrawdownPaymentRules')]/*[text()='Payment Control Rules']";
	public String xpAddPCrule = "//*[contains(@id,'PaymentRulesTableView--table-header-inner')]/following::button[position()=3]//span[contains(@id,'img')]";
	public String xpPCruletab = "//*[text()='Payment Control Rules']";
	public String xpUse = "//*[contains(@id,'transactiontyp-comboBoxEdit-arrow')]";
	public String xpValidfrom = "//*[text()='Valid From']/following::div[position()=1]//input[contains(@id,'datePicker')]";
	public String xpValidTo = "//*[text()='Valid To']/following::div[position()=1]//input[contains(@id,'datePicker')]";
	public String xpPP = "//*[contains(@id,'idpayerpayee-arrow')]";
	public String xpPaymentmethod = "//*[contains(@id,'idPaymentmethod-arrow')]";
	public String xpBankdtls = "//*[text()='Bank Details ID']/following::div[position()=1]//input";
	
	public boolean tabDraPCR(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sAddPCrule = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_DRAPCRULE_Add);
		String sUse = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_DRAPCRULE_Use);
		String sFrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_DRAPCRULE_ValidFrom);
		String sTo = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_DRAPCRULE_ValidTo);
		String sPP = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_DRAPCRULE_PayerPayee);
		String sPaymentmethod = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRAPCRULE_PaymentMethod);
		String sBankdetails = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_DRAPCRULE_BankDetails);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPCR)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPCR, "Yes");
			lowlevellogsobj.info("Clicked on Payment Control Rules button");
			Thread.sleep(2000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPCruletab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPCruletab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddPCrule)));
			lowlevellogsobj.info("Started in Payment Control Rule Class");

			if (sAddPCrule.equalsIgnoreCase("Yes")) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpAddPCrule, "Yes");
				lowlevellogsobj.info("Add PC Rule button is clicked");
				Thread.sleep(2000);
			}

			if (sUse.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpUse)));
				commfunct_Obj.comboSelect(driver, sUse, cmbUse);
				lowlevellogsobj.info("Use is Selected as->" + sUse);
				Thread.sleep(1000);
			}

			if (sFrom.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
				commfunct_Obj.commonSetTextTextBox(txt_Validfrom, sFrom);
				lowlevellogsobj.info("From Date is entered as->" + sFrom);
			}

			if (sTo.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidTo)));
				commfunct_Obj.commonSetTextTextBox(txt_ValidTo, sTo);
				lowlevellogsobj.info("To Date is entered as->" + sTo);
			}

			if (sPP.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPP)));
				commfunct_Obj.comboSelect(driver, sPP, cmbPP);
				lowlevellogsobj.info("PayerPayee is selected as->" + sPP);
			}

			if (sPaymentmethod.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentmethod)));
				commfunct_Obj.comboSelect(driver, sPaymentmethod, cmbPaymentmethod);
				lowlevellogsobj.info("Payment Method is selected as->" + sPaymentmethod);
			}

			if (sBankdetails.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBankdtls)));
				commfunct_Obj.commonSetTextTextBox(txt_Bankdtls, sBankdetails);
				txt_Bankdtls.sendKeys(Keys.ENTER);
				lowlevellogsobj.info("Bank Details is entered as->" + sBankdetails);
				Thread.sleep(2000);
			}

			commfunct_Obj.commonClick(btnPMCreate, "Yes");
			lowlevellogsobj.info("Clicked on Create button");
			commfunct_Obj.waitUntilDocumentIsReady(driver);
			Appcommfunct_Obj.checkSavemessage(driver, Constants.AddPMCmsg);
			Thread.sleep(2000);

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}

}
