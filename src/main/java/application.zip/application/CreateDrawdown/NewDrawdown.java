/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.awt.KeyEventPostProcessor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class NewDrawdown {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(NewDrawdown.class);

	public NewDrawdown(WebDriver driver) {
	}

	@FindBy(xpath = "//div[contains(@id,'idTrancheEdit-anchBar')]//div[contains(@class,'sapUxAPHierarchicalSelect')]")
	private WebElement btnMore;

	@FindBy(xpath = "//*[text()='Create Drawdown']")
	private WebElement btnCreateDrawdown;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Name']/following::div[position()=1]//input")
	private WebElement txt_Name;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Borrower']/following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbBorrower;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Drawdown Product']/following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbproduct;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Total Drawdown Amount']/following::div[position()=1]//input[not(contains(@aria-describedby,'SuggDescr'))]")
	private WebElement txt_Amount;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Total Drawdown Amount']/following::div[position()=1]//input[contains(@aria-describedby,'SuggDescr')]")
	private WebElement txtCurrency;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Disbursement Rate']/following::div[position()=1]//input")
	private WebElement txt_DisbursmentRate;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='Start of Term']/following::div[position()=1]//input")
	private WebElement txt_StartTerm;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='End of Term']/following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbEndTerm;

	@FindBy(xpath = "//section[contains(@id,'drawdownCreate')]//*[text()='End of Term']/following::div[position()=5]//input")
	private WebElement txt_EndofTerm;

	@FindBy(xpath = "//footer[contains(@id,'drawdownCreate')]//*[text()='Create and Edit']")
	private WebElement buttonCreateEdit;

	@FindBy(xpath = "//table[contains(@aria-labelledby,'tableForDrawdownFreeText-header')]/tbody/tr[1]/td[3]/div")
	private WebElement btnFTRflag;

	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader; 




	public String xpbtnMore="//div[contains(@id,'idTrancheEdit-anchBar')]//div[contains(@class,'sapUxAPHierarchicalSelect')]";
	public String xpOverview="//li[text()='Overview']";
	public String xpOverviewtab = "//button[contains(@id, 'trancheEdit--TrancheOverview-anchor')]";
	public String xpCT="//*[text()='Create Drawdown']";
	public String xpCreateEdit="//footer[contains(@id,'drawdownCreate')]//*[text()='Create and Edit']";
	public String xpName="//section[contains(@id,'drawdownCreate')]//*[text()='Name']/following::div[position()=1]//input";
	public String xpBorrower = "//section[contains(@id,'drawdownCreate')]//*[text()='Borrower']/following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpproduct = "//section[contains(@id,'drawdownCreate')]//*[text()='Drawdown Product']/following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpAmount = "//section[contains(@id,'drawdownCreate')]//*[text()='Total Drawdown Amount']/following::div[position()=1]//input[not(contains(@aria-describedby,'SuggDescr'))]";
	public String xpCurrency = "//section[contains(@id,'drawdownCreate')]//*[text()='Total Drawdown Amount']/following::div[position()=1]//input[contains(@aria-describedby,'SuggDescr')]";
	public String xpDisbursmentRate = "//section[contains(@id,'drawdownCreate')]//*[text()='Disbursement Rate']/following::div[position()=1]//input";
	public String xpStartTerm = "//section[contains(@id,'drawdownCreate')]//*[text()='Start of Term']/following::div[position()=1]//input";
	public String xpEndTerm = "//section[contains(@id,'drawdownCreate')]//*[text()='End of Term']/following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpEndofTerm= "//section[contains(@id,'drawdownCreate')]//*[text()='End of Term']/following::div[position()=5]//input";
	public String xpFTRflag = "//table[contains(@aria-labelledby,'tableForDrawdownFreeText-header')]/tbody/tr[1]/td[3]/div";
	
	public boolean tabNewDD(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sDDName = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_DDName);
		String sBorrower = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_MainBorrower);
		String sDDProduct = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_DDProduct);
		String sDDAmt = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_DDAmt);
		String sDDCurr= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_DDCurr);
		String sDisbrate=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_Disbrate);
		String sStartofterm= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_StartofTerm);
		String sEndofTerm= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_EndofTerm);
		String sEndDate= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_EndDate);
		String sFTRflag= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_FTR_FLAG);
		String sClickCreateEdit= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_CREATEDRAWDOWN_ClickCreateEdit);

		try {
			if(driver.findElement(By.xpath(xpbtnMore)).isDisplayed()){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnMore)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnMore, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOverview)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpOverview, "Yes");
				lowlevellogsobj.info("Clicked on Overview button");
				Thread.sleep(2000);
			}
			else {
				lowlevellogsobj.info("Started in Overview Class");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOverviewtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpOverviewtab, "Yes");
				Thread.sleep(1000);
		}
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCT)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCT, "Yes");
			lowlevellogsobj.info("Clicked on Create Drawdown button");
			
			commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
			lowlevellogsobj.info("Inside Create Drawdown class");
			Thread.sleep(1000);
			if (sDDName.length() > 0) {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpName, "Yes", sDDName);
			lowlevellogsobj.info("Drawdown Name is entered as->"+sDDName);
			Thread.sleep(1000);
			}
			if (sBorrower.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBorrower)));
			commfunct_Obj.comboSelect(driver, sBorrower, cmbBorrower);
			lowlevellogsobj.info("Borrower Name is selected as->"+sBorrower);
			Thread.sleep(1000);
			}
			if (sDDProduct.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpproduct)));
			commfunct_Obj.comboSelect(driver, sDDProduct, cmbproduct);
			lowlevellogsobj.info("Drawdown Product is selected as->"+sDDProduct);
			Thread.sleep(1000);
			}
			if (sDDAmt.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAmount)));
			commfunct_Obj.commonSetTextTextBox(txt_Amount, sDDAmt);
			lowlevellogsobj.info("Drawdown Amount is entered as->"+sDDAmt);
			Thread.sleep(1000);
			}
			if (sDDCurr.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCurrency)));
			commfunct_Obj.commonSetTextTextBox(txtCurrency, sDDCurr);
			lowlevellogsobj.info("Drawdown Currency is entered as->"+sDDCurr);
			txtCurrency.sendKeys(Keys.ENTER);
			Thread.sleep(1000);
			Thread.sleep(1000);
			}
			if (sDisbrate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDisbursmentRate)));
			commfunct_Obj.commonSetTextTextBox(txt_DisbursmentRate, sDisbrate);
			lowlevellogsobj.info("Disbursement rate is entered as->"+sDisbrate);
			}
			if (sStartofterm.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpStartTerm)));
			commfunct_Obj.commonSetTextTextBox(txt_StartTerm, sStartofterm);
			lowlevellogsobj.info("Drawdown Start of Term is entered as->"+sStartofterm);
			}
			
			
			if(sEndofTerm.equalsIgnoreCase("Term Ends On")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEndTerm)));
				commfunct_Obj.comboSelect(driver, sEndofTerm, cmbEndTerm);
				lowlevellogsobj.info("Drawdown End of Term is selected as->"+sEndofTerm);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEndofTerm)));
				commfunct_Obj.commonSetTextTextBox(txt_EndofTerm,sEndDate);
				lowlevellogsobj.info("Drawdown End Date is entered as->"+sEndDate);
			}
			else{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEndTerm)));
				commfunct_Obj.comboSelect(driver, sEndofTerm, cmbEndTerm);
				lowlevellogsobj.info("Drawdown End of Term is selected as->"+sEndofTerm);
			}



			if(sFTRflag.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFTRflag)));
				commfunct_Obj.commonClick(btnFTRflag, "Yes");
				lowlevellogsobj.info("Free Text Rule Flag is Switched on");
			}
			else{
				lowlevellogsobj.info("Free Text Rule Flag is Switched off");
			}

			Thread.sleep(2000);

			if(sClickCreateEdit.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCreateEdit)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCreateEdit, "Yes");
				lowlevellogsobj.info("Clicked on Drawdown Create and Edit button");
				Appcommfunct_Obj.checkSavemessage(driver, Constants.newDDMsg);
				Thread.sleep(1000);
			}
			else{

			}

			result = true;

		}catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}

}
