/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateDrawdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class EditDrawdown {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	// private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(EditDrawdown.class);

	public EditDrawdown(WebDriver driver) {
	}

	@FindBy(xpath = "//*[text()='Expand']/../following::span[position()=1]")
	private WebElement cmbSlctlevel;

	@FindBy(xpath = "//*[text()='Edit']")
	private WebElement btnEdit;

	@FindBy(xpath = "//button[contains(@id,'idDrawdown')]/following::button[position()=1]//*[text()='Edit']")
	private WebElement btnCnfEdit;

	@FindBy(xpath = "//*[text()='Warning']")
	private WebElement labelWarning;

	public String xpSelectLevel = "//*[text()='Expand']/../following::span[position()=1]";
	public String xptitle = "//h1[contains(@class,'HeadTitle')]";
	public String xpdrawdownlink = "//a[text()='AutoDrawdown']";
	public String xpwarning = "//*[text()='Warning']";
	public String xpbtnEdit = "//button[contains(@id,'idDrawdown')]/following::button[position()=1]//*[text()='Edit']";
	public String xpbtnCnfEdit = "//*[text()='Edit Anyway']";

	public boolean tabEditdrawdown(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sEdit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_EditDrawdown_Edit);
		String sWarning = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_EditDrawdown_Warning);
		String sLevel = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_EditDrawdown_Level);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			lowlevellogsobj.info("Started in Overview Class");
			Thread.sleep(3000);

			
			if (sLevel.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSelectLevel)));
				commfunct_Obj.comboSelect(driver, sLevel, cmbSlctlevel);
				lowlevellogsobj.info("Level is selected as ->" + sLevel);
			}

			Thread.sleep(3000);
			if ((driver.findElements(By.xpath(xpdrawdownlink)).size() == 1)) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpdrawdownlink)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpdrawdownlink, "Yes");
				lowlevellogsobj.info("Clicked on drawdown link");
				Thread.sleep(3000);
			}

			if ((driver.findElements(By.xpath(xpbtnEdit)).size() == 1) && (sEdit.equalsIgnoreCase("Yes"))) {

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnEdit)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnEdit, "Yes");
				lowlevellogsobj.info("Clicked on Edit Button");
				Thread.sleep(3000);
			} else {
				lowlevellogsobj.info("Edit button is not displayed");
			}
			Thread.sleep(3000);
			if ((driver.findElements(By.xpath(xpwarning)).size() == 1) && (sWarning.equalsIgnoreCase("Yes"))) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpwarning)));
				commfunct_Obj.expectedValue(labelWarning, "text", sWarning, "Yes");
				lowlevellogsobj.info("Title of window (After Edit) is ->" + sWarning);

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnCnfEdit)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnCnfEdit, "Yes");
				lowlevellogsobj.info("Confirmed clicking on Edit Button");
				Thread.sleep(3000);
			} else {
				lowlevellogsobj.info("Warning is not displayed");

				Thread.sleep(3000);
			}
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in editing finance Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    

		return result;
	}

}
