/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class NewDisbursement {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(NewDisbursement.class);

	public NewDisbursement(WebDriver driver) {
	}

	@FindBy(xpath = "//h1[text()='Disbursement']")
	private WebElement titleHeader;

	@FindBy(xpath = "//div[contains(@id,'activate-Button')]")
	private WebElement radioActivate;
	
	@FindBy(xpath = "//div[contains(@id,'post-Button')]")
	private WebElement radioPost;
	
	@FindBy(xpath = "//*[contains(@id,'idFlowType-arrow')]")
	private WebElement cmbFlowtype;
	
	@FindBy(xpath = "//*[contains(text(),'Payment Date')]/../following::div[position()=2]//input")
	private WebElement txtPaymentdt;

	@FindBy(xpath = "//*[contains(text(),'Calculation Date')]/../following::div[position()=2]//input")
	private WebElement txtCalcdt;
	
	@FindBy(xpath = "//*[contains(text(),'Withhold Upto')]/../following::div[position()=2]//input")
	private WebElement txtWHUdt;
	
	@FindBy(xpath = "//*[contains(text(),'Full Disbursement')]/../following::div[position()=2]//div[contains(@id,'CbBg')]")
	private WebElement chkFD;
	
	@FindBy(xpath = "//*[contains(text(),'Settlement Amount')]/../following::div[position()=2]//input")
	private WebElement txtSettledamt;
	
	@FindBy(xpath = "//*[contains(text(),'Item Text')]/../following::div[position()=2]//textarea")
	private WebElement txtIT;
	
	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;
	
	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement btnSubmit;
	
	@FindBy(xpath = "//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]/*[text()='Business Operations']")
	private WebElement tabBO;
	
	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;
	
	@FindBy(xpath = "//div[@id='sap-ui-blocklayer-popup']")
    private WebElement ele_ScreenLoading;
	
	@FindBy(xpath = "//*[text()='OK']")
    private WebElement ele_OKbtn;
	

	public String xpFlowtype = "//*[contains(@id,'idFlowType-arrow')]";
	public String xpDisbtitle= "//h1[text()='Disbursement']";
	public String xpradioActivate = "//div[contains(@id,'activate-Button')]";
	public String xpradioPost = "//div[contains(@id,'post-Button')]";
	public String xpSettlementdt="//*[contains(text(),'Settlement Amount')]/../following::div[position()=2]//input";
	public String xpBO="//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]";
	public String xpId="//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr[2]/td[2]//span/span";
	public String xpAccnum="//header[contains(@id,'idDisbursementObjectPage-headerContent')]/div/child::div[position()=3]/child::div[position()=1]/div/span/span";
	public String xpCompanycode ="//header[contains(@id,'idDisbursementObjectPage-headerContent')]/div/child::div[position()=1]/child::div[position()=4]/div/span/span";
	public String xpPostdate="//header[contains(@id,'idDisbursementObjectPage-headerContent')]/div/child::div[position()=2]/child::div[position()=1]/div/span/span";
	public String xpchkFD="//*[contains(text(),'Full Disbursement')]/../following::div[position()=2]//div[contains(@id,'CbBg')]";
	public String xptxtsettlementAmt="//*[contains(text(),'Settlement Amount')]/../following::div[position()=2]//input";
	public String xpPostokbtn="//*[text()='OK']";
	public String xpPaymentdt = "//*[contains(text(),'Payment Date')]/../following::div[position()=2]//input";
	public String xpCalcdt = "//*[contains(text(),'Calculation Date')]/../following::div[position()=2]//input";
	public String xpWHUdt = "//*[contains(text(),'Withhold Upto')]/../following::div[position()=2]//input";
	public String xpIT = "//*[contains(text(),'Item Text')]/../following::div[position()=2]//textarea";
	public String xpSave = "//*[text()='Save']";
	public String xpSubmit = "//*[text()='Submit']";
	
	public boolean tabNewDisb(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Title);
		String sImmposting = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Imm_Posting);
		String sFlowType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_FlowType);
		String sPaymentDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_PaymentDate);
		String sCalculationDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_CalculationDate);
		String sWithHoldUpto = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_WithHoldUpto);
		String sType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Type);
		String sSettlement_Amount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Settlement_Amount);
		String sItem_Text = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Item_Text);
		String sSave = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Save);
		String sSubmit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewDisb_Submit);
		

		try {
			lowlevellogsobj.info("Inside New Disbursement Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDisbtitle)));
			commfunct_Obj.expectedValue(titleHeader, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);

			if(sImmposting.equalsIgnoreCase("Activate")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioActivate)));
				commfunct_Obj.commonClick(radioActivate,"Yes");
				lowlevellogsobj.info("Clicked on Activate radio button");
			}
			else{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioPost)));
				commfunct_Obj.commonClick(radioPost,"Yes");
				lowlevellogsobj.info("Clicked on Post radio button");
			}
			
			//Flow Type
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFlowtype)));
			commfunct_Obj.comboSelect(driver, sFlowType, cmbFlowtype);
			lowlevellogsobj.info("Flow Type is selected as->"+sFlowType);
			
			//Payment Date
			if(sPaymentDate.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentdt)));
				commfunct_Obj.commonSetTextTextBox(txtPaymentdt, sPaymentDate);
				lowlevellogsobj.info("Payment Date is entered as->"+sPaymentDate);
			}
			
			//Calculation Date
			if(sCalculationDate.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCalcdt)));
				commfunct_Obj.commonSetTextTextBox(txtCalcdt, sCalculationDate);
				lowlevellogsobj.info("Calculation Date is entered as->"+sCalculationDate);
			}
			
			//Withhold upto
			
			if(sWithHoldUpto.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpWHUdt)));
				commfunct_Obj.commonSetTextTextBox(txtWHUdt, sWithHoldUpto);
				lowlevellogsobj.info("Withhold upto Date is entered as->"+sWithHoldUpto);
			}
			txtWHUdt.sendKeys(Keys.TAB);
			//Full disbursement Flag
			Thread.sleep(2000);
			
			if(sType.equalsIgnoreCase("Partial")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpchkFD)));
				commfunct_Obj.commonClick(chkFD,"Yes");
				commfunct_Obj.commonWaitToNotDisplayElement(driver,15,screenloader);
				if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1)){
					result=false;
				}
				lowlevellogsobj.info("Partial Disbursement is opted");
				
				
				if(sSettlement_Amount.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxtsettlementAmt)));
					commfunct_Obj.commonSetTextTextBox(txtSettledamt, sSettlement_Amount);
					lowlevellogsobj.info("Settlement Amount is entered as-> "+sSettlement_Amount);
				}
			}else{
				lowlevellogsobj.info("Full Disbursement is opted");
			}
			
			
			//Item Text
			if(sItem_Text.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpIT)));
				commfunct_Obj.commonSetTextTextBox(txtIT, sItem_Text);
				lowlevellogsobj.info("Item Text is entered as->"+sItem_Text);
			}
			
			//Save
			if(sSave.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSave)));
				commfunct_Obj.commonClick(btnSave, "Yes");
				lowlevellogsobj.info("Save disbursement button is clicked");
				//Thread.sleep(2000);
				Appcommfunct_Obj.checkSavemessage(driver, Constants.Disbcreationmsg);
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
				Thread.sleep(3000);
				//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBO)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBO, "Yes");
				//commfunct_Obj.commonClick(tabBO, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpId)));
				String getId = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpId);
				System.out.println(getId);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BO, "REF_01", getId, 1);
			}
			
			//Submit
			if(sSubmit.equalsIgnoreCase("Yes")){
				
				//Capture Company Code
				String temp1 = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpCompanycode);
				String [] CCode = temp1.split(":");
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_UFT, "REF_01", CCode[1].trim(), 1);
				
				//Capture the account number
				String temp2 = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpAccnum);
				String [] Accnum = temp2.split(":");
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_UFT, "REF_01", Accnum[1].trim(), 2);
				
				//Capture the Date
				//String temp3 = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpPostdate);
				//String [] pDate = temp3.split(":");
				//ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_UFT, "REF_01", pDate[1].trim(), 3);
				
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmit)));
				commfunct_Obj.commonClick(btnSubmit, "Yes");
				lowlevellogsobj.info("Submit disbursement button is clicked");
				//Thread.sleep(2000);
				if(sImmposting.equalsIgnoreCase("Post")){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPostokbtn)));
					commfunct_Obj.commonClick(ele_OKbtn, "Yes");
				}
				
				Appcommfunct_Obj.checkSavemessage(driver, Constants.Disbsentapproval);
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
				Thread.sleep(2000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBO)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBO, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpId)));
				String getId = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpId);
				System.out.println(getId);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BO, "REF_02", getId, 1);
			}
			
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Disbursement Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}
}