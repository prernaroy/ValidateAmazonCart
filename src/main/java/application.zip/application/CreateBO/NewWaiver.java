/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class NewWaiver {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(NewWaiver.class);

	public NewWaiver(WebDriver driver) {
	}

	@FindBy(xpath = "//h1[text()='Waiver']")
	private WebElement titleHeader;

	@FindBy(xpath = "//div[contains(@id,'manageWaiver-component---ObjectPage--OverviewView--idActivateRadioBtn-Button')]")
	private WebElement radioActivate;
	
	@FindBy(xpath = "//div[contains(@id,'manageWaiver-component---ObjectPage--OverviewView--idPostRadioBtn-Button')]")
	private WebElement radioPost;
	
	@FindBy(xpath = "//tr[1]/td[3]//span/span/preceding::input/parent::div[contains(@id,'selectMulti-CbBg')]")
	private WebElement chkFlowtype;
	
	@FindBy(xpath = "//*[contains(text(),'Settlement Amount')]/../following::div[position()=2]//input")
	private WebElement txtSettledamt;
	
	@FindBy(xpath = "//*[contains(text(),'Item Text')]/../following::div[position()=2]//textarea")
	private WebElement txtIT;
	
	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;
	
	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement btnSubmit;
	
	@FindBy(xpath = "//*[text()='Business Operations']")
	private WebElement tabBO;
	
	@FindBy(xpath = "//*[text()='Waive']")
	private WebElement btnWaive;
	
	@FindBy(xpath = "//*[contains(text(),'Waived Amount')]/../following::div[position()=2]//input[contains(@id,'inner')]")
	private WebElement txt_Amtwaive;
	
	@FindBy(xpath = "//*[contains(text(),'Payment Date')]/../following::div[position()=2]//input[contains(@id,'inner')]")
	private WebElement txt_Paymentdt;
	
	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btnApply;
	
	
	

	public String xpFlowtype = "//*[contains(@id,'idFlowType-arrow')]";
	public String xptitle= "//h1[text()='Waiver']";
	public String xpSettlementdt="//*[contains(text(),'Settlement Amount')]/../following::div[position()=2]//input";
	public String xpBO="//*[text()='Business Operations']";
	public String xpId="//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr[2]/td[2]//span/span";
	public String xpAccnum="//header[contains(@id,'idDisbursementObjectPage-headerContent')]/div/child::div[position()=3]/child::div[position()=1]/div/span/span";
	public String xpCompanycode ="//header[contains(@id,'idDisbursementObjectPage-headerContent')]/div/child::div[position()=1]/child::div[position()=4]/div/span/span";
	public String xpPostdate="//header[contains(@id,'idDisbursementObjectPage-headerContent')]/div/child::div[position()=2]/child::div[position()=1]/div/span/span";
	public String xpErrormsg="//*[text()='Invalid key predicate']";
	public String xpAmtwaive = "//*[contains(text(),'Waived Amount')]/../following::div[position()=2]//input[contains(@id,'inner')]";
	public String xpradioActivate = "//div[contains(@id,'manageWaiver-component---ObjectPage--OverviewView--idActivateRadioBtn-Button')]";
	public String xpradioPost = "//div[contains(@id,'manageWaiver-component---ObjectPage--OverviewView--idPostRadioBtn-Button')]";
	public String xpSave = "//*[text()='Save']";
	public String xpSubmit = "//*[text()='Submit']";
	public String xpWaive = "//*[text()='Waive']";
	public String xpPaymentdt= "//*[contains(text(),'Payment Date')]/../following::div[position()=2]//input[contains(@id,'inner')]";
	public String xpApply = "//*[text()='Apply']";
	
	public boolean newWaiver(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_Title);
		String sImmposting = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_Imm_Posting);
		String sFlowType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_FlowType);
		String sBO_Text = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_BO_Text);
		String sWaivedamt = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_WaivedAmt);
		String sWaivedStatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_WaivedStatus);
		String sPaymentdate=commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_PaymentDate);
		String sSave = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_Save);
		String sSubmit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewWaiver_Submit);
		String sStatus = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_UFT, "REF_01",4);

		try {
			if(sStatus.equalsIgnoreCase("Successful")){
			lowlevellogsobj.info("Inside New Waiver Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			commfunct_Obj.expectedValue(titleHeader, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);

			if(sImmposting.equalsIgnoreCase("Activate")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioActivate)));
				commfunct_Obj.commonClick(radioActivate,"Yes");
				lowlevellogsobj.info("Clicked on Activate radio button");
			}
			else{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioPost)));
				commfunct_Obj.commonClick(radioPost,"Yes");
				lowlevellogsobj.info("Clicked on Post radio button");
			}
			
			//Flow Type
			
			WebElement flwType=driver.findElement(By.xpath("//table[contains(@aria-labelledby,'idOpenItems-header')]/tbody/tr[1]/td[3]//span[contains(text(),'"+sFlowType+"')]/preceding::div[contains(@id,'Single-Button')]"));
			commfunct_Obj.commonClick(flwType, "Yes");
			if(btnWaive.isEnabled()){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpWaive)));
				commfunct_Obj.commonClick(btnWaive, "Yes");
				lowlevellogsobj.info("Clicked on Waive button");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAmtwaive)));
				commfunct_Obj.commonSetTextTextBox(txt_Amtwaive, sWaivedamt);
				lowlevellogsobj.info("Waived Amount is enetered as ->"+sWaivedamt);
				if(sPaymentdate.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentdt)));
					commfunct_Obj.commonSetTextTextBox(txt_Paymentdt, sPaymentdate);
					lowlevellogsobj.info("Payment Date is enetered as ->"+sPaymentdate);
				}
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpApply)));
				commfunct_Obj.commonClick(btnApply, "Yes");
				lowlevellogsobj.info("Clicked on Apply button");
			}
			
			//Save
			if(sSave.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSave)));
				commfunct_Obj.commonClick(btnSave, "Yes");
				lowlevellogsobj.info("Save disbursement button is clicked");
				Thread.sleep(2000);
				
			}
			
			//Submit
			if(sSubmit.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmit)));	
				commfunct_Obj.commonClick(btnSubmit, "Yes");
				lowlevellogsobj.info("Submit Waiver button is clicked");
				Thread.sleep(2000);
				if(driver.findElements(By.xpath(xpErrormsg)).size()==1){
					result=false;
					lowlevellogsobj.error("Invalid Key Predicate Message displayed on click of Submit button");
					
				}
				if(driver.findElements(By.xpath("//*[text()='OK']")).size()==1){
					driver.findElement(By.xpath("//*[text()='OK']")).click();
					lowlevellogsobj.info("Clicked on Posting 'Ok' button");
				}
			}
			
			
			result = true;
		}
			else{
				lowlevellogsobj.error("UFT Job FNMS1 did not run as expected");
			}
			

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Disbursement Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    
		return result;
	}
}