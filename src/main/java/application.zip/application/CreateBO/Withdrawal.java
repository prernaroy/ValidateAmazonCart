/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class Withdrawal {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Withdrawal.class);


	public Withdrawal(WebDriver driver) {
	}

	@FindBy(xpath = "//h1[text()='Withdrawal']")
	private WebElement titleHeader;

	@FindBy(xpath = "//*[@id='application-LoansWplcFinancing-renew-component---renewal--OffersView--idConditionHeaderTable']/descendant::button[position()=2]/span")
	private WebElement btnAddrenewal;

	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement btnSubmit;

	@FindBy(xpath = "//*[text()='Business Operations']")
	private WebElement tabBO;

	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btnApply;

	@FindBy(xpath = "//*[text()='Create']")
	private WebElement btnCreate;

	@FindBy(xpath = "//label[text()='Type']/following::span[position()=1][contains(@id,'arrow')]")
	private WebElement cmbType;

	@FindBy(xpath = "//label[text()='Calculation Date']/following::input[position()=1]")
	private WebElement txtCD;

	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;


	@FindBy(xpath = "//*[contains(@id,'renew-component---condHeader--Conditions-anchor-content')]")
	private WebElement renewConditionstab;

	@FindBy(xpath = "//label[text()='Type']/following::input[position()=1]")
	private WebElement txtype;

	@FindBy(xpath = "//*[text()='Non-Acceptance']/following::span[contains(@id,'arrow')]")
	private WebElement cmbNA;
	
	@FindBy(xpath = "//*[contains(@id,'BusinessOperationsView--idSelect-arrow')]")
	private WebElement cmbSelectBO;
	
	
	
	
	public String xptitle= "//h1[text()='Withdrawal']";
	public String xpNA="//*[text()='Non-Acceptance']/following::span[contains(@id,'arrow')]";
	public String xpBO="//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]";
	public String xpApprovalstatus="//*[text()='Type: Withdrawal']/following::span[position()=8]";	
	public String xpFixeduntil= "//input[contains(@id,'renew-component---condHeader--ConditionsView--FixedPerEnd-datePicker-inner')]";
	public String xpType="//label[text()='Type']/following::span[position()=1][contains(@id,'arrow')]";
	public String xptxtType="//label[text()='Type']/following::input[position()=1]";
	public String xpID="//*[text()='Type: Withdrawal']/following::span[position()=1]";
	public String xpSbmt = "//*[text()='Submit']";	
	public String xpCD = "//label[text()='Calculation Date']/following::input[position()=1]";
	
	public boolean boWithdrawal(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Withdrwal_Title);
		String sCD= commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Withdrwal_CalculationDate);
		String sNA = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Withdrwal_NonAcceptance);
		String sSubmit= commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Withdrwal_Submit);
		
		
		
		try {
			lowlevellogsobj.info("Inside Withdrawal Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			commfunct_Obj.expectedValue(titleHeader, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);

			
			if(sCD.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCD)));
				commfunct_Obj.commonSetTextTextBox(txtCD, sCD);
				lowlevellogsobj.info("Calculation Date is entered as ->"+sCD);
			}
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpNA)));
			commfunct_Obj.comboSelect(driver, sNA, cmbNA);
			
			
			//Click on Submit button
			
			if(sSubmit.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSbmt)));
				commfunct_Obj.commonClick(btnSubmit, "Yes");
				Appcommfunct_Obj.checkSavemessage(driver, Constants.submitWithdrawal);
				Thread.sleep(2000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBO)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBO, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpApprovalstatus)));
								
				
				String getId = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpID);
				System.out.println(getId);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BO, "REF_04", getId, 1);
				result = true;
			}


		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Disbursement Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
			if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
				Thread.sleep(1000);
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->"+geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
				result=false;
			}
			else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->"+geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
				result=false;
			}
			else {
				MsgList.add("Application Dump did not occur");
			}
		}    
		return result;
	}
}