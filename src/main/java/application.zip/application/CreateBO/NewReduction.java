/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class NewReduction {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(NewReduction.class);

	public NewReduction(WebDriver driver) {
	}

	@FindBy(xpath = "//h1[text()='Reduction']")
	private WebElement titleHeader;

	@FindBy(xpath = "//*[contains(text(),'Reduction Amount')]/../following::div[position()=2]//input")
	private WebElement txtReductionAmnt;

	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement btnSubmit;

	@FindBy(xpath = "//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]/*[text()='Business Operations']")
	private WebElement tabBO;

	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;

	public String xpReductiontitle = "//h1[text()='Reduction']";
	public String xpReductionAmnt = "//*[contains(text(),'Reduction Amount')]/../following::div[position()=2]//input";
	public String xpBO = "//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]";
	public String xpId = "//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr[2]/td[2]//span/span";
	public String xpSave = "//*[text()='Save']";
	public String xpSubmit = "//*[text()='Submit']";
	
	public boolean tabNewReduc(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewReduction_Title);
		String sReductionAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_NewReduction_ReductionAmount);
		String sSave = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewReduction_Save);
		String sSubmit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_NewReduction_Submit);

		try {
			lowlevellogsobj.info("Inside New Reduction Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReductiontitle)));
			commfunct_Obj.expectedValue(titleHeader, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);

			// Reduction Amount
			if (sReductionAmount.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReductionAmnt)));
				commfunct_Obj.commonSetTextTextBox(txtReductionAmnt, sReductionAmount);
				lowlevellogsobj.info("Reduction amount is entered as->" + sReductionAmount);
			}

			// Save
			if (sSave.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSave)));
				commfunct_Obj.commonClick(btnSave, "Yes");
				lowlevellogsobj.info("Save reduction button is clicked");
				Thread.sleep(2000);
			}

			// Submit
			if (sSubmit.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmit)));
				commfunct_Obj.commonClick(btnSubmit, "Yes");
				lowlevellogsobj.info("Submit reduction button is clicked");
				// Thread.sleep(2000);
				Appcommfunct_Obj.checkSavemessage(driver, Constants.submitReductionmsg);
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
				Thread.sleep(1000);
				/*wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBO)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBO, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpId)));
				String getId = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpId);
				System.out.println(getId);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BO, "REF_03", getId, 2);*/
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Reduction Detail:  " + e.getMessage(), e);
			result = false;
		} finally {
			if ((driver.findElements(By.xpath("//a[text()='Show Details']")).size() == 1)
					&& (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size() == 1)) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
				Thread.sleep(1000);
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath",
						"//div[contains(@class,'sapMMessageBoxDetails')]");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->" + geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
				result = false;
			} else if (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size() == 1) {
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath",
						"//div[@class='sapMDialogScrollCont']/span");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->" + geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
				result = false;
			} else {
				MsgList.add("Application Dump did not occur");
			}
		}

		return result;
	}
}