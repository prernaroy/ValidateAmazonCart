/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class BorrowerChange {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(BorrowerChange.class);

	public BorrowerChange(WebDriver driver) {
	}

	@FindBy(xpath = "//h1[text()='Borrower Change']")
	private WebElement titleHeader;
	
	@FindBy(xpath = "//label[contains(text(),'New Main Borrower')]/../following::div[position()=1]//span[contains(@id,'vhi')]")
	private WebElement cmbMB;
	
	@FindBy(xpath = "//div[contains(@data-sap-ui-related,'rows-row0')]")
	private WebElement cmbMBsel;
	
	@FindBy(xpath = "//label[contains(text(),'Reason')]/../following::div[position()=1]//span[contains(@id,'comboBoxEdit-arrow')]")
	private WebElement cmbReason;
	
	@FindBy(xpath = "//span[contains(@id,'idPaymentMethod-arrow')]")
	private WebElement cmbPaymentMethod;
	
	@FindBy(xpath = "//*[contains(@id,'idAccountInType-arrow')]")
	private WebElement cmbAccount;
	
	@FindBy(xpath = "//li[contains(@id,'idAccountInType')]//span[text()='AutoDrawdown']")
	private WebElement cmbAccntoption;
	
	@FindBy(xpath = "//span[contains(@id,'idFlowType-arrow')]")
	private WebElement cmbFlowType;
	
	@FindBy(xpath = "//label[contains(text(),'Bank Details ID')]/../following::div[position()=1]//span[contains(@id,'vhi')]")
	private WebElement cmbBankdtls;
	
	@FindBy(xpath = "//*[contains(text(),'Alternative Payer')]/../following::div[position()=2]//div[contains(@id,'CbBg')]")
	private WebElement chkAP;
	
	@FindBy(xpath = "//*[contains(text(),'Authorized Drawer')]/../following::div[position()=2]//div[contains(@id,'CbBg')]")
	private WebElement chkAD;
	
	@FindBy(xpath = "//div[contains(@id,'manageBorrowerChange')]//*[text()='Attach Charge']/../following::div[position()=3]/div/div[contains(@class,'Rb')]")
	public WebElement radbtn_AtchCharge;

	@FindBy(xpath = "//button[@title='Go']")
	private WebElement btnGo;
	
	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Submit']")
	private WebElement btnSubmit;

	@FindBy(xpath = "//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]/*[text()='Business Operations']")
	private WebElement tabBO;

	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;

	public String xpBOtitle = "//h1[text()='Borrower Change']";
	
	public String xpBO = "//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]";
	public String xpId = "//table[contains(@aria-labelledby,'idBusinessTransactionsTable')]/tbody/tr[2]/td[2]//span/span";
	
	public String xpMainBorrower = "//label[contains(text(),'New Main Borrower')]/../following::div[position()=1]//span[contains(@id,'vhi')]";
	public String xpBorrowerName = "//a[@role='link']";
	public String xpMBSearch = "//input[contains(@id,'input-valueHelpDialog-smartFilterBar-filterItemControlA_-Partner-inner')]";
	public String xpMBSelect = "//div[contains(@data-sap-ui-related,'rows-row0')]";
	public String xpDuedate = "//*[contains(text(),'Due Date')]/../following::div[position()=1]//input";
	public String xpTransferdate = "//*[contains(text(),'Transfer Date')]/../following::div[position()=1]//input";
	public String xpChargeAmnt = "//*[contains(text(),'Charge Amount')]/../following::div[position()=1]//input";
	public String xpToAccnt = "//*[contains(@id,'idAccountInType-label')]";
	public String xpGo = "//button[@title='Go']";
	public String xpReason = "//label[contains(text(),'Reason')]/../following::div[position()=1]//span[contains(@id,'comboBoxEdit-arrow')]";
	public String xpPaymentMethod = "//span[contains(@id,'idPaymentMethod-arrow')]";
	public String xpBankdtls = "//label[contains(text(),'Bank Details ID')]/../following::div[position()=1]//span[contains(@id,'vhi')]";
	public String xpAP = "//*[contains(text(),'Alternative Payer')]/../following::div[position()=2]//div[contains(@id,'CbBg')]";
	public String xpAD = "//*[contains(text(),'Authorized Drawer')]/../following::div[position()=2]//div[contains(@id,'CbBg')]";
	public String xpAtchCharge = "//div[contains(@id,'manageBorrowerChange')]//*[text()='Attach Charge']/../following::div[position()=3]/div/div[contains(@class,'Rb')]";
	public String xpAccount = "//*[contains(@id,'idAccountInType-arrow')]";
	public String xpAccntoption = "//li[contains(@id,'idAccountInType')]//span[text()='AutoDrawdown']";
	public String xpFlowType = "//span[contains(@id,'idFlowType-arrow')]";
	public String xpSave = "//*[text()='Save']";
	public String xpSubmit = "//*[text()='Submit']";
	
	public boolean tabBOChange(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_BOChange_Title);
		String sMainBorrower = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_MainBorrower);
		String sBorrowerName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_BorrowerName);
		String sTransferDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_TransferDate);
		String sReason = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_Reason);
		String sPaymentMethod = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_PaymentMethod);
		String sBankdtls = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_BankDetails);
		String sPayer = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_AlternativePayer);
		String sDrawer = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_AuthorizedDrawer);
		String sAttachCharge = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_AttachCharge);
		String sToAccount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_ToAccount);
		String sChargeAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_ChargeAmount);
		String sDueDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_DueDate);
		String sFlowtype = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_BOChange_Flowtype);
		String sSave = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_BOChange_Save);
		String sSubmit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_BOChange_Submit);
		
		try {
			lowlevellogsobj.info("Inside New BO Change Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBOtitle)));
			commfunct_Obj.expectedValue(titleHeader, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(2000);

			// Main Borrower
			if (sMainBorrower.length() > 0) {
				
				commfunct_Obj.commonClick(cmbMB, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBSearch)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpMBSearch, "Yes", sMainBorrower);
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpGo)));
				commfunct_Obj.commonClick(btnGo, "Yes");
				lowlevellogsobj.info("Clicked on Go button");
				Thread.sleep(2000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBSelect)));
				commfunct_Obj.commonClick(cmbMBsel, "Yes");	
				lowlevellogsobj.info("Main Borrower is entered as->" + sMainBorrower);
			}
			
			Thread.sleep(1000);
			// Transfer Date
			if (sTransferDate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTransferdate)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpTransferdate, "Yes", sTransferDate);
				lowlevellogsobj.info("TransferDate is entered as->" + sTransferDate);
				Thread.sleep(2000);
			}
			// Reason for change
			if (sReason.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReason)));
				commfunct_Obj.comboSelect(driver, sReason, cmbReason);
				Thread.sleep(2000);
				lowlevellogsobj.info("Reason is selected as ->" + sReason);
			}
			
			// Payment method
			if (sPaymentMethod.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentMethod)));
				commfunct_Obj.comboSelect(driver, sPaymentMethod, cmbPaymentMethod);
				Thread.sleep(2000);
				lowlevellogsobj.info("Payment method is selected as ->" + sPaymentMethod);
			}

			
			// Bank details 
			if (sBankdtls.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBankdtls)));
				commfunct_Obj.commonClick(cmbBankdtls, "Yes");				
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMBSelect)));
				commfunct_Obj.commonClick(cmbMBsel, "Yes");
				lowlevellogsobj.info("Bank details is entered as ->" + sBankdtls);
				
			}
			
			//Alternative Payer Flag
			
			if (sPayer.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAP)));
				commfunct_Obj.commonClick(chkAP,"Yes");
				lowlevellogsobj.info("Alternative Payer is opted");
				Thread.sleep(1000);
			}else{
				lowlevellogsobj.info("Alternative Payer is  not opted");
			}
			
			//Authorized Drawer Flag
			
			if (sDrawer.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAD)));
				commfunct_Obj.commonClick(chkAD,"Yes");
				lowlevellogsobj.info("Authorized Drawer is opted");
				Thread.sleep(1000);
			}else{
				lowlevellogsobj.info("Authorized Drawer is  not opted");
			}
			
			if(sAttachCharge.length()>0){
				if(sAttachCharge.equalsIgnoreCase("Yes")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAtchCharge)));
					commfunct_Obj.commonClick(radbtn_AtchCharge, "Yes");
					Thread.sleep(2000);
					lowlevellogsobj.info("Attach Charge is selected as ->"+sAttachCharge);	
				}
				
			}
			
			// Account details
			if (sToAccount.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAccount)));
				commfunct_Obj.commonClick(cmbAccount, "Yes");
				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAccntoption)));
				commfunct_Obj.commonClick(cmbAccntoption, "Yes");
				Thread.sleep(2000);
				lowlevellogsobj.info("FlowType is selected as ->" + sFlowtype);
			}
			
			// Flow type
			if (sFlowtype.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFlowType)));
				commfunct_Obj.comboSelect(driver, sFlowtype, cmbFlowType);
				Thread.sleep(2000);
				lowlevellogsobj.info("FlowType is selected as ->" + sFlowtype);
			}
			
			// Due Date
			if (sDueDate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDuedate)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpDuedate, "Yes", sDueDate);
				lowlevellogsobj.info("Duedate is entered as->" + sDueDate);
				Thread.sleep(2000);
			}
			
			// Charge Amount
			if (sChargeAmount.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpChargeAmnt)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpChargeAmnt, "Yes", sChargeAmount);
				lowlevellogsobj.info("Charge Amount is entered as->" + sChargeAmount);
				Thread.sleep(2000);
			}


			// Save
			if (sSave.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSave)));
				commfunct_Obj.commonClick(btnSave, "Yes");
				lowlevellogsobj.info("Save reduction button is clicked");
				Thread.sleep(2000);
			}

			// Submit
			if (sSubmit.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmit)));
				commfunct_Obj.commonClick(btnSubmit, "Yes");
				lowlevellogsobj.info("Submit BO change button is clicked");
				// Thread.sleep(2000);
				Appcommfunct_Obj.checkSavemessage(driver, Constants.submitBOmsg);
				commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
				Thread.sleep(1000);
				/*wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBO)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBO, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpId)));
				String getId = commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpId);
				System.out.println(getId);
				ds.updateCellDate(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_BO, "REF_03", getId, 2);*/
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Reduction Detail:  " + e.getMessage(), e);
			result = false;
		} finally {
			if ((driver.findElements(By.xpath("//a[text()='Show Details']")).size() == 1)
					&& (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size() == 1)) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
				Thread.sleep(1000);
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath",
						"//div[contains(@class,'sapMMessageBoxDetails')]");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->" + geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
				result = false;
			} else if (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size() == 1) {
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath",
						"//div[@class='sapMDialogScrollCont']/span");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->" + geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
				result = false;
			} else {
				MsgList.add("Application Dump did not occur");
			}
		}

		return result;
	}
}