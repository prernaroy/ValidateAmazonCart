/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class BOOverview {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(BOOverview.class);
	
	public WebDriver driver1;
	
	public BOOverview(WebDriver driver) {
	}

	@FindBy(xpath = "//h1")
	public WebElement txt_ScreenName;

	@FindBy(xpath = "//*[text()='Expand']/../following::span[position()=1]")
	public WebElement cmbSlctlevel;

	@FindBy(xpath = "//h1[contains(@id,'application-LoansWplcFinancing-manage-component---dealDisplay--idDealDisplayHeader-title')]")
	public WebElement title_Header;


	@FindBy(xpath = "//*[text()='Disbursement']")
	public WebElement eledisbursement;

	@FindBy(xpath = "//*[text()='Create Business Operation']")
	public WebElement btn_CreateBO;

	@FindBy(xpath =  "//div[@title='Click to Select' and @aria-level='3']")
	public WebElement chk_drawdown;

	public String xpSelectLevel = "//*[text()='Expand']/../following::span[position()=1]";
	public String xpHeadertitle = "//h1[contains(@id,'application-LoansWplcFinancing-manage-component---dealDisplay--idDealDisplayHeader-title')]";
	//public String xpHeadertitle = "//h1";
	public String xpSelectdrawdown = "//div[@title='Click to Select' and @aria-level='3']";
	public String xpDisbursement = "//*[text()='Disbursement']";
	public String xpWaiver = "//button//*[text()='Waiver']";
	public String xpReversal = "//button//*[text()='Reversal']";
	public String xpCreateBO = "//*[text()='Create Business Operation']";
	public String xpDisbtitle= "//h1[text()='Disbursement']";
	public String xpWaivertitle= "//h1[text()='Waiver']";
	public String xpRenewal = "//button//*[text()='Renewal']";
	public String xpRenewaltitle= "//h1[text()='Renewal']";
	public String xpReversaltitle= "//*[text()='Loans: Initial Screen for Reversal']";
	public String xpgetAccnum="//table[contains(@id,'DealOverviewView--OverviewTreeTable-table')]/tbody/tr[3]/td[13]//a";
	public String xpRevurl="https://ldcirpg.wdf.sap.corp:44311/sap/bc/gui/sap/its/webgui/?sap-client=110&sap-language=EN&~transaction=FNM3&~Okcode=BUS_MAIN_ENTER&VDARL-BUKRS=0101&RMF67-XRANL=";
	public String xpWithdrawaltitle= "//h1[text()='Withdrawal']";
	public String xpWithdrawal="//button//*[text()='Withdrawal']";
	
	
	
	public boolean tabDisbOverview(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);

		String sName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_OverviewDisbursement_Name);
		String sLevel = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_OverviewDisbursement_Level);
		String sBOType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_OverviewDisbursement_BOType);
		//String DBO=commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_OverviewDisbursement_DisabledBO);
		try {
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpHeadertitle)));
			commfunct_Obj.expectedValue(title_Header, "text", sName, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sName + " Screen");
			Thread.sleep(3000);

			
			if(sLevel.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSelectLevel)));
				commfunct_Obj.comboSelect(driver, sLevel, cmbSlctlevel);
				lowlevellogsobj.info("Level is selected as ->" + sLevel);
			}

			commfunct_Obj.waitUntilDocumentIsReady(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSelectdrawdown)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSelectdrawdown, "Yes");
			lowlevellogsobj.info("Clicked on Drawdown level checkbox");
			Thread.sleep(2000);
			
			//Store the account num
			WebElement element = driver.findElement(By.xpath(xpgetAccnum));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(500); 
			String getAccnum=commfunct_Obj.commonFindElement_GetText(driver, "xpath", xpgetAccnum);
			String revNavigate = xpRevurl+getAccnum;
			System.out.println(revNavigate);
			

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCreateBO)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCreateBO, "Yes");
			lowlevellogsobj.info("Clicked on Create Business Operation Button");
			Thread.sleep(3000);
	

			if(sBOType.equalsIgnoreCase("Disbursement")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDisbursement)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDisbursement, "Yes");
				lowlevellogsobj.info("Clicked on Disbursement option");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDisbtitle)));
			}
			else if(sBOType.equalsIgnoreCase("Waiver")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpWaiver)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpWaiver, "Yes");
				lowlevellogsobj.info("Clicked on Waiver option");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpWaivertitle)));
			}
			else if(sBOType.equalsIgnoreCase("Write-Off")){
				
			}
			else if(sBOType.equalsIgnoreCase("Renewal")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpRenewal)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpRenewal, "Yes");
				lowlevellogsobj.info("Clicked on Renewal option");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpRenewaltitle)));
				
			}
			else if(sBOType.equalsIgnoreCase("Reversal")){
				
				String parentHandle = driver.getWindowHandle();
	            System.out.println("Parent Window"+parentHandle);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReversal)));
				driver.navigate().to(revNavigate);
								
			}
			
			else if(sBOType.equalsIgnoreCase("Withdrawal")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpWithdrawal)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpWithdrawal, "Yes");
				lowlevellogsobj.info("Clicked on Withdrawal option");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpWithdrawaltitle)));
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Disbursement Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}
}