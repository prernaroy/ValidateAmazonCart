/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Nov 28, 2017
 */
package application.CreateBO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author C5268933
 *
 */
public class Reversal {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Reversal.class);
	public BOOverview boo;
	
	public Reversal(WebDriver driver) {
	}

	@FindBy(xpath = "//*[text()='Loans: Initial Screen for Reversal']")
	private WebElement titleHeader;
	
	@FindBy(xpath = "//*[text()='From']/following::tr[position()=1]//input")
	private WebElement txtFrom;

	@FindBy(xpath = "//*[text()='To']/following::tr[position()=1]//input")
	private WebElement txtTo;

	@FindBy(xpath = "//div[@title='Enter (Enter)']")
	private WebElement btnEnter;

	@FindBy(xpath = "//div[@ct='ALC']/span")
	private WebElement chkSelect;
	
	@FindBy(xpath = "//div[@title='Post (F9)']")
	private WebElement btnPost;
	
	@FindBy(xpath = "//*[text()='Text']/following::input[position()=1]")
	private WebElement postingText;
	
	@FindBy(xpath = "//input[@title='Reason for Reversal']")
	private WebElement postingReversaltxt;
	
	@FindBy(xpath = "//div[@title='ENTER (Enter)']")
	private WebElement postingBtnenter;
	
	@FindBy(xpath = "//*[text()='Posting Log']")
	private WebElement postinglogTitle;
	
	@FindBy(xpath = "//span[@title='Exit (Shift+F3)']")
	private WebElement exitLog;
	
	public static String parentWindowHandle=null;
	public static String parent = null;
	public static String child = null;
	
	
	public String xptitle= "//*[text()='Loans: Initial Screen for Reversal']";
	public String xpbtnPost="//div[@title='Post (F9)']";
	public String xpbtnEnter="//div[@title='Enter (Enter)']";
	public String xpTxt="//*[text()='Text']/following::input[position()=1]";
	public String xpPostingreversaltxt="//input[@title='Reason for Reversal']";
	public String xpPostingbtnenter="//div[@title='ENTER (Enter)']";
	public String xpLogtitle="//*[text()='Posting Log']";
	public String xpBO="//*[contains(@id,'idDealDisplayPage-anchBar-application-LoansWplcFinancing-manage-component---dealDisplay--DealBusinessOperations-anchor-content')]";
	public String xpApprovalstatus="//*[text()='Type: Renewal']/following::span[position()=8]";	
	public String xpType="//label[text()='Type']/following::span[position()=1][contains(@id,'arrow')]";
	public String xptxtType="//label[text()='Type']/following::input[position()=1]";
	public String xpID="//*[text()='Type: Renewal']/following::span[position()=1]";
	public String xpUserid = "//input[@id='sap-user']";
	public String xpPassword="//input[@id='sap-password']";
	public String xptnLogon="//span[@id='LOGON_BUTTON-cnt']";
	public String xpFrom = "//*[text()='From']/following::tr[position()=1]//input";
	public String xpTo = "//*[text()='To']/following::tr[position()=1]//input";
	
	public boolean boReversal(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 100);

		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Reversal_Title);
		String sFromDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Reversal_FromDate);
		String sToDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Reversal_ToDate);
		String sText = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Reversal_Text);
		String sRevsersal=commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_Reversal_ReasonForReversal);
		String sUname=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_LOGIN, "REF_01",2);
		String sPassword=ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_LOGIN, "REF_01",3);		
		try {
			lowlevellogsobj.info("Inside Reversal Class");
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			
					
			/*Set<String> handles = driver.getWindowHandles();
			System.out.println(handles);
			for(String handle1 : driver.getWindowHandles()){
				System.out.println(handle1);
			    driver.switchTo().window(handle1);
			    
			   
			}*/
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("ITSFRAME1"));
			
			/*wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpUserid)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpUserid, "Yes", sUname);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPassword)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpPassword, "Yes", sPassword);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptnLogon)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xptnLogon, "Yes");
			Thread.sleep(5000);*/
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			commfunct_Obj.expectedValue(titleHeader, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);

			
			if(sFromDate.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFrom)));
				commfunct_Obj.commonSetTextTextBox(txtFrom, sFromDate);
				lowlevellogsobj.info("From date is entered as ->"+sFromDate);
			}


			if(sToDate.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTo)));
				commfunct_Obj.commonSetTextTextBox(txtTo, sToDate);
				lowlevellogsobj.info("To date is entered as ->"+sToDate);
			}
			Thread.sleep(500);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnEnter)));
			commfunct_Obj.commonClick(btnEnter, "Yes");
			lowlevellogsobj.info("Enter button is clicked");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnPost)));
			Thread.sleep(2000);
			
			//Select the checkbox
			
			commfunct_Obj.commonClick(chkSelect, "Yes");
			lowlevellogsobj.info("Checkbox is ticked");
			Thread.sleep(500);
			commfunct_Obj.commonClick(btnPost, "Yes");
			lowlevellogsobj.info("Post button is clicked");
			driver.switchTo().defaultContent();
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("URLSPW-0"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTxt)));
			commfunct_Obj.commonSetTextTextBox(postingText, sText);
			lowlevellogsobj.info("Posting Text is entered as ->"+sText);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPostingreversaltxt)));
			commfunct_Obj.commonSetTextTextBox(postingReversaltxt, sRevsersal);
			lowlevellogsobj.info("Posting Reversal Text is entered as ->"+sRevsersal);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPostingbtnenter)));
			commfunct_Obj.commonClick(postingBtnenter, "Yes");
			lowlevellogsobj.info("Enter button is clicked");
			driver.switchTo().defaultContent();
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("ITSFRAME1"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpLogtitle)));
			commfunct_Obj.expectedValue(postinglogTitle, "text", "Posting Log", "Yes");
			lowlevellogsobj.info("Landed successfully on " + "Posting Log" + " Screen");
			result=true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in handling New Disbursement Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
			if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
				Thread.sleep(1000);
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->"+geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
				result=false;
			}
			else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->"+geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
				result=false;
			}
			else {
				MsgList.add("Application Dump did not occur");
			}
		}    
		return result;
	}
}