/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.References;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class References {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(References.class);

	public References(WebDriver driver) {
	}
	
	@FindBy(xpath = "//*[contains(@id,'ReferencesTableView')]/following::button[position()=3]//span[contains(@id,'img')]")
	private WebElement btn_AddReferences;
	
	@FindBy(xpath = "//*[contains(@id,'Reftype-comboBoxEdit-arrow')]")
	private WebElement cmb_RefType;
	
	@FindBy(xpath = "//input[contains(@id,'ReferenceTable--Url-input')]")
	private WebElement txt_RefURL;
	
	@FindBy(xpath = "//input[contains(@id,'ReferenceTable--Description-input-inner')]")
	private WebElement txt_RefName;
	
	@FindBy(xpath = "//input[contains(@id,'idValidFrom-datePicker-inner')]")
	private WebElement txt_RefFrom;
	
	@FindBy(xpath = "//input[contains(@id,'idvalidto-datePicker-inner')]")
	private WebElement txt_RefTo;
	
	@FindBy(xpath = "//footer/child::button[position()=1]//*[text()='Create']")
	private WebElement btn_RefCreate;
	
	public String xpReftype="//span[contains(@id,'Reftype-comboBoxEdit-arrow')]";
	public String xpRefnumber="//label[text()='Reference Number']/following::input[position()=1]";
	public String xpURL="//input[contains(@id,'ReferenceTable--Url-input')]";
	public String xpName="//input[contains(@id,'ReferenceTable--Description-input-inner')]";
	public String xpFrom="//input[contains(@id,'idValidFrom-datePicker-inner')]";
	public String xpTo="//input[contains(@id,'idvalidto-datePicker-inner')]";
	
	
	public String xpReftab="//*[text()='References']";
	public String xpBtnaddRef="//*[contains(@id,'ReferencesTableView')]/following::button[position()=3]//span[contains(@id,'img')]";
	public String xpBtnrefcreate="//footer/child::button[position()=1]//*[text()='Create']";

	public boolean tabReferences(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
					throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sReftype = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_REFERENCES_RefType);
		String sRefnumber = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_REFERENCES_Refnumber);
		String sURL = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_REFERENCES_URL);
		String sName = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_REFERENCES_Name);
		String sFrom = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_REFERENCES_From);
		String sTo = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_REFERENCES_To);
		
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReftab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpReftab, "Yes");
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBtnaddRef)));
			lowlevellogsobj.info("Started in References Class");
			Thread.sleep(2000);
			//Click on Add Reference icon
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBtnaddRef, "Yes");
			Thread.sleep(3000);
			
			if(sReftype.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReftype)));
			commfunct_Obj.comboSelect(driver, sReftype, cmb_RefType);
			lowlevellogsobj.info("Reference Type is selected as->"+sReftype);
			Thread.sleep(2000);
			}
			
			if(sRefnumber.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpRefnumber)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpRefnumber, "Yes", sRefnumber);
			lowlevellogsobj.info("Reference number is entered as->"+sRefnumber);
			Thread.sleep(1000);
			}
			
			if(sURL.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpURL)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpURL, "Yes", sURL);
			lowlevellogsobj.info("URL is entered as->"+sURL);
			Thread.sleep(1000);
			}
			
			if(sName.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpName, "Yes", sName);
			lowlevellogsobj.info("Name is entered as->"+sName);
			Thread.sleep(1000);
			}
			
			if(sFrom.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFrom)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpFrom, "Yes", sFrom);
			lowlevellogsobj.info("From is entered as->"+sFrom);
			Thread.sleep(1000);
			}
			
			if(sTo.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTo)));
			commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpTo, "Yes", sTo);
			lowlevellogsobj.info("To is entered as->"+sTo);
			Thread.sleep(1000);
			}
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBtnrefcreate)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpBtnrefcreate, "Yes");
			lowlevellogsobj.info("Clicked on Reference Create button");
			
			result = true;
			
		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}
	
}
