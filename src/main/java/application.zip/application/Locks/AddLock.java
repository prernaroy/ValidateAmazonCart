/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Locks;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class AddLock {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(AddLock.class);

	public AddLock(WebDriver driver) {
	}

	@FindBy(xpath = "//*[contains(@id,'LocksTableView')]/following::button[position()=3]//span[contains(@id,'img')]")
	private WebElement btn_Addlock;

	@FindBy(xpath = "//*[contains(@id,'idLock-arrow')]")
	private WebElement cmbLocktype;

	@FindBy(xpath = "//*[text()='Valid From']/following::div[position()=1]//input[contains(@id,'datePicker')]")
	private WebElement txt_Validfrom;

	@FindBy(xpath = "//*[text()='Valid To']/following::div[position()=1]//input[contains(@id,'datePicker')]")
	private WebElement txt_ValidTo;

	@FindBy(xpath = "//input[contains(@id,'drawDownExcempt-input')]")
	private WebElement txt_EA;

	@FindBy(xpath = "//footer[contains(@id,'LocksTableDialog-footer')]//*[text()='Create']")
	private WebElement btnLockCreate;

	public String xpAddlock="//*[contains(@id,'LocksTableView')]/following::button[position()=3]//span[contains(@id,'img')]";
	public String xpLockstab="//*[text()='Locks']";
	public String xpLocktype="//span[contains(@id,'idLock-arrow')]";
	public String xpValidfrom = "//*[text()='Valid From']/following::div[position()=1]//input[contains(@id,'datePicker')]";
	public String xpValidTo= "//*[text()='Valid;To']/following::div[position()=1]//input[contains(@id,'datePicker')]";
	public String xpEA = "//input[contains(@id,drawDownExcempt-input')]";
	public String xpLockCreate = "//footer[contains(@id,'LocksTableDialog-footer')]//*[text()='Create']";
	
	
	public boolean tabLocks(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sAddLocks = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_LOCKS_Add);
		String sLocktype = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_LOCKS_LockType);
		String sFrom = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_LOCKS_ValidFrom);
		String sTo = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_LOCKS_ValidTo);
		String sEA = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_LOCKS_ExemptionAmount);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpLockstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpLockstab, "Yes");
		
			lowlevellogsobj.info("Started in Locks Class");
			if(sAddLocks.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddlock)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpAddlock, "Yes");
				lowlevellogsobj.info("Add Lock button is clicked");
				Thread.sleep(2000);


			
				if(sLocktype.length()>0){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpLocktype)));
					commfunct_Obj.comboSelect(driver, sLocktype, cmbLocktype);
					lowlevellogsobj.info("Lock Type is Selected as->"+sLocktype);
					Thread.sleep(1000);
				}

				if (sFrom.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
					commfunct_Obj.commonSetTextTextBox(txt_Validfrom, sFrom);
					lowlevellogsobj.info("From Date is entered as->" + sFrom);
				}

				if (sTo.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidTo)));
					commfunct_Obj.commonSetTextTextBox(txt_ValidTo, sTo);
					lowlevellogsobj.info("To Date is entered as->" + sTo);
				}

				if (sEA.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEA)));
					commfunct_Obj.commonSetTextTextBox(txt_EA, sEA);
					lowlevellogsobj.info("Exemption Amount is entered as->" + sEA);
				}

				Thread.sleep(1000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpLockCreate)));
				commfunct_Obj.commonClick(btnLockCreate, "Yes");
				lowlevellogsobj.info("Clicked on Create button");
				commfunct_Obj.waitUntilDocumentIsReady(driver);
				Appcommfunct_Obj.checkSavemessage(driver, Constants.AddLockmsg);
			}
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}

}
