/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Covenants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class CovenantsCC_AddLock {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(CovenantsCC_AddLock.class);

	public CovenantsCC_AddLock(WebDriver driver) {
	}


	@FindBy(xpath = "//*[contains(text(),'Consequence Type')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbConsequencetype;

	@FindBy(xpath = "//*[contains(text(),'Consequence Type')]/following::div[position()=2]//input")
	private WebElement txt_Consequencetype;

	@FindBy(xpath = "//*[contains(text(),'Usage')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbUsage;

	@FindBy(xpath = "//*[contains(text(),'Obligatory Consequence')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbOC;

	@FindBy(xpath = "//*[contains(text(),'Lock Type')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbLockType;

	@FindBy(xpath = "//*[contains(text(),'Individual Lock')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbIL;

	@FindBy(xpath = "//*[contains(text(),'Collective Lock')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbCL;

	@FindBy(xpath = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Valid From')]/following::div[position()=2]//input")
	private WebElement txt_Validfrom;

	@FindBy(xpath = "//*[contains(text(),'Term')]/following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbTerm;

	@FindBy(xpath = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Inherit Condition Adjustment')]/following::div[position()=2]//input")
	private WebElement chkbox_ICA;

	@FindBy(xpath = "//div[contains(@id,'ContractualConsequencesObjectPage')]//*[text()='Create']")
	private WebElement btnCreate;

	@FindBy(xpath = "//footer[contains(@id,'idEditCovenant-footerWrapper')]//*[text()='Create']")
	private WebElement btnCovCreate;


	public String xpUsage = "//*[contains(text(),'Usage')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpCovenantstab = "//*[text()='Covenants']";
	public String xpConsequencetype = "//*[contains(text(),'Consequence Type')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpOC = "//*[contains(text(),'Obligatory Consequence')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpLockType = "//*[contains(text(),'Lock Type')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpCIL= "//*[contains(text(),'Individual Lock')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpCL = "//*[contains(text(),'Collective Lock')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpValidfrom= "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Valid From')]/following::div[position()=2]//input";
	public String xpICA = "//div[contains(@id,'idCovenantConsequenceDet')]//*[contains(text(),'Inherit Condition Adjustment')]/following::div[position()=2]//input";
	public String xpTerm = "//*[contains(text(),'Term')]/following::div[position()=2]//span[contains(@id,'arrow')]";
	
	public boolean tabCCAddlock(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sType= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_Type);
		String sUsage= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_Usage);
		String sOC= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_ObligatoryConsequence);
		String sLockType= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_LockType);
		String sIL= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_IndividualLock);
		String sCL= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_CollectiveLock);
		String svalidfrom= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_ValidFrom);
		String sTerm= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_Term);
		String sICAFLAG= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_ICA_FLAG);
		String sCCFlag=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSCCADDLOCK_CreateCovenant);


		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpConsequencetype)));
			commfunct_Obj.comboSelect(driver, sType, cmbConsequencetype);
			lowlevellogsobj.info("Type is selected as_>"+sType);
			Thread.sleep(2000);
			/*if(sType.length()>0){
				commfunct_Obj.commonSetTextTextBox(txt_Consequencetype, sType);
				txt_Consequencetype.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
				lowlevellogsobj.info("Type is selected as_>"+sType);
			}*/

			if(sUsage.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpUsage)));
				commfunct_Obj.comboSelect(driver, sUsage, cmbUsage);
				lowlevellogsobj.info("Usage is selected as_>"+sUsage);
				Thread.sleep(2000);
			}

			if(sOC.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOC)));
				commfunct_Obj.comboSelect(driver, sOC, cmbOC);
				lowlevellogsobj.info("OC is selected as_>"+sOC);
				Thread.sleep(2000);
			}


			if(sLockType.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpLockType)));
				commfunct_Obj.comboSelect(driver, sLockType, cmbLockType);
				lowlevellogsobj.info("Lock Type is selected as_>"+sLockType);
				Thread.sleep(2000);
			}

			if(sIL.length()>0){
				if (sLockType.equalsIgnoreCase("Individual Lock")){
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCIL)));
					commfunct_Obj.comboSelect(driver, sIL, cmbIL);
					lowlevellogsobj.info("Individual Lock Type is selected as ->"+sIL);
					Thread.sleep(2000);
				}
				else{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCL)));
					commfunct_Obj.comboSelect(driver, sCL, cmbCL);
					lowlevellogsobj.info("Collective Lock Type is selected as ->"+sCL);
					Thread.sleep(2000);
				}
			}

			if(svalidfrom.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
			commfunct_Obj.commonSetTextTextBox(txt_Validfrom, svalidfrom);
			lowlevellogsobj.info("Valid from is selected as ->"+svalidfrom);
			}

			if(sTerm.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTerm)));
			commfunct_Obj.comboSelect(driver, sTerm, cmbTerm);
			lowlevellogsobj.info("Term is selected as ->"+sTerm);
			}

			//wait.until(ExpectedConditions.visibilityOf(chkbox_ICA));
			if(sICAFLAG.equalsIgnoreCase("Yes")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpICA)));
				commfunct_Obj.commonClick(chkbox_ICA, "Yes");
				lowlevellogsobj.info("Inherit Condition Adjustment is Checked");
			}
			else{
				lowlevellogsobj.info("Inherit Condition Adjustment is NOT Checked/Flag is set to No in data sheet");
			}
			//Thread.sleep(3000);
			commfunct_Obj.waitUntilDocumentIsReady(driver);
			WebElement eleCreate = commfunct_Obj.commonFindElement_GetElement(driver, "xpath", "//div[contains(@id,'ContractualConsequencesObjectPage')]//*[text()='Create']");
			/*Actions act = new Actions(driver);
			act.moveToElement(eleCreate).build().perform();
			act.click().build().perform();*/
			commfunct_Obj.commonClick(btnCreate, "Yes");
			lowlevellogsobj.info("Contractual Consequences is added");
			//commfunct_Obj.commonClick(btnCreate, "Yes");
			Thread.sleep(1000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[contains(@aria-labelledby,'idContractualConsequences-header')]/tbody/tr[1]/td[2]/span[text()='"+sType+"']")));
			if(sCCFlag.equalsIgnoreCase("Yes")){
				commfunct_Obj.commonClick(btnCovCreate, "Yes");
				lowlevellogsobj.info("Create Covenant button is clicked");
				Thread.sleep(3000);
				//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCovenantstab)));
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}

}
