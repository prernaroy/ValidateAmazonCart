/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Covenants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class Covenants_Details {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Covenants_Details.class);

	public Covenants_Details(WebDriver driver) {
	}
	
	@FindBy(xpath = "//*[text()='Details']")
	private WebElement btn_Details;
	
	@FindBy(xpath = "//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'bank')]")
	private WebElement radioBank;
	
	@FindBy(xpath = "//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'borrower')]")
	private WebElement radioBorrower;
	
	@FindBy(xpath = "//*[contains(text(),'Description')]/../following::div[position()=1]//input")
	private WebElement txt_Description;
	
	@FindBy(xpath = "//*[text()='Covenant Check Procedure']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbCCP;
	
	@FindBy(xpath = "//*[text()='Soft Covenant Threshold']/../following::div[position()=1]//input")
	private WebElement txt_SCThreshold;
	
	@FindBy(xpath = "//*[text()='Hard Covenant Threshold']/../following::div[position()=1]//input")
	private WebElement txt_HCThreshold;
	
	@FindBy(xpath = "//*[text()='First Key Date']/../following::div[position()=1]//input")
	private WebElement txtFKdate;
	
	@FindBy(xpath = "//*[text()='Covenant Monitoring Procedure']/../following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbCMP;
	
	@FindBy(xpath = "//*[text()='Calculation Period']/../following::div[position()=1]//input")
	private WebElement txtCalculationperiod;
	
	@FindBy(xpath = "//*[text()='Calculation Period']/following::div[position()=7]//span[contains(@id,'arrow')]")
	private WebElement cmbCP;
	
	@FindBy(xpath = "//*[text()='Submission Deadline']/../following::div[position()=1]//input")
	private WebElement txtSubmissiondeadline;
	
	@FindBy(xpath = "//*[text()='Submission Deadline']/following::div[position()=7]//span[contains(@id,'arrow')]")
	private WebElement cmbSD;
	
	
	
	public String xpDetailstab="//*[text()='Details']";
	public String xpradioBank="//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'bank')]";
	public String xpradioBorrower="//*[contains(text(),'Covenant Result Supplier')]/../following::div[position()=1]//input[contains(@id,'borrower')]";
	public String xpValidfrom="//*[contains(text(),'Valid From')]/../following::div[position()=1]//input";
	public String xpValidTo="//*[contains(text(),'Valid To')]/../following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpDescription = "//*[contains(text(),'Description')]/../following::div[position()=1]//input";
	public String xpCCP = "//*[text()='Covenant Check Procedure']/../following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpSCThreshold = "//*[text()='Soft Covenant Threshold']/../following::div[position()=1]//input";
	public String xpHCThreshold= "//*[text()='Hard Covenant Threshold']/../following::div[position()=1]//input";
	public String xpFKdate= "//*[text()='First Key Date']/../following::div[position()=1]//input";
	public String xpCMP= "//*[text()='Covenant Monitoring Procedure']/../following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpCalculationperiod = "//*[text()='Calculation Period']/../following::div[position()=1]//input";
	public String xpCP= "//*[text()='Calculation Period']/following::div[position()=7]//span[contains(@id,'arrow')]";
	public String xpSubmissiondeadline = "//*[text()='Submission Deadline']/../following::div[position()=1]//input";
	public String xpSD= "//*[text()='Submission Deadline']/following::div[position()=7]//span[contains(@id,'arrow')]";
	

	public boolean tabCovenantsheader(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
					throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sResultSupplier = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_ResultSupplier);
		String sCheckProcedure = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_CheckProcedure);
		String sSoftThreshold = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_SoftThreshold);
		String sHardThreshold = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_HardThreshold);
		String sFirstKeyDate= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_FirstKeyDate);
		String sMonitoringProcedure= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_MonitoringProcedure);
		String sCalculationPeriod = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_CalculationPeriod);
		String sPeriodType1= commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_PeriodType1);
		String sSubmissionDeadline = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_SubmissionDeadline);
		String sPeriodType2 = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_COVENANTSDETAILS_PeriodType2);
		
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDetailstab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpDetailstab, "Yes");
			Thread.sleep(1000);
			if(sResultSupplier.equalsIgnoreCase("Bank")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioBank)));
				commfunct_Obj.commonClick(radioBank, "Yes");
				lowlevellogsobj.info("Bank is selected");
			}
			else{
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioBorrower)));
				commfunct_Obj.commonClick(radioBorrower, "Yes");
				lowlevellogsobj.info("Borrower is selected");
			}
			
			Thread.sleep(1000);
			
			if(sCheckProcedure.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCCP)));
			commfunct_Obj.comboSelect(driver,sCheckProcedure,cmbCCP);
			lowlevellogsobj.info("Covenant Check Procedure is selected as->"+sCheckProcedure);
			}
			
			if(sSoftThreshold.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSCThreshold)));
			commfunct_Obj.commonSetTextTextBox(txt_SCThreshold, sSoftThreshold);
			lowlevellogsobj.info("Soft Covenant Threshold is entered as->"+sSoftThreshold);
			}
			
			if(sHardThreshold.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpHCThreshold)));
			commfunct_Obj.commonSetTextTextBox(txt_HCThreshold, sHardThreshold);
			lowlevellogsobj.info("Hard Covenant Threshold is entered as->"+sHardThreshold);
			}
			
			if(sFirstKeyDate.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFKdate)));
			commfunct_Obj.commonSetTextTextBox(txtFKdate,sFirstKeyDate );
			lowlevellogsobj.info("First Key Date is entered as->"+sFirstKeyDate);
			}
			
			if(sMonitoringProcedure.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCMP)));
			commfunct_Obj.comboSelect(driver,sMonitoringProcedure,cmbCMP);
			lowlevellogsobj.info("Covenant Monitoring Procedure is selected as->"+sMonitoringProcedure);
			}
			
			if(sCalculationPeriod.length()>0){
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCalculationperiod)));
			commfunct_Obj.commonSetTextTextBox(txtCalculationperiod, sCalculationPeriod);
			lowlevellogsobj.info("Calculation Period is entered as->"+sCalculationPeriod);
			}
			
			if(sPeriodType1.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCP)));
			commfunct_Obj.comboSelect(driver,sPeriodType1,cmbCP);
			lowlevellogsobj.info("Calculation Period is selected as->"+sPeriodType1);
			}
			
			if(sSubmissionDeadline.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSubmissiondeadline)));
			commfunct_Obj.commonSetTextTextBox(txtSubmissiondeadline, sSubmissionDeadline);
			lowlevellogsobj.info("Submission Deadline is entered as->"+sSubmissionDeadline);
			}
			
			if(sPeriodType2.length()>0){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSD)));
			commfunct_Obj.comboSelect(driver,sPeriodType2,cmbSD);
			lowlevellogsobj.info("Submission Deadline is selected as->"+sPeriodType2);
			}
			
			result = true;
			
		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}
	
}
