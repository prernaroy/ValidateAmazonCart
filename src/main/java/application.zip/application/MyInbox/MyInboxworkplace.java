/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.MyInbox;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class MyInboxworkplace {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(MyInboxworkplace.class);

	public MyInboxworkplace(WebDriver driver) {
	}

	@FindBy(xpath = "//h1[text()='My Inbox']")
	private WebElement titlePage;

	@FindBy(xpath = "//input[@type='search']")
	private WebElement txtSearch;

	@FindBy(xpath = "//table[contains(@id,'taskListTable-listUl')]/tbody/tr[1]")
	private WebElement linkFirstrecord;

	@FindBy(xpath = "//*[contains(@id,'noDataMsg')]")
	private WebElement lblNoitems;

	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;

	public String xpMyinbox="//h1[text()='My Inbox']";
	public String xpSearch="//input[@type='search']";
	public String xpbtnOpentask="//*[text()='Open Task']";
	public String xpsearchrecord="//table[contains(@id,'taskListTable-listUl')]/tbody/tr[1]";
	public String xpbtnApprove="//*[text()='Approve']";
	public String xpApprovecompletion="//*[text()='No items available.']";
	public String xpchangelogClose="//*[text()='Close']";
	public String xpProceedbtn ="//*[text()='Proceed']";
	public String xpGobtn="//*[text()='Go']";

	public boolean appMyinboxworkplace(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 60);
		String sName = commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_MYINBOX_SearchName);
		String sType=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_MYINBOX_Type);
		String sAction=commfunct_Obj.getParameter(testArray_Data,headerMap_Data,Constants.C_MYINBOX_Action);

		try {
			lowlevellogsobj.info("Started in MyInbox Class");
			commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSearch)));
			commfunct_Obj.commonSetTextTextBox(txtSearch, sName);
			//commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpSearch, "Yes", sName);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpGobtn)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpGobtn, "Yes");
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpsearchrecord)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath",xpsearchrecord, "Yes");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnOpentask)));

			if(sType.equalsIgnoreCase("OpenTask")){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnOpentask)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnOpentask, "Yes");
				lowlevellogsobj.info("Open Task button is clicked");
				Thread.sleep(2000);
				if(driver.findElements(By.xpath(xpchangelogClose)).size()==1) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpchangelogClose)));
					commfunct_Obj.commonFindElement_Click(driver, "xpath", xpchangelogClose, "Yes");
					Thread.sleep(500);
				}
				else {
					lowlevellogsobj.info("Change log popup did not display");
				}

				if(sAction.equalsIgnoreCase("Approve")){
					//commfunct_Obj.getHandleToWindow(driver, Constants.PageFinance);
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnApprove)));
					commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnApprove, "Yes");
					lowlevellogsobj.info("Clicked on Approve button");

					//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpProceedbtn)));
					if(driver.findElements(By.xpath(xpProceedbtn)).size()==1){
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpProceedbtn)));
						commfunct_Obj.commonFindElement_Click(driver, "xpath", xpProceedbtn, "Yes");
					}

					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMyinbox)));
					Thread.sleep(4000);

				}
				
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
			if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
				Thread.sleep(1000);
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->"+geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
				result=false;
			}
			else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
				String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
				lowlevellogsobj.info(geterrorText);
				MsgList.add("Application Dump->"+geterrorText);
				commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
				result=false;
			}
			else {
				MsgList.add("Application Dump did not occur");
			}

		}    

		return result;
	}

}
