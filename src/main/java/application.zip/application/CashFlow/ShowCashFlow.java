/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CashFlow;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class ShowCashFlow {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(ShowCashFlow.class);

	public ShowCashFlow(WebDriver driver) {
	}

	@FindBy(xpath = "//*[contains(@id,'idDealDisplayHeader-overflow-inner')]")
	private WebElement btnMore;
	
	@FindBy(xpath = "//div[contains(@id,'popover')]//*[text()='Show Cash Flow']")
	private WebElement btnShowcashflow;
	
	@FindBy(xpath = "//*[contains(@id,'aggregation-arrow')]")
	private WebElement cmbAggregation;

	@FindBy(xpath = "//*[text()='Go']")
	private WebElement btnGo;
	
	@FindBy(xpath = "//*[contains(@id,'btnFullScreen-img')]")
	private WebElement btnFullscreen;
	
	@FindBy(xpath = "//a[@id='backBtn']")
	private WebElement btnBack;
	
	public String xpMore = "//*[contains(@id,'idDealDisplayHeader-overflow-inner')]";
	public String xpSCF = "//div[contains(@id,'popover')]//*[text()='Show Cash Flow']";
	public String xptitle = "//h1[text()='Cash Flow Financing']";
	public String xpAggregation = "//*[contains(@id,'aggregation-arrow')]";
	public String xpGobtn="//*[text()='Go']";
	public String xpFullscreen="//*[contains(@id,'btnFullScreen-img')]";
	public String xpFintitle="//h1[text()='Financing]";
	public String xpbtnBack="//a[@id='backBtn']";
	
	

	public boolean tabCashflow(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		
		String sPagetitle=commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_SCF_PAGETITLE);
		String sAggregation = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_SCF_TYPE);
		String sRecord = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SCF_RECORD);
		

		try {
			lowlevellogsobj.info("Started in Show Cash Flow Class");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMore)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpMore, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSCF)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpSCF, "Yes");
			lowlevellogsobj.info("Clicked on Show Cash Flow Button");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptitle)));
			
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSCF)));
			commfunct_Obj.comboSelect(driver, sAggregation, cmbAggregation);
			lowlevellogsobj.info("Aggregation is selected as->"+sAggregation);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpGobtn)));
			commfunct_Obj.commonClick(btnGo, "Yes");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFullscreen)));
			commfunct_Obj.commonClick(btnFullscreen, "Yes");
			Thread.sleep(2000);
			commfunct_Obj.commonClick(btnFullscreen, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnBack)));
			commfunct_Obj.commonClick(btnBack, "Yes");
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFintitle)));

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}

}
