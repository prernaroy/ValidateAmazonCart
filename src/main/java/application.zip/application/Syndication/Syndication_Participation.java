/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Syndication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class Syndication_Participation {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Syndication_Participation.class);

	public Syndication_Participation(WebDriver driver) {
	}

	@FindBy(xpath = "//span[text()='Financing']/../following::div[position()=1]//input")
	private WebElement txtFinanceRatio;

	@FindBy(xpath = "//span[text()='Tranche']/../following::div[position()=1]//input")
	private WebElement txtTrancheRatio;

	@FindBy(xpath = "//span[text()='Drawdown']/../following::div[position()=1]//input")
	private WebElement txtDrawdownRatio;

	@FindBy(xpath = "//span[text()='Financing']/../following::div[position()=7]//input")
	private WebElement txtFinanceAmnt;

	@FindBy(xpath = "//span[text()='Tranche']/../following::div[position()=7]//input")
	private WebElement txtTrancheAmnt;

	@FindBy(xpath = "//span[text()='Drawdown']/../following::div[position()=7]//input")
	private WebElement txtDrawdownAmnt;

	@FindBy(xpath = "//span[text()='Financing']/../following::div[position()=16]//span[contains(@id,'arrow')]")
	private WebElement cmbFinancePptform;

	@FindBy(xpath = "//span[text()='Tranche']/../following::div[position()=16]//input")
	private WebElement txtTranchePptform;

	@FindBy(xpath = "//span[text()='Drawdown']/../following::div[position()=16]//input")
	private WebElement txtDrawdownPptform;

	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btnCreate;

	@FindBy(xpath = "//*[text()='Participation']")
	private WebElement lblParticipation;

	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;
	public String xpFinRatio = "//span[text()='Financing']/../following::div[position()=1]//input";
	public String xpFinAmnt = "//span[text()='Financing']/../following::div[position()=7]//input";
	public String xpFinPptform = "//span[text()='Financing']/../following::div[position()=16]//span[contains(@id,'arrow')]";
	public String xpTraRatio = "//span[text()='Tranche']/../following::div[position()=1]//input";
	public String xpTraAmnt = "//span[text()='Tranche']/../following::div[position()=7]//input";
	public String xpTraPptform = "//span[text()='Tranche']/../following::div[position()=16]//input";
	public String xpDraRatio = "//span[text()='Drawdown']/../following::div[position()=1]//input";
	public String xpDraAmnt = "//span[text()='Drawdown']/../following::div[position()=7]//input";
	public String xpDraPptform = "//span[text()='Drawdown']/../following::div[position()=16]//input";
	public String xpbtnCreate = "//*[text()='Create']";
	public String xpParticipation = "//*[text()='Participation']";
	public String xpSyndTable = "//table[contains(@aria-labelledby,'SyndicationView')]/tbody/tr";

	public boolean tabSyndicationparticipation(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sFinRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_FinRatio);
		String sFinAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_FinAmount);
		String sFinPptform = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_FinPptForm);
		String sTraRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_TraRatio);
		String sTraAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_TraAmount);
		String sTraPptform = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_TraPptForm);
		String sDraRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_DraRatio);
		String sDraAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_DraAmount);
		String sDraPptform = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_DraPptForm);
		String sAddRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONPARTICIPATION_AddRatio);

		try {
			String strSplitFinRatio[] = sFinRatio.split("\\|");
			
			int totalcnt = driver.findElements(By.xpath(xpSyndTable)).size();
			System.out.println(totalcnt);
			for (int i = 1; i <= totalcnt; i++) {
			if (sAddRatio.equalsIgnoreCase("Yes")) {

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSyndTable)));
			commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
			Thread.sleep(1000);
			WebElement table_Syndrow = driver.findElement(By
					.xpath("//table[contains(@aria-labelledby,'SyndicationView')]/tbody/tr[" + i + "]/td[3]"));
			commfunct_Obj.commonClick(table_Syndrow, "Yes");
			lowlevellogsobj.info("Deal Syndication row is clicked");
			Thread.sleep(2000);


			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpParticipation)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpParticipation, "Yes");
			Thread.sleep(2000);

			if (sFinRatio.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFinRatio)));
				commfunct_Obj.commonSetTextTextBox(txtFinanceRatio, strSplitFinRatio[i - 1]);
				// commfunct_Obj.waitUntilDocumentIsReady(driver);
				lowlevellogsobj.info("Finance Participation Ratio is entered as ->" + strSplitFinRatio[i - 1]);
				Thread.sleep(1000);
			}
				
				if (sFinPptform.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFinPptform)));
					commfunct_Obj.comboSelect(driver, sFinPptform, cmbFinancePptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Finance Participation Form is selected as ->" + sFinPptform);
					Thread.sleep(2000);
				}
				

			} 
			else {
			
				if (sFinAmount.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFinAmnt)));
					commfunct_Obj.commonSetTextTextBox(txtFinanceAmnt, sFinAmount);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Finance Participation Amount is entered as ->" + sFinAmount);
				}
				
				
			
				if (sFinPptform.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFinPptform)));
					commfunct_Obj.comboSelect(driver, sFinPptform, cmbFinancePptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Finance Participation Form is selected as ->" + sFinPptform);
					Thread.sleep(2000);
				}
				
			}

			Thread.sleep(1000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnCreate)));
			commfunct_Obj.commonClick(btnCreate, "Yes");
			lowlevellogsobj.info("Clicked on Create button");

			/*Thread.sleep(1000);

			wait.until(ExpectedConditions.visibilityOf(btnSave));
			commfunct_Obj.commonClick(btnSave, "Yes");
			lowlevellogsobj.info("Clicked on Save button");*/

			
			result = true;
		}

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}

}
