/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateTranche;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class TraConditions {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(TraConditions.class);

	public TraConditions(WebDriver driver) {
	}

	@FindBy(xpath = "//*[contains(@id,'buttonAddCond-img')]")
	private WebElement btn_Addcondition;

	@FindBy(xpath = "//button[contains(@id,'TrancheConditions-anchor')]")
	private WebElement btn_Trancheconditions;

	public String xptrancheAddcondition = "//button[contains(@id,'buttonAddCond')]";
	public String xptrancheConditionstab = "//button[contains(@id,'TrancheConditions-anchor')]";
	public String xptrancheConditionstype = "//*[contains(@id,'idConditionType-arrow')]";

	public boolean tabtraConditions(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver,60);
		String sAddtrancheconditions = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRANCHECONDITIONS_Add);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptrancheConditionstab)));
			Thread.sleep(1000);
			commfunct_Obj.commonClick(btn_Trancheconditions, "Yes");
			// commfunct_Obj.commonFindElement_Click(driver, "xpath",
			// xptrancheConditionstab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptrancheAddcondition)));
			lowlevellogsobj.info("Started in Tranche Conditions Class");
			if (sAddtrancheconditions.equalsIgnoreCase("Yes")) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xptrancheAddcondition, "Yes");
				lowlevellogsobj.info("Add Condition button is clicked");
				Thread.sleep(2000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptrancheConditionstype)));
			}
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}

}
