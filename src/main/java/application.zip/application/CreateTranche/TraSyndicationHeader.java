/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateTranche;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;
import utils.Common_Functions;
import utils.Application_Common_Functions;

/**
 * @author C5268933
 *
 */
public class TraSyndicationHeader {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(TraSyndicationHeader.class);

	public TraSyndicationHeader(WebDriver driver) {
	}

	@FindBy(xpath = "//*[text()='Header']")
	private WebElement lblHeader;

	@FindBy(xpath = "//*[contains(@id,'buttonAddSynd-img')]")
	private WebElement btn_Addsyndication;

	@FindBy(xpath = "//label[contains(text(),'Business Partner')]/../following::div[position()=1]//input")
	private WebElement txt_Busspartner;

	@FindBy(xpath = "//*[@role='link']//span")
	private WebElement lblBP;

	@FindBy(xpath = "//*[contains(text(),'Participation Via')]/../following::div[position()=1]//span")
	private WebElement cmbParticipationvia;

	@FindBy(xpath = "//*[contains(text(),'Participation Type')]/../following::div[position()=1]//span")
	private WebElement cmbParticipationtype;

	@FindBy(xpath = "//*[contains(text(),'Valid From')]/../following::div[position()=1]//input")
	private WebElement cmbValidfrom;

	@FindBy(xpath = "//*[contains(text(),'Valid To')]/../following::div[position()=1]//input")
	private WebElement cmbValidto;

	@FindBy(xpath = "//label[contains(text(),'Bank Details ID')]/../following::div[position()=1]//input")
	private WebElement txt_Bankdtls;

	@FindBy(xpath = "//span[contains(@id,'PaymentMethod')]")
	private WebElement cmbPaymentMethod;

	public String xpHeader = "//*[text()='Header']";
	public String xpAddsyndication = "//*[contains(@id,'buttonAddSynd-img')]";
	public String xpSyndBP = "//label[contains(text(),'Business Partner')]/../following::div[position()=1]//span[contains(@id, 'vhi')]";
	public String xpPptvia = "//*[contains(text(),'Participation Via')]/../following::div[position()=1]//span";
	public String xpPpttype = "//*[contains(text(),'Participation Type')]/../following::div[position()=1]//span";
	public String xpValidfrom = "//*[contains(text(),'Valid From')]/../following::div[position()=1]//input";
	public String xpValidto = "//*[contains(text(),'Valid To')]/../following::div[position()=1]//input";
	public String xpPayment = "//span[contains(@id,'PaymentMethod')]";
	public String xpBusspartner = "//label[contains(text(),'Business Partner')]/../following::div[position()=1]//input";
	public String xpBusspartnerName = "//*[@role='link']//span";
	public String xpBankdtls = "//label[contains(text(),'Bank Details ID')]/../following::div[position()=1]//input";
	
	public boolean tabtraSyndicationheader(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sAddsyndication = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_Add);
		String sBussPartner = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_BussPartner);
		String sBussPartnerName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_BussPartnerName);
		String sParticipationVia = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_ParticipationVia);
		String sValidFrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_ValidFrom);
		String sValidTo = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_ValidTo);
		String sBankdtls = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_BankDetails);
		String sInPaymentMethod = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_InPaymentMethod);
		String sParticipationType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_SYNDICATIONHEADER_ParticipationType);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddsyndication)));
			Thread.sleep(1000);
			if (sAddsyndication.equalsIgnoreCase("Yes")) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpAddsyndication, "Yes");
				lowlevellogsobj.info("Add Syndication button is clicked");
				Thread.sleep(2000);
				// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpSyndBP)));
			}
		
			if (sBussPartner.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBusspartner)));
				Thread.sleep(1000);
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpBusspartner, "Yes", sBussPartner);
				txt_Busspartner.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
				lowlevellogsobj.info("Business Partner is entered as->" + sBussPartner);
			}
			// Appcommfunct_Obj.clickGridele(driver, sConditionType, xptableCondition,
			// cmbPeriodicprofile, sPP, btnApply);
			Thread.sleep(2000);
		
			if (sBussPartnerName.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBusspartnerName)));
				commfunct_Obj.expectedValue(lblBP, "text", sBussPartnerName, "Yes");
				lowlevellogsobj.info("Validated Succesfully that Business Partner name is:" + sBussPartnerName);
			}

			if (sValidFrom.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpValidfrom, "Yes", sValidFrom);
				lowlevellogsobj.info("Syndication Valid From is entered as->" + sValidFrom);
			}

			if (sValidTo.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidto)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpValidto, "Yes", sValidTo);
				lowlevellogsobj.info("Syndication Valid To is entered as->" + sValidTo);
			}

			if (sBankdtls.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBankdtls)));
				commfunct_Obj.commonSetTextTextBox(txt_Bankdtls, sBankdtls);
				txt_Bankdtls.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				lowlevellogsobj.info("Bank details is entered as ->" + sBankdtls);
			}

			
			if (sInPaymentMethod.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPayment)));
				commfunct_Obj.comboSelect(driver, sInPaymentMethod, cmbPaymentMethod);
				lowlevellogsobj.info("Payment method is selected as ->" + sInPaymentMethod);
			}

			if (sParticipationType.length() > 0) {

				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPpttype)));
				commfunct_Obj.comboSelect(driver, sParticipationType, cmbParticipationtype);
				lowlevellogsobj.info("Participation Type is selected as ->" + sParticipationType);
			}

		
			if (sParticipationVia.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPptvia)));
				commfunct_Obj.comboSelect(driver, sParticipationVia, cmbParticipationvia);
				lowlevellogsobj.info("Participation Via is selected as->" + sParticipationVia);
			}
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}

}
