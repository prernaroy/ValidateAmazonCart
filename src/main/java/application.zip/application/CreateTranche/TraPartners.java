/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateTranche;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class TraPartners {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions acf_Obj = new Application_Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(TraPartners.class);

	public TraPartners(WebDriver driver) {
	}

	@FindBy(xpath = "//span[text()='Business Partners']")
	private WebElement title_partner;
	
	@FindBy(xpath = "//table[contains(@aria-labelledby,'tableForBusinessPartners')]/tbody/tr[1]/td[2]/div[contains(@id,'selectMulti')]/div")
	private WebElement radiobtnBProle;
	
	@FindBy(xpath = "//table[contains(@aria-labelledby,'tableForBusinessPartners')]/tbody/tr[2]/td[2]/div[contains(@id,'selectMulti')]/div")
	private WebElement radiobtnBProle_synd;

	@FindBy(xpath = "//div[contains(@id,'trancheEdit--PartnersView--tableForBusinessPartners--table-header')]/following::button[position()=1]")
	private WebElement btnEdit;

	@FindBy(xpath = "//*[text()='Payment Method']/../following::div[position()=1]//span")
	private WebElement cmbPaymentmethod;

	@FindBy(xpath = "//label[text()='Bank Details ID']/following::input[position()=1]")
	private WebElement txt_Bankdtls;

	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btnApply;

	@FindBy(xpath = "//*[text()='Responsible Agents']/following::button[position()=3]/span")
	private WebElement btn_AddRA;

	@FindBy(xpath = "//*[contains(@id,'RespCat-comboBoxEdit-arrow')]")
	private WebElement cmbAgentrole;

	@FindBy(xpath = "//input[contains(@id,'ResponsibleAgentsTable--BpId-input')]")
	private WebElement txt_ResAgent;

	@FindBy(xpath = "//input[contains(@id,'ResponsibleAgentsTable--OrgUnit-input')]")
	private WebElement txt_OrgUnit;

	@FindBy(xpath = "//input[contains(@id,'ResponsibleAgentsTable--idValidFrom-datePicker')]")
	private WebElement txt_ValidFrom;

	@FindBy(xpath = "//*[contains(@id,'utilType-comboBoxEdit-arrow')]")
	private WebElement cmbUtilType;

	@FindBy(xpath = "//footer/child::button[position()=1]//*[text()='Create']")
	private WebElement btnCreate;

	@FindBy(xpath = "//span[contains(@id,'dealEdit--idSaveDeal-inner')]")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Check Consistency']")
	private WebElement linkCheckconistency;

	@FindBy(xpath = "//*[text()='Close']")
	private WebElement btnCCclose;

	@FindBy(xpath = "//span[text()='Release Status:']/following::span[position()=1]")
	private WebElement labelFinancestatus;

	public String xpradioBProle = "//table[contains(@aria-labelledby,'tableForBusinessPartners')]/tbody/tr[1]/td[2]/div[contains(@id,'selectMulti')]/div";
	public String xpradioBProle_synd = "//table[contains(@aria-labelledby,'tableForBusinessPartners')]/tbody/tr[2]/td[2]/div[contains(@id,'selectMulti')]/div";
	public String xpPaymentmethod = "//*[text()='Payment Method']/../following::div[position()=1]//span";
	public String xpptTitle = "//span[text()='Business Partners']";
	public String xpPartnerstab = "//button[contains(@id,'TranchePartners-anchor')]";
	public String xpBankdtls = "//label[text()='Bank Details ID']/following::input[position()=1]";
	public String xpMDRef = "//label[text()='Mandate Reference']/following::input[position()=1]";
	public String xpMsglist = "//table[contains(@aria-labelledby,'idConsistencyTable-header')]/tbody/tr/td[6]/span";
	public String xpReleasestatus = "//span[text()='Release Status:']/following::span[position()=1]";
	public String xpApplybtn="//*[text()='Apply']";
	public String xpOrgUnit = "//input[contains(@id,'ResponsibleAgentsTable--OrgUnit-input')]";
	public String xpValidFrom = "//input[contains(@id,'ResponsibleAgentsTable--idValidFrom-datePicker')]";
	public String xpUtilType = "//*[contains(@id,'utilType-comboBoxEdit-arrow')]";
	public String xpCreate = "//footer/child::button[position()=1]//*[text()='Create']";
	public String xpAddRA = "//*[text()='Responsible Agents']/following::button[position()=3]/span";
	public String xpCheckconistency = "//*[text()='Check Consistency']";
	public String xpcmbAgentrole = "//*[contains(@id,'RespCat-comboBoxEdit-arrow')]";
	public String xptxt_ResAgent = "//input[contains(@id,'ResponsibleAgentsTable--BpId-input')]";
	public String xpbtnEdit = "//div[contains(@id,'trancheEdit--PartnersView--tableForBusinessPartners--table-header')]/following::button[position()=1]";
	public String xpbtnSave= "//span[contains(@id,'dealEdit--idSaveDeal-inner')]";

	public boolean tabtraPartners(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sTitle = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRAPARTNERS_Title);
		String sEdit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRAPARTNERS_Edit);
		String sPaymentmethod = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_PaymentMethod);
		String sBankdtls = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_BankDetailsID);
		String sMDRef = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRAPARTNERS_MandateRef);
		String sAddResAgents = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_AddResponsibleAgent);
		String sAgentRole = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_AgentRole);
		String sResponsibleAgent = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_ResponsibleAgent);
		String sOrgUnit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRAPARTNERS_OrgUnit);
		String sValidFrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_ValidFrom);
		String sUtilizationType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_UtilizationType);
		String sSave = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRAPARTNERS_ClickSave);
		String sCheckConsistency = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_CheckConsistency);
		String sCCErrormsg = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_CheckConsistErrorMsg);
		String sSynd = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_TRAPARTNERS_Syndication);
		
		String sFinancestatus = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRAPARTNERS_ReleaseStatus);

		try {
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpPartnerstab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpptTitle)));
			lowlevellogsobj.info("Started in Partners Class");

			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			commfunct_Obj.expectedValue(title_partner, "text", sTitle, "Yes");
			lowlevellogsobj.info("Landed successfully on " + sTitle + " Screen");
			Thread.sleep(3000);

			// Check Consistency
			if (sCheckConsistency.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCheckconistency)));
				commfunct_Obj.commonClick(linkCheckconistency, "Yes");
				lowlevellogsobj.info("Clicked on Check conistency link");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMsglist)));
				acf_Obj.messageVerificationPartner(driver, sCCErrormsg);
				lowlevellogsobj.info("Check conistency Error Messgae is verfied successfully");
				commfunct_Obj.commonClick(btnCCclose, "Yes");

			} else {
				lowlevellogsobj.info("Check conistency flag is set to No");
			}

			if (sEdit.equalsIgnoreCase("Yes")) {
				if(sSynd.equalsIgnoreCase("No")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioBProle)));
					commfunct_Obj.commonClick(radiobtnBProle, "Yes");
					if (btnEdit.isEnabled() == true) {
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnEdit)));
					commfunct_Obj.commonClick(btnEdit, "Yes");
					lowlevellogsobj.info("Edit button is clicked");
				} else {
					lowlevellogsobj.info("Edit button is not enabled");
				}
				}
				else{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpradioBProle_synd)));
					commfunct_Obj.commonClick(radiobtnBProle_synd, "Yes");
					if (btnEdit.isEnabled() == true) {
						wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnEdit)));
						commfunct_Obj.commonClick(btnEdit, "Yes");
					lowlevellogsobj.info("Edit button is clicked");
				} else {
					lowlevellogsobj.info("Edit button is not enabled");
				}	
				}

				if (sPaymentmethod.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentmethod)));
					commfunct_Obj.comboSelect(driver, sPaymentmethod, cmbPaymentmethod);
					lowlevellogsobj.info("Payment method is selected as ->" + sPaymentmethod);
				}
				Thread.sleep(2000);
				if (sBankdtls.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBankdtls)));
					commfunct_Obj.commonSetTextTextBox(txt_Bankdtls, sBankdtls);
					txt_Bankdtls.sendKeys(Keys.ENTER);
					Thread.sleep(2000);
					lowlevellogsobj.info("Bank details is entered as ->" + sBankdtls);
				}
				if (driver.findElements(By.xpath(xpMDRef)).size() == 1) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpMDRef)));
					if (sMDRef.length() > 0) {
						commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpMDRef, "Yes", sMDRef);
						lowlevellogsobj.info("Mandate Reference is entered as ->" + sMDRef);
					}
				}
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpApplybtn)));
				commfunct_Obj.commonClick(btnApply, "Yes");
				lowlevellogsobj.info("Apply button is clicked");
				acf_Obj.checkSavemessage(driver, Constants.bankdtlsUpdatemsg);
			}

		

			// Add Responsible Agent
			if (sAddResAgents.equalsIgnoreCase("Yes")) {
				lowlevellogsobj.info("Add Responsible Agent is set to Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddRA)));
				commfunct_Obj.commonClick(btn_AddRA, "Yes");
				lowlevellogsobj.info("Add Responsible Agent button is clicked");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpcmbAgentrole)));
				commfunct_Obj.comboSelect(driver, sAgentRole, cmbAgentrole);
				Thread.sleep(2000);
				lowlevellogsobj.info("Agent role is entered as ->" + sAgentRole);
				// Responsible Agent
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xptxt_ResAgent)));
				commfunct_Obj.commonSetTextTextBox(txt_ResAgent, sResponsibleAgent);
				txt_ResAgent.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				lowlevellogsobj.info("Responsible Agent is entered as ->" + sResponsibleAgent);
				// Organization Unit
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOrgUnit)));
				commfunct_Obj.commonSetTextTextBox(txt_OrgUnit, sOrgUnit);
				txt_OrgUnit.sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				lowlevellogsobj.info("Organization Unit is entered as ->" + sOrgUnit);
				// Valid From
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidFrom)));
				commfunct_Obj.commonSetTextTextBox(txt_ValidFrom, sValidFrom);
				lowlevellogsobj.info("Valid From is entered as ->" + sValidFrom);
				// Utilization Type
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpUtilType)));
				commfunct_Obj.comboSelect(driver, sUtilizationType, cmbUtilType);
				lowlevellogsobj.info("Utilization Type is selected as ->" + sUtilizationType);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCreate)));
				commfunct_Obj.commonClick(btnCreate, "Yes");
				lowlevellogsobj.info("Clicked on Create Button");
				acf_Obj.checkSavemessage(driver, Constants.AddresponsibleAgentmsg);

			} else {
				lowlevellogsobj.info("Add Responsible Agent is set to NO");
			}

			// Save Create Finance

			if (sSave.equalsIgnoreCase("Yes")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnSave)));
				commfunct_Obj.commonClick(btnSave, "Yes");
				lowlevellogsobj.info("Footer Save button is clicked");
				acf_Obj.checkSavemessage(driver, Constants.saveFinancemsg);
				Thread.sleep(3000);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpReleasestatus)));
				commfunct_Obj.expectedValue(labelFinancestatus, "text", sFinancestatus, "Yes");
				lowlevellogsobj.info("Release status is ->" + sFinancestatus);
			} else {
				lowlevellogsobj.info("Either Save button flag is off or Save operation failure");
			}

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
             	 MsgList.add("Application Dump did not occur");
             }
       }    

		return result;
	}

}
