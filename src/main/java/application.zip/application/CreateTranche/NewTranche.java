/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateTranche;

import java.awt.KeyEventPostProcessor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Application_Common_Functions;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class NewTranche {

	private Common_Functions commfunct_Obj = new Common_Functions();
	private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(NewTranche.class);

	public NewTranche(WebDriver driver) {
	}

	@FindBy(xpath = "//div[contains(@class,'sapUxAPHierarchicalSelect')]")
	private WebElement btnMore;

	@FindBy(xpath = "//section[contains(@id, 'dealEdit--DealOverview')]//*[text()='Create Tranche']")
	private WebElement btnCreateTranche;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='Name']/following::div[position()=1]//input")
	private WebElement txt_Name;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='Main Borrower']/following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbBorrower;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='Tranche Product']/following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbproduct;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='Total Tranche Amount']/following::div[position()=1]//input[not(contains(@aria-describedby,'SuggDescr'))]")
	private WebElement txt_Amount;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='Total Tranche Amount']/following::div[position()=1]//input[contains(@aria-describedby,'SuggDescr')]")
	private WebElement txtCurrency;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='Start of Term']/following::div[position()=1]//input")
	private WebElement txt_StartTerm;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='End of Term']/following::div[position()=1]//span[contains(@id,'arrow')]")
	private WebElement cmbEndTerm;

	@FindBy(xpath = "//section[contains(@id,'trancheCreate')]//*[text()='End of Term']/following::div[position()=5]//input")
	private WebElement txt_EndofTerm;

	@FindBy(xpath = "//*[text()='Create and Edit']")
	private WebElement buttonCreateEdit;
	
	@FindBy(xpath = "//div[@id='fiori2LoadingDialogBusyIndicator-busyIndicator']")
	private WebElement screenloader;

	public String xpbtnMore = "//div[contains(@class,'sapUxAPHierarchicalSelect')]";
	public String xpOverview = "//li[text()='Overview']";
	public String xpOverviewtab = "//button[contains(@id, 'DealOverview')]";
	public String xpCT = "//section[contains(@id, 'dealEdit--DealOverview')]//*[text()='Create Tranche']";
	public String xpCreateEdit = "//*[text()='Create and Edit']";
	public String xpName = "//section[contains(@id,'trancheCreate')]//*[text()='Name']/following::div[position()=1]//input";
	public String xpBorrower= "//section[contains(@id,'trancheCreate')]//*[text()='Main Borrower']/following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpproduct = "//section[contains(@id,'trancheCreate')]//*[text()='Tranche Product']/following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpAmount= "//section[contains(@id,'trancheCreate')]//*[text()='Total Tranche Amount']/following::div[position()=1]//input[not(contains(@aria-describedby,'SuggDescr'))]";
	public String xpCurrency = "//section[contains(@id,'trancheCreate')]//*[text()='Total Tranche Amount']/following::div[position()=1]//input[contains(@aria-describedby,'SuggDescr')]";
	public String xpStartTerm = "//section[contains(@id,'trancheCreate')]//*[text()='Start of Term']/following::div[position()=1]//input";
	public String xpEndTerm = "//section[contains(@id,'trancheCreate')]//*[text()='End of Term']/following::div[position()=1]//span[contains(@id,'arrow')]";
	public String xpEndofTerm= "//section[contains(@id,'trancheCreate')]//*[text()='End of Term']/following::div[position()=5]//input";
	
	public boolean tabNewtranche(WebDriver driver, List<String> testArray_Data, HashMap<String, Integer> headerMap_Data)
			throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		String sTranchName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_TranchName);
		String sMainBorrower = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_MainBorrower);
		String sTrancheProduct = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_TrancheProduct);
		String sTrancheAmt = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_TrancheAmt);
		String sTrancheCurr = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_TrancheCurr);
		String sStartofterm = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_StartofTerm);
		String sEndofTerm = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_EndofTerm);
		String sEndDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_CREATETRANCHE_EndDate);
		String sClickCreateEdit = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CREATETRANCHE_ClickCreateEdit);

		try {
			if(driver.findElement(By.xpath(xpbtnMore)).isDisplayed()){
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnMore)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpbtnMore, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOverview)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpOverview, "Yes");
				lowlevellogsobj.info("Clicked on Overview button");
				Thread.sleep(1000);
			}
			else {
				lowlevellogsobj.info("Started in Overview Class");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpOverviewtab)));
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpOverviewtab, "Yes");
				lowlevellogsobj.info("Clicked on Overview button");
				Thread.sleep(1000);
		}
			commfunct_Obj.commonWaitToNotDisplayElement(driver, 15, screenloader);
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCT)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCT, "Yes");
			lowlevellogsobj.info("Clicked on Create Tranche button");
			
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
			lowlevellogsobj.info("Inside Create Tranche class");

			if (sTranchName.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpName)));
				commfunct_Obj.commonSetTextTextBox(txt_Name, sTranchName);
				lowlevellogsobj.info("Tranche Name is entered as->" + sTranchName);
			}

			if (sMainBorrower.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBorrower)));
				commfunct_Obj.comboSelect(driver, sMainBorrower, cmbBorrower);
				lowlevellogsobj.info("Borrower Name is selected as->" + sMainBorrower);
			}

			if (sTrancheProduct.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpproduct)));
				commfunct_Obj.comboSelect(driver, sTrancheProduct, cmbproduct);
				lowlevellogsobj.info("Tranche Product is selected as->" + sTrancheProduct);
			}

			if (sTrancheAmt.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAmount)));
				commfunct_Obj.commonSetTextTextBox(txt_Amount, sTrancheAmt);
				lowlevellogsobj.info("Tranche Amount is entered as->" + sTrancheAmt);
			}

			if (sTrancheCurr.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCurrency)));
				commfunct_Obj.commonSetTextTextBox(txtCurrency, sTrancheCurr);
				lowlevellogsobj.info("Tranche Currency is entered as->" + sTrancheCurr);
				txtCurrency.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
			}

			if (sStartofterm.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpStartTerm)));
				commfunct_Obj.commonSetTextTextBox(txt_StartTerm, sStartofterm);
				lowlevellogsobj.info("Tranche Start of Term is entered as->" + sStartofterm);
			}

			
			if (sEndofTerm.equalsIgnoreCase("Term Ends On")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEndTerm)));
				commfunct_Obj.comboSelect(driver, sEndofTerm, cmbEndTerm);
				lowlevellogsobj.info("Tranche End of Term is selected as->" + sEndofTerm);

				
				if (sEndDate.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEndofTerm)));
					commfunct_Obj.commonSetTextTextBox(txt_EndofTerm, sEndDate);
					lowlevellogsobj.info("Tranche End Date is entered as->" + sEndDate);
				}
			}

			else {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpEndTerm)));
				commfunct_Obj.comboSelect(driver, sEndofTerm, cmbEndTerm);
				lowlevellogsobj.info("Tranche End of Term is selected as->" + sEndofTerm);
			}

			Thread.sleep(2000);

			if (sClickCreateEdit.equalsIgnoreCase("Yes")) {
				commfunct_Obj.commonFindElement_Click(driver, "xpath", xpCreateEdit, "Yes");
				lowlevellogsobj.info("Clicked on Tranche Create and Edit button");
				
				Appcommfunct_Obj.checkSavemessage(driver, Constants.newtranceMsg);
				Thread.sleep(1000);
			} else {

			}

			result = true;

		}
		catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    


		return result;
	}

}
