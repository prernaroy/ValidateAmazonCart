/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.CreateTranche;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class EditTraParticipation {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(EditTraParticipation.class);

	public EditTraParticipation(WebDriver driver) {
	}

	@FindBy(xpath = "//span[text()='Financing']/../following::div[position()=1]//input")
	private WebElement txtFinanceRatio;

	@FindBy(xpath = "//span[text()='Tranche']/../following::div[position()=1]//input")
	private WebElement txtTrancheRatio;

	@FindBy(xpath = "//span[text()='Drawdown']/../following::div[position()=1]//input")
	private WebElement txtDrawdownRatio;

	@FindBy(xpath = "//span[text()='Financing']/../following::div[position()=7]//input")
	private WebElement txtFinanceAmnt;

	@FindBy(xpath = "//span[text()='Tranche']/../following::div[position()=7]//input")
	private WebElement txtTrancheAmnt;

	@FindBy(xpath = "//span[text()='Drawdown']/../following::div[position()=7]//input")
	private WebElement txtDrawdownAmnt;

	@FindBy(xpath = "//span[text()='Financing']/../following::div[position()=16]//input")
	private WebElement txtFinancePptform;

	@FindBy(xpath = "//span[text()='Tranche']/../following::div[position()=16]//span[contains(@id,'comboBoxEdit-arrow')]")
	private WebElement cmbTranchePptform;

	@FindBy(xpath = "//span[text()='Drawdown']/../following::div[position()=16]//input")
	private WebElement txtDrawdownPptform;

	@FindBy(xpath = "//*[text()='Save']")
	private WebElement btnSave;

	@FindBy(xpath = "//*[text()='Apply']")
	private WebElement btnApply;

	@FindBy(xpath = "//*[text()='Participation']")
	private WebElement lblParticipation;

	@FindBy(xpath = "//h1//span[text()='AutoTranche']")
	private WebElement lblTranche;

	public String xpFinRatio = "//span[text()='Financing']/../following::div[position()=1]//input";
	public String xpFinAmnt = "//span[text()='Financing']/../following::div[position()=7]//input";
	public String xpFinPptform = "//span[text()='Financing']/../following::div[position()=16]//input";
	public String xpTraRatio = "//span[text()='Tranche']/../following::div[position()=1]//input";
	public String xpTraAmnt = "//span[text()='Tranche']/../following::div[position()=7]//input";
	public String xpTraPptform = "//span[text()='Tranche']/../following::div[position()=16]//span[contains(@id,'comboBoxEdit-arrow')]";
	public String xpDraRatio = "//span[text()='Drawdown']/../following::div[position()=1]//input";
	public String xpDraAmnt = "//span[text()='Drawdown']/../following::div[position()=7]//input";
	public String xpDraPptform = "//span[text()='Drawdown']/../following::div[position()=16]//input";
	public String xpbtnApply = "//*[text()='Apply']";
	public String xpbtnSave = "//*[text()='Save']";
	public String xpParticipation = "//*[text()='Participation']";
	public String xplblTranche = "//h1//span[text()='AutoTranche']";

	public boolean tabTraSyndicationparticipation(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 20);

		String sFinRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_FinRatio);
		String sFinAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_FinAmount);
		String sFinPptform = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_FinPptForm);
		String sTraRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_TraRatio);
		String sTraAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_TraAmount);
		String sTraPptform = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_TraPptForm);
		String sDraRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_DraRatio);
		String sDraAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_DraAmount);
		String sDraPptform = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_DraPptForm);
		String sAddRatio = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_TRASYNDICATIONPARTICIPATION_AddRatio);

		try {
			// Finance details - syndication
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpParticipation)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpParticipation, "Yes");
			Thread.sleep(2000);

			if (sAddRatio.equalsIgnoreCase("Yes")) {
				
				if (sFinRatio.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFinRatio)));
					commfunct_Obj.commonSetTextTextBox(txtFinanceRatio, sFinRatio);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Finance Participation Ratio is entered as ->" + sFinRatio);
				}

				Thread.sleep(2000);
			
				if (sFinPptform.length() > 0) {
					wait.until(ExpectedConditions.visibilityOf(txtFinancePptform));
					commfunct_Obj.commonSetTextTextBox(txtFinancePptform, sFinPptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Finance Participation Form is selected as ->" + sFinPptform);
				}
				Thread.sleep(2000);

				// Tranche details - syndication
				
				if (sTraRatio.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTraRatio)));
					commfunct_Obj.commonSetTextTextBox(txtTrancheRatio, sTraRatio);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Tranche Participation Ratio is entered as ->" + sTraRatio);
				}
				Thread.sleep(2000);

				
				if (sTraPptform.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTraPptform)));
					commfunct_Obj.comboSelect(driver, sTraPptform, cmbTranchePptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Tranche Participation Form is selected as ->" + sTraPptform);
				}
				Thread.sleep(2000);
				// Drawdown details - syndication
				
				if (sDraRatio.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDraRatio)));
					commfunct_Obj.commonSetTextTextBox(txtDrawdownRatio, sDraRatio);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Drawdown Participation Ratio is entered as ->" + sDraRatio);
				}
				Thread.sleep(1000);
				
				if (sDraPptform.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDraPptform)));
					commfunct_Obj.commonSetTextTextBox(txtDrawdownPptform, sDraPptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Drawdown Participation Form is selected as ->" + sDraPptform);
				}
			} else {
			
				if (sFinAmount.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpFinAmnt)));
					commfunct_Obj.commonSetTextTextBox(txtFinanceAmnt, sFinAmount);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Finance Participation Amount is entered as ->" + sFinAmount);
				}
				Thread.sleep(2000);

				
				if (sFinPptform.length() > 0) {
					wait.until(ExpectedConditions.visibilityOf(txtFinancePptform));
					commfunct_Obj.commonSetTextTextBox(txtFinancePptform, sFinPptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Finance Participation Form is selected as ->" + sFinPptform);
				}
				Thread.sleep(2000);
				// Tranche details - syndication
				
				if (sTraAmount.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTraAmnt)));
					commfunct_Obj.commonSetTextTextBox(txtTrancheAmnt, sTraAmount);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Tranche Participation Amount is entered as ->" + sTraAmount);
				}
				Thread.sleep(2000);
				
				if (sTraPptform.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpTraPptform)));
					commfunct_Obj.comboSelect(driver, sTraPptform, cmbTranchePptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Tranche Participation Form is selected as ->" + sTraPptform);
				}
				Thread.sleep(2000);
				// Drawdown details - syndication
				
				if (sDraAmount.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDraAmnt)));
					commfunct_Obj.commonSetTextTextBox(txtDrawdownAmnt, sDraAmount);
					// commfunct_Obj.waitUntilDocumentIsReady(driver);
					lowlevellogsobj.info("Drawdown Participation Amount is entered as ->" + sDraAmount);
				}
				Thread.sleep(1000);

			
				if (sDraPptform.length() > 0) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDraPptform)));
					commfunct_Obj.commonSetTextTextBox(txtDrawdownPptform, sDraPptform);
					commfunct_Obj.waitUntilDocumentIsReady(driver);
					Thread.sleep(1000);
					lowlevellogsobj.info("Drawdown Participation Form is selected as ->" + sDraPptform);
				}
			}
			Thread.sleep(1000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnApply)));
			commfunct_Obj.commonClick(btnApply, "Yes");
			lowlevellogsobj.info("Clicked on Apply button");

			Thread.sleep(3000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xplblTranche)));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnApply)));
			commfunct_Obj.commonClick(btnApply, "Yes");
			lowlevellogsobj.info("Clicked on  tranche level Apply button");

			Thread.sleep(2000);

			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpbtnSave)));
			commfunct_Obj.commonClick(btnSave, "Yes");
			lowlevellogsobj.info("Clicked on Save button");

			Thread.sleep(2000);
			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
              	 MsgList.add("Application Dump did not occur");
              }
       }    


		return result;
	}

}
