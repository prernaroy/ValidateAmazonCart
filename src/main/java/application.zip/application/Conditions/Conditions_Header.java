/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application.Conditions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class Conditions_Header {

	private Common_Functions commfunct_Obj = new Common_Functions();
	// private Application_Common_Functions Appcommfunct_Obj = new
	// Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(Conditions_Header.class);

	public Conditions_Header(WebDriver driver) {
	}

	@FindBy(xpath = "//section//*[contains(@id,'idConditionType-arrow')]")
	private WebElement cmbCCType;

	@FindBy(xpath = "//section//*[contains(text(),'Valid From')]/../following::div[position()=2]//input")
	private WebElement txtValidfrom;

	@FindBy(xpath = "//section//label[contains(text(),'Percentage')]/../following::div[position()=1]//input")
	private WebElement txtPercentage;

	@FindBy(xpath = "//section//*[contains(text(),'Payer')]/../following::div[position()=2]//span")
	private WebElement txtPayer;

	@FindBy(xpath = "//section//*[contains(text(),'Calculation Date')]/../following::div[position()=2]//input")
	private WebElement txtCalculationdate;

	@FindBy(xpath = "//section//*[contains(text(),'Due Date')]/../following::div[position()=2]//input")
	private WebElement txtDuedate;

	@FindBy(xpath = "//section//*[contains(text(),'Periodicity Profile')]/../following::div[position()=2]//span[contains(@id,'arrow')]")
	private WebElement cmbPeriodicprofile;

	@FindBy(xpath = "//*[text()='Create']")
	private WebElement btnCreate;

	@FindBy(xpath = "//footer[contains(@id,'idEditCondition-footerWrapper')]/child::div//button[1]")
	private WebElement btnCreate1;

	@FindBy(xpath = "//a[@title='Back']")
	private WebElement btnBack;

	@FindBy(xpath = "//table/tbody/tr[@title='Click to Select']/td[2]//span")
	private WebElement rowPaymentinfo;

	public String xpConditionstab = "//*[text()='Conditions']";
	public String xpAddcondition = "//*[contains(@id,'buttonAddCond-img')]";
	public String xpcondHeadertab = "//*[text()='Header Data']";
	public String xpConditionstype = "//span[contains(@id,'idConditionType-arrow')]";
	public String xpAddedcondition = "//div[contains(@id,'ConditionView--conditionTable')]//table[contains(@aria-labelledby,'ConditionView--conditionTable')]/tbody/tr[1]/td[3]//span/span";
	public String xpValidfrom = "//section//*[contains(text(),'Valid From')]/../following::div[position()=2]//input";
	public String xpCalculationdate = "//section//*[contains(text(),'Calculation Date')]/../following::div[position()=2]//input";
	public String xpDuedate = "//section//*[contains(text(),'Due Date')]/../following::div[position()=2]//input";
	public String xpbtnCreate = "//*[text()='Create']";
	public String xpPaymentinfo = "//table/tbody/tr[@title='Click to Select']/td[2]//span";
	public String xpPercentage = "//section//label[contains(text(),'Percentage')]/../following::div[position()=1]//input";
	public String xpCreatebtn = "//footer[contains(@id,'idEditCondition-footerWrapper')]//*[text()='Create']";
	public String xpCreatebtn1 = "//footer[contains(@id,'idEditCondition-footerWrapper')]/child::div//button[1]";
	public String xpPayer = "//section//*[contains(text(),'Payer')]/../following::div[position()=2]//span";
	public String xpPeriodicprofile = "//section//*[contains(text(),'Periodicity Profile')]/../following::div[position()=2]//span[contains(@id,'arrow')]";
	public String xpBack = "//a[@title='Back']";
	
	public boolean tabConditionsheader(WebDriver driver, List<String> testArray_Data,
			HashMap<String, Integer> headerMap_Data) throws Exception {

		boolean result = true;
		WebDriverWait wait = new WebDriverWait(driver, 30);

		String sConditionType = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_ConditionType);
		String sValidFrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_ValidFrom);
		String sPercentage = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_Percentage);
		String sConditionAmount = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_ConditionAmount);
		String sSkim = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_CONDITIONSHEADER_Skim);
		String sConditionFrom = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_ConditionFrom);
		String sPayer = commfunct_Obj.getParameter(testArray_Data, headerMap_Data, Constants.C_CONDITIONSHEADER_Payer);
		String sPayerName = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_PayerName);
		String sPeriodicityProfile = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_PeriodicityProfile);
		String sCalculationDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_CalculationDate);
		String sDueDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_DueDate);
		String sMonitoringLatestOn = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_MonitoringLatestOn);
		String sEarliestExerciseDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_EarliestExerciseDate);
		String sLatestExerciseDate = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_LatestExerciseDate);
		String sFreeText = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_FreeText);
		String sExerised = commfunct_Obj.getParameter(testArray_Data, headerMap_Data,
				Constants.C_CONDITIONSHEADER_Exerised);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpcondHeadertab)));
			commfunct_Obj.commonFindElement_Click(driver, "xpath", xpcondHeadertab, "Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpConditionstype)));
			Thread.sleep(1000);
			lowlevellogsobj.info("Started in Conditions Header Data Class");

			if (sConditionType.length() > 0) {
				commfunct_Obj.comboSelect(driver, sConditionType, cmbCCType);
				Thread.sleep(3000);
				lowlevellogsobj.info("Condition Type is Selected as ->" + sConditionType);
			}
			// commfunct_Obj.commonSetTextTextBox(txtValidfrom, sValidFrom);

			// Thread.sleep(2000);

			if (sPercentage.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPercentage)));
				commfunct_Obj.commonSetTextTextBox(txtPercentage, sPercentage);
				
				lowlevellogsobj.info("Percentage is entered as ->" + sPercentage);
				Thread.sleep(1000);
			}

			if (sPayer.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPayer)));
				commfunct_Obj.commonClick(txtPayer, "Yes");
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPaymentinfo)));
				commfunct_Obj.commonClick(rowPaymentinfo, "Yes");
				lowlevellogsobj.info("Payer is entered as ->" + sPayer);
				Thread.sleep(1000);
			}

			if (sPeriodicityProfile.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpPeriodicprofile)));
				commfunct_Obj.comboSelect(driver, sPeriodicityProfile, cmbPeriodicprofile);
				lowlevellogsobj.info("Periodic Profile is selected as ->" + sPeriodicityProfile);
				Thread.sleep(3000);
			}

			if (sValidFrom.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpValidfrom)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpValidfrom, "Yes", sValidFrom);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Valid From is entered as ->" + sValidFrom);
				Thread.sleep(1000);
			}
			
			Thread.sleep(3000);
			if (sCalculationDate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpCalculationdate)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpCalculationdate, "Yes", sCalculationDate);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Calculation Date is entered as ->" + sCalculationDate);
			}
			
			Thread.sleep(1000);
			if (sDueDate.length() > 0) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpDuedate)));
				commfunct_Obj.commonFindElement_enterText(driver, "xpath", xpDuedate, "Yes", sDueDate);
				// Thread.sleep(1000);
				lowlevellogsobj.info("Due date is entered as ->" + sDueDate);
			}

			// wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpCreatebtn1)));

			// commfunct_Obj.commonClick(btnCreate,"Yes");

			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpConditionstab)));
			// driver.switchTo().defaultContent();
			// commfunct_Obj.commonClick(btnCreate,"Yes");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpBack)));
			commfunct_Obj.commonClick(btnBack, "Yes");
			lowlevellogsobj.info("Create button is clicked");
			Thread.sleep(2000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpAddedcondition)));
			// commfunct_Obj.waitUntilDocumentIsReady(driver);

			result = true;

		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    

		return result;
	}

}
