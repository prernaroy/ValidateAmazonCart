/**
 * This Code is Property of SAP Labs and is Copyright.
 * Distribution and Copying is Prohibited without
 * Approval OR Permission.
 *
 * @author I313006 / Dec 1, 2017
 */
package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.xml.sax.SAXException;

import logs.LowLevelLogs;
import utils.Common_Functions;
import utils.Constants;
import utils.DataSourceHelper;

/**
 * @author I313006
 *
 */
public class HeaderData {

	private Common_Functions commfunct_Obj = new Common_Functions();
	//private Application_Common_Functions Appcommfunct_Obj = new Application_Common_Functions();
	private DataSourceHelper ds = new DataSourceHelper();
	public ArrayList<String> MsgList = new ArrayList<String>();
	private static final Logger lowlevellogsobj = Logger.getLogger(HeaderData.class);

	public HeaderData(WebDriver driver) {
	}
	
	@FindBy(xpath = "//h1[contains(@id,'application-LoansWplcFinancing-manage-component---dealEdit--idDealEditHeader-title')]")
	private WebElement headerTitle;
	
	@FindBy(id = "application-zdealsearch-manage-component---dealEdit--idDealEditHeader-innerTitle")
	private WebElement lbl_FinanceName;

	@FindBy(xpath = "//section[contains(@id,'DealHeader')]//label[text()='Status']/../following-sibling::div[position()=1]//label")
	private WebElement cmbStatus;
	
	
	public String xpMB="//section[contains(@id,'DealHeader')]//label[text()='Main Borrower']/../following::div[position()=2]//input";
	public String xpProduct="//section[contains(@id,'DealHeader')]//label[text()='Product']/../following::div[position()=2]//input";
	public String xpCD="//section[contains(@id,'DealHeader')]//label[text()='Commitment date']/../following::div[position()=2]//input";
	public String xpStatus="//section[contains(@id,'DealHeader')]//label[text()='Status']/../following-sibling::div[position()=1]//label";
	

	public boolean headerDetails(WebDriver driver, List<String> testArray_Data,HashMap<String, Integer> headerMap_Data)
					throws Exception {

		boolean result = true;

		String sFinanceName = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_HEADERDATA, "REF_01",1);
		String sMainBorrower = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_HEADERDATA, "REF_01",2);
		String sProduct = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_HEADERDATA, "REF_01",3);
		String sCommitmentDate = ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_HEADERDATA, "REF_01",4);
		String sStatus= ds.getCellData(Constants.C_WB_TESTDATA_TC, Constants.C_SHEET_HEADERDATA, "REF_01",5);
		
		try {
			lowlevellogsobj.info("Started in HeaderData Class");
					
			lowlevellogsobj.info("Checking if Landed on Correct Screen");
			commfunct_Obj.expectedValue(headerTitle, "text", sFinanceName, "Yes");
			lowlevellogsobj.info("Landed successfully on Header Details -" + sFinanceName + "Screen");
			Thread.sleep(3000);
			commfunct_Obj.compareValue(driver, xpMB, "Main Borrower", sMainBorrower);
			commfunct_Obj.compareValue(driver, xpProduct, "Product", sProduct);
			commfunct_Obj.compareValue(driver, xpCD, "Commitment date", sCommitmentDate);
			commfunct_Obj.expectedValue(cmbStatus, "text", sStatus, "Yes");
			
			result = true;
			
		} catch (Exception e) {
			LowLevelLogs.getLogger().error("Exception in entering header Detail:  " + e.getMessage(), e);
			result = false;
		}	
		finally{
            if((driver.findElements(By.xpath("//a[text()='Show Details']")).size()==1) && (driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1)){
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//a[text()='Show Details']", "Yes");
                 Thread.sleep(1000);
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[contains(@class,'sapMMessageBoxDetails')]");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//footer//*[text()='Close']", "Yes");
                 result=false;
                 }
            else if(driver.findElements(By.xpath("//span[contains(text(),'Error')]")).size()==1){
                 String geterrorText = commfunct_Obj.commonFindElement_GetText(driver, "xpath", "//div[@class='sapMDialogScrollCont']/span");
                 lowlevellogsobj.info(geterrorText);
                 MsgList.add("Application Dump->"+geterrorText);
                 commfunct_Obj.commonFindElement_Click(driver, "xpath", "//*[text()='OK']", "Yes");
                 result=false;
            }
            else {
           	 MsgList.add("Application Dump did not occur");
           }
       }    


		return result;
	}
	
}
